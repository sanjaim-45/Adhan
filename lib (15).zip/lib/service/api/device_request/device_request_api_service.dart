// device_request_service.dart
import 'dart:convert';

import 'package:http/http.dart' as http;
import 'package:prayerunitesss/model/api/device_request/device_request_model.dart';

import '../tokens/token_service.dart';

class DeviceRequestService {
  final String baseUrl;

  DeviceRequestService({required this.baseUrl});

  Future<DeviceRequestResponse> submitDeviceRequest(
    DeviceRequest request,
  ) async {
    final url = Uri.parse('$baseUrl/api/Customer/DeviceRequest');

    // Get the stored access token
    final accessToken = await TokenService.getAccessToken();

    if (accessToken == null || accessToken.isEmpty) {
      throw Exception('No access token found');
    }
    final headers = {
      'Content-Type': 'application/json',
      // Add authorization header if needed
      'Authorization': 'Bearer $accessToken',
    };

    try {
      final response = await http.post(
        url,
        headers: headers,
        body: json.encode(request.toJson()),
      );

      if (response.statusCode == 200) {
        final responseData = json.decode(response.body);
        print(responseData);
        return DeviceRequestResponse.fromJson(responseData);
      } else {
        throw Exception(
          'Failed to submit device request: ${response.statusCode}',
        );
      }
    } catch (e) {
      throw Exception('Failed to submit device request: ${e.toString()}');
    }
  }
}
