import 'dart:convert';

import 'package:http/http.dart' as http;
import 'package:prayerunitesss/utils/app_urls.dart';

import '../tokens/token_service.dart';

class DeleteAccountService {
  Future<bool> deleteCustomerAccount(int customerId) async {
    try {
      final accessToken = await TokenService.getAccessToken();

      final response = await http.post(
        Uri.parse(
          '${AppUrls.appUrl}/api/Customer/DeleteCustomer?id=$customerId',
        ),
        headers: {
          'Authorization': 'Bearer $accessToken',
          'Content-Type': 'application/json',
        },
      );

      if (response.statusCode == 200) {
        final responseData = json.decode(response.body);
        if (responseData['message'] == "Customer deleted successfully") {
          return true;
        }
      } else {
        final errorData = json.decode(response.body);
        print('Server error: ${errorData['message'] ?? 'Unknown error'}');
      }

      return false;
    } catch (e) {
      print('Exception while deleting account: $e');
      return false;
    }
  }
}
