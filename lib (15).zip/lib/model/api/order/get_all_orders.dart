// models/order_model.dart
class Order {
  final int orderId;
  final DateTime orderDate;
  final DateTime? deliveryDate;
  final String deliveryStatus;
  final String paymentMethod;
  final List<dynamic> items;

  Order({
    required this.orderId,
    required this.orderDate,
    this.deliveryDate,
    required this.deliveryStatus,
    required this.paymentMethod,
    required this.items,
  });

  factory Order.fromJson(Map<String, dynamic> json) {
    return Order(
      orderId: json['orderId'],
      orderDate: DateTime.parse(json['orderDate']),
      deliveryDate:
          json['deliveryDate'] != null
              ? DateTime.parse(json['deliveryDate'])
              : null,
      deliveryStatus: json['deliveryStatus'],
      paymentMethod: json['paymentMethod'],
      items: json['items'] ?? [],
    );
  }
}
