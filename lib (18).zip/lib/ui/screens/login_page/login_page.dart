import 'dart:async'; // Import for TimeoutException
import 'dart:io'; // Import for SocketException

import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:http/http.dart' as http;
import 'package:prayerunitesss/ui/screens/login_page/create_account.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../../../service/api/login/login_page_api.dart';
import '../../../utils/font_mediaquery.dart';
import '../notification/notification_preference.dart';
import 'forgot_password/forgot_password_ui.dart';
import 'login_via_otp/login_otp.dart';

class LoginPage extends StatefulWidget {
  const LoginPage({super.key});

  @override
  State<LoginPage> createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  final _formKey = GlobalKey<FormState>();
  final TextEditingController _usernameController = TextEditingController();
  final TextEditingController _passwordController = TextEditingController();
  bool _isLoading = false;
  bool _isPasswordVisible = false;

  // Validation methods
  String? _validateUsername(String? value) {
    if (value == null || value.isEmpty) {
      return 'Username is required';
    }
    if (value.length < 4) {
      return 'Username must be at least 4 characters';
    }
    return null;
  }

  String? _validatePassword(String? value) {
    if (value == null || value.isEmpty) {
      return 'Password is required';
    }
    if (value.length < 8) {
      return 'Password must be at least 8 characters';
    }
    return null;
  }

  Future<void> _handleLogin() async {
    // Validate form
    if (!_formKey.currentState!.validate()) {
      return;
    }

    setState(() {
      _isLoading = true;
    });

    try {
      final response = await LoginService.login(
        userName: _usernameController.text,
        password: _passwordController.text,
        context: context,
        maintainSession: true,
      );

      if (response.message == "Login Successfull") {
        // Store customerId in SharedPreferences
        final prefs = await SharedPreferences.getInstance();
        await prefs.setString(
          'customerId',
          response.customerDetailResponse.customerId,
        );

        // Retrieve and print the stored customerId
        final storedId = prefs.getString('customerId');
        print('Stored customerId: $storedId');

        if (!mounted) return;

        // ScaffoldMessenger.of(context).showSnackBar(
        //   const SnackBar(
        //     content: Text('Login Successful'),
        //     backgroundColor: Colors.green,
        //   ),
        // );

        // Navigate to home screen
        Navigator.pushReplacement(
          context,
          MaterialPageRoute(
            builder: (context) => const NotificationPreference(),
          ),
        );
      } else {
        if (!mounted) return;
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Login failed'), backgroundColor: Colors.red),
        );
      }
    } on SocketException catch (_) {
      // Handle no internet connection
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text(
            'No internet connection. Please check your network settings.',
          ),
          backgroundColor: Colors.red,
        ),
      );
    } on TimeoutException catch (_) {
      // Handle timeout
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Connection timeout. Please try again.'),
          backgroundColor: Colors.red,
        ),
      );
    } on http.ClientException catch (e) {
      // Handle other client-side network errors
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Network error: ${e.message}'),
          backgroundColor: Colors.red,
        ),
      );
    } catch (e) {
      print(e);
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(e.toString().replaceFirst('Exception: ', '')),
          backgroundColor: Colors.red,
        ),
      );
    } finally {
      if (mounted) {
        setState(() {
          _isLoading = false;
        });
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final mediaQuery = MediaQuery.of(context);
    final screenHeight = mediaQuery.size.height;
    final screenWidth = mediaQuery.size.width;

    return Scaffold(
      backgroundColor: const Color(0xFF3B873E),
      body: Form(
        key: _formKey,
        child: Column(
          children: [
            // Top logo section (same as your original code)
            SizedBox(
              height: screenHeight * 0.22,
              child: Stack(
                clipBehavior: Clip.none,
                children: [
                  Align(
                    alignment: Alignment.topCenter,
                    child: Padding(
                      padding: EdgeInsets.only(top: screenHeight * 0.08),
                      child: Image.asset(
                        'assets/images/logo.png',
                        height: screenHeight * 0.12,
                        width: screenWidth * 0.30,
                      ),
                    ),
                  ),
                  Positioned(
                    top: screenHeight * 0.001,
                    right: screenWidth * 0.013,
                    child: Image.asset(
                      'assets/images/logo_blur.png',
                      height: screenHeight * 0.27,
                      width: screenWidth * 0.50,
                    ),
                  ),
                ],
              ),
            ),

            // Login form
            Expanded(
              child: Container(
                width: double.infinity,
                padding: EdgeInsets.symmetric(
                  horizontal: screenWidth * 0.05,
                  vertical: screenHeight * 0.04,
                ),
                decoration: const BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.only(
                    topLeft: Radius.circular(28),
                    topRight: Radius.circular(28),
                  ),
                ),
                child: SingleChildScrollView(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'Access Live Mosque Audio',
                        style: GoogleFonts.beVietnamPro(
                          fontSize: getFontBoldSize(context),
                          fontWeight: FontWeight.w700,
                          letterSpacing: -0.5,
                        ),
                      ),
                      Text(
                        'Login with your Email ID or Phone Number and Password to access the live Mosque audio.',
                        style: GoogleFonts.beVietnamPro(
                          fontSize: getFontRegularSize(context),
                          color: Colors.grey[700],
                          letterSpacing: -0.5,
                        ),
                      ),
                      SizedBox(height: screenHeight * 0.03),

                      // Username Field
                      Text(
                        'Email ID or Phone Number*',
                        style: GoogleFonts.beVietnamPro(
                          fontWeight: FontWeight.w600,
                          color: Color(0xFF3A4354),
                          fontSize: getDynamicFontSize(context, 0.032),
                          letterSpacing: -0.5,
                        ),
                      ),
                      SizedBox(height: screenHeight * 0.008),
                      TextFormField(
                        controller: _usernameController,
                        validator: _validateUsername,
                        style: GoogleFonts.beVietnamPro(
                          fontSize: getFontRegularSize(context),
                        ),
                        decoration: InputDecoration(
                          hintText: 'Enter your username',
                          hintStyle: GoogleFonts.beVietnamPro(
                            color: const Color(0xFFA1A1A1),
                            fontSize: getFontRegularSize(context),
                            letterSpacing: -0.5,
                          ),
                          contentPadding: EdgeInsets.symmetric(
                            vertical: screenHeight * 0.015,
                            horizontal: screenWidth * 0.04,
                          ),
                          enabledBorder: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(10),
                            borderSide: const BorderSide(
                              color: Color(0xFFEBEBEB),
                            ),
                          ),
                          focusedBorder: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(10),
                            borderSide: const BorderSide(
                              color: Color(0xFF3B873E),
                              width: 2,
                            ),
                          ),
                          errorBorder: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(10),
                            borderSide: const BorderSide(color: Colors.red),
                          ),
                          focusedErrorBorder: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(10),
                            borderSide: const BorderSide(
                              color: Colors.red,
                              width: 2,
                            ),
                          ),
                          filled: true,
                          fillColor: Colors.white,
                        ),
                      ),
                      SizedBox(height: screenHeight * 0.025),

                      // Password Field
                      Text(
                        'Password',
                        style: GoogleFonts.beVietnamPro(
                          fontWeight: FontWeight.w600,
                          color: Color(0xFF3A4354),

                          fontSize: getDynamicFontSize(context, 0.032),
                          letterSpacing: -0.5,
                        ),
                      ),
                      SizedBox(height: screenHeight * 0.008),
                      TextFormField(
                        controller: _passwordController,
                        validator: _validatePassword,
                        style: GoogleFonts.beVietnamPro(
                          fontSize: getFontRegularSize(context),
                        ),
                        obscureText: !_isPasswordVisible,
                        decoration: InputDecoration(
                          hintText: 'Enter your password',
                          hintStyle: GoogleFonts.beVietnamPro(
                            color: const Color(0xFFA1A1A1),
                            fontSize: getFontRegularSize(context),
                            letterSpacing: -0.5,
                          ),
                          contentPadding: EdgeInsets.symmetric(
                            vertical: screenHeight * 0.015,
                            horizontal: screenWidth * 0.04,
                          ),
                          enabledBorder: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(10),
                            borderSide: const BorderSide(
                              color: Color(0xFFEBEBEB),
                            ),
                          ),
                          focusedBorder: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(10),
                            borderSide: const BorderSide(
                              color: Color(0xFF3B873E),
                              width: 2,
                            ),
                          ),
                          errorBorder: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(10),
                            borderSide: const BorderSide(color: Colors.red),
                          ),
                          focusedErrorBorder: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(10),
                            borderSide: const BorderSide(
                              color: Colors.red,
                              width: 2,
                            ),
                          ),
                          filled: true,
                          fillColor: Colors.white,
                          suffixIcon: IconButton(
                            icon: Icon(
                              _isPasswordVisible
                                  ? Icons.visibility_outlined
                                  : Icons.visibility_off_outlined,
                              size: getFontRegularSize(context) * 1.5,
                            ),
                            onPressed: () {
                              setState(() {
                                _isPasswordVisible = !_isPasswordVisible;
                              });
                            },
                          ),
                        ),
                      ),
                      const SizedBox(height: 8),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          GestureDetector(
                            onTap: () {
                              Navigator.of(context).push(
                                MaterialPageRoute(
                                  builder: (context) => const ForgotPassword(),
                                ),
                              );
                            },
                            child: Text(
                              'Forgot Password?',
                              style: TextStyle(
                                color: Color(0xFF2E7D32),
                                fontSize: getDynamicFontSize(context, 0.032),
                                fontWeight: FontWeight.w600,
                              ),
                            ),
                          ),
                          GestureDetector(
                            onTap: () {
                              Navigator.of(context).push(
                                MaterialPageRoute(
                                  builder: (context) => const LoginOtp(),
                                ),
                              );
                            },
                            child: Text(
                              'Login Via OTP',
                              style: TextStyle(
                                color: Color(0xFF2E7D32),
                                fontSize: getDynamicFontSize(context, 0.032),
                                fontWeight: FontWeight.w600,
                              ),
                            ),
                          ),
                        ],
                      ),
                      SizedBox(height: screenHeight * 0.02),

                      // Login Button
                      SizedBox(
                        width: double.infinity,
                        height: screenHeight * 0.055,
                        child: ElevatedButton(
                          onPressed: _isLoading ? null : _handleLogin,
                          style: ElevatedButton.styleFrom(
                            backgroundColor: const Color(0xFF2D7C3F),
                            padding: const EdgeInsets.symmetric(vertical: 10),
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(10),
                            ),
                            elevation: 0,
                          ),
                          child:
                              _isLoading
                                  ? const CircularProgressIndicator(
                                    color: Colors.white,
                                    strokeWidth: 2,
                                  )
                                  : Text(
                                    'Login',
                                    style: GoogleFonts.beVietnamPro(
                                      fontSize: getFontRegularSize(context),
                                      letterSpacing: -0.5,
                                      fontWeight: FontWeight.w500,
                                      color: Colors.white,
                                    ),
                                  ),
                        ),
                      ),
                      SizedBox(height: 5),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Text(
                            "Dont have an account?",
                            style: GoogleFonts.inter(letterSpacing: -0.5),
                          ),
                          GestureDetector(
                            onTap: () {
                              Navigator.of(context).push(
                                MaterialPageRoute(
                                  builder: (context) => SignupScreen(),
                                ),
                              );
                            },
                            child: Text(
                              "Create Amount",
                              style: GoogleFonts.inter(
                                color: Color(0xFF2E7D32),
                                fontWeight: FontWeight.w400,
                                letterSpacing: -0.5,
                              ),
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  @override
  void dispose() {
    _usernameController.dispose();
    _passwordController.dispose();
    super.dispose();
  }
}
