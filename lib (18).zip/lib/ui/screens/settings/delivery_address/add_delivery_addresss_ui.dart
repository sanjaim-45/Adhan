// add_delivery_address_page.dart
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:prayerunitesss/utils/app_urls.dart';

import '../../../../model/api/address/shipping_address_create_model.dart';
import '../../../../service/api/address/shipping_address_add/shipping_address_create.dart';
import '../../../../service/api/address/shipping_address_add/shipping_address_update_api.dart';
import '../../../../service/api/templete_api/api_service.dart';
import '../../../../utils/font_mediaquery.dart';

class AddDeliveryAddressPage extends StatefulWidget {
  final ShippingAddress?
  existingAddress; // Use ShippingAddress instead of ShippingAddressss

  const AddDeliveryAddressPage({super.key, this.existingAddress});

  @override
  _AddDeliveryAddressPageState createState() => _AddDeliveryAddressPageState();
}

class _AddDeliveryAddressPageState extends State<AddDeliveryAddressPage> {
  final ShippingAddressApiService _shippingAddressApiService;
  final ShippingAddressUpdateApiService _shippingAddressUpdateApiService;
  final _formKey = GlobalKey<FormState>();

  _AddDeliveryAddressPageState()
    : _shippingAddressApiService = ShippingAddressApiService(
        ApiService(baseUrl: AppUrls.appUrl),
      ),
      _shippingAddressUpdateApiService = ShippingAddressUpdateApiService(
        apiService: ApiService(baseUrl: AppUrls.appUrl),
      );

  late final TextEditingController _fullNameController;
  late final TextEditingController _mobileNumberController;
  late final TextEditingController _emailController;
  late final TextEditingController _addressController;
  late bool isDefault;

  @override
  void initState() {
    super.initState();

    // Initialize controllers with existing address data if available
    _fullNameController = TextEditingController(
      text: widget.existingAddress?.fullName ?? '',
    );
    _mobileNumberController = TextEditingController(
      text: widget.existingAddress?.phoneNumber ?? '',
    );
    _emailController = TextEditingController(
      text: widget.existingAddress?.email ?? '',
    );
    _addressController = TextEditingController(
      text: widget.existingAddress?.address ?? '',
    );
    isDefault = widget.existingAddress?.isDefault ?? false;
  }

  @override
  void dispose() {
    _fullNameController.dispose();
    _mobileNumberController.dispose();
    _emailController.dispose();
    _addressController.dispose();
    super.dispose();
  }

  Future<void> _saveAddress() async {
    if (!_formKey.currentState!.validate()) return;

    try {
      if (widget.existingAddress != null) {
        // Update existing address
        await _shippingAddressUpdateApiService.updateShippingAddress(
          addressId: widget.existingAddress!.shippingAddressId,
          fullName: _fullNameController.text,
          phoneNumber: _mobileNumberController.text,
          email: _emailController.text,
          address: _addressController.text,
          makeDefault: isDefault,
        );
      } else {
        // Create new address
        await _shippingAddressApiService.createShippingAddress(
          fullName: _fullNameController.text,
          phoneNumber: _mobileNumberController.text,
          email: _emailController.text,
          address: _addressController.text,
          makeDefault: isDefault,
        );
      }

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
            widget.existingAddress != null
                ? 'Address updated successfully'
                : 'Address created successfully',
          ),
        ),
      );

      Navigator.of(context).pop(true); // Return success
    } catch (e) {
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(SnackBar(content: Text('Failed to save address: $e')));
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: PreferredSize(
        preferredSize: const Size.fromHeight(80),
        child: Container(
          decoration: BoxDecoration(
            color: Colors.white,
            boxShadow: [
              BoxShadow(
                color: Colors.grey.withOpacity(0.1),
                spreadRadius: 1,
                blurRadius: 8,
                offset: const Offset(0, 4),
              ),
            ],
          ),
          child: Padding(
            padding: const EdgeInsets.only(top: 20.0),
            child: AppBar(
              backgroundColor: Colors.white,
              elevation: 0,
              leadingWidth: 70,
              leading: Padding(
                padding: const EdgeInsets.only(left: 10.0),
                child: GestureDetector(
                  onTap: () => Navigator.of(context).pop(),
                  child: Container(
                    margin: EdgeInsets.all(10),
                    decoration: BoxDecoration(
                      border: Border.all(
                        width: 1,
                        color: Colors.grey.withOpacity(0.5),
                      ),
                      borderRadius: BorderRadius.circular(5),
                    ),
                    width: 40,
                    height: 15,
                    child: const Icon(
                      Icons.arrow_back_ios_new_rounded,
                      size: 15,
                      color: Colors.black,
                    ),
                  ),
                ),
              ),
              title: Padding(
                padding: const EdgeInsets.only(top: 0.0),
                child: Text(
                  widget.existingAddress != null
                      ? 'Edit Address'
                      : 'Add Address',
                  style: GoogleFonts.beVietnamPro(
                    color: Colors.black,
                    letterSpacing: -0.5,
                    fontSize: getDynamicFontSize(context, 0.05),
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
            ),
          ),
        ),
      ),
      body: Form(
        key: _formKey,
        child: Padding(
          padding: const EdgeInsets.fromLTRB(16.0, 16.0, 16.0, 0),
          child: Column(
            children: <Widget>[
              Expanded(
                child: ListView(
                  children: <Widget>[
                    _buildTextField(
                      label: 'Full Name',
                      hint: 'e.g. Ahmed Al-Mutairi',
                      controller: _fullNameController,
                      keyboardType: TextInputType.text,
                      inputFormatters: [
                        FilteringTextInputFormatter.allow(
                          RegExp(r"[a-zA-Z ]"),
                        ), // Allow letters and spaces
                      ],
                      validator: (value) {
                        // Treat only spaces as empty
                        if (value == null || value.trim().isEmpty) {
                          return 'Please enter full name';
                        }

                        // Optional: reject multiple spaces between words
                        if (!RegExp(
                          r'^[a-zA-Z]+(?: [a-zA-Z]+)*$',
                        ).hasMatch(value.trim())) {
                          return 'Enter a valid full name';
                        }

                        return null;
                      },
                    ),

                    _buildTextField(
                      label: 'Mobile Number',
                      hint: 'e.g. +965 50123456',
                      controller: _mobileNumberController,
                      keyboardType: TextInputType.phone,
                      inputFormatters: [
                        FilteringTextInputFormatter.digitsOnly,
                        LengthLimitingTextInputFormatter(
                          12,
                        ), // Limit to 12 digits
                      ],
                      validator: (value) {
                        if (value == null || value.isEmpty) {
                          return 'Please enter mobile number';
                        }
                        // Kuwait mobile number validation: starts with 965 and is followed by 8 digits starting with 5, 6, or 9
                        // Or, starts with 5, 6, or 9 and has 8 digits
                        final kuwaitMobileRegex = RegExp(
                          r'^(965[569]\d{7}|[569]\d{7})$',
                        );

                        return null;
                      },
                    ),
                    _buildTextField(
                      label: 'Email Address',
                      hint: 'e.g. ahmed@email.com',
                      controller: _emailController,
                      keyboardType: TextInputType.emailAddress,
                      validator: (value) {
                        if (value == null || value.isEmpty) {
                          return 'Please enter email';
                        }
                        if (!value.contains('@')) {
                          return 'Please enter a valid email';
                        }
                        return null;
                      },
                    ),
                    _buildTextField(
                      label: 'Home Address',
                      hint: 'e.g. 123 Main St, Kuwait City',
                      controller: _addressController,
                      maxLines: 3,
                      validator: (value) {
                        if (value == null || value.isEmpty) {
                          return 'Please enter address';
                        }
                        return null;
                      },
                    ),
                    Row(
                      children: [
                        Checkbox(
                          value: isDefault,
                          onChanged: (val) {
                            setState(() {
                              isDefault = val ?? false;
                            });
                          },
                        ),
                        Text("Make this my default Address"),
                      ],
                    ),
                  ],
                ),
              ),
              SizedBox(height: 20),
              Padding(
                padding: const EdgeInsets.only(bottom: 16.0),
                child: SizedBox(
                  height: 56,
                  width: double.infinity,
                  child: ElevatedButton(
                    onPressed: _saveAddress,
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Color(0xFF2E7D32),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(12),
                      ),
                    ),
                    child: Text(
                      widget.existingAddress != null
                          ? 'Update Address'
                          : 'Save Address',
                      style: TextStyle(fontSize: 16, color: Colors.white),
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildTextField({
    required String label,
    required String hint,
    required TextEditingController controller,
    required FormFieldValidator<String>? validator,
    TextInputType keyboardType = TextInputType.text,
    int maxLines = 1,
    List<TextInputFormatter>? inputFormatters,
  }) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 16.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            label,
            style: TextStyle(
              fontWeight: FontWeight.w600,
              color: Color(0xFF3A4354),
            ),
          ),
          SizedBox(height: 8),
          TextFormField(
            controller: controller,
            keyboardType: keyboardType,
            maxLines: maxLines,
            validator: validator,
            inputFormatters: inputFormatters,
            decoration: InputDecoration(
              hintText: hint,
              hintStyle: TextStyle(color: Color(0xFFA1A1A1)),
              filled: true,
              fillColor: Colors.white,
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(12),
                borderSide: BorderSide(color: Colors.grey.shade300),
              ),
              focusedBorder: OutlineInputBorder(
                borderRadius: BorderRadius.circular(12),
                borderSide: BorderSide(
                  color: Color(0xFF2E7D32),
                ), // Focused color
              ),
              enabledBorder: OutlineInputBorder(
                borderRadius: BorderRadius.circular(12),
                borderSide: BorderSide(color: Colors.grey.shade300),
              ),
              contentPadding: EdgeInsets.symmetric(
                horizontal: 16,
                vertical: 14,
              ),
            ),
          ),
        ],
      ),
    );
  }
}
