import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:intl/intl.dart';

import '../../../model/api/transaction/transaction_response.dart';
import '../../../utils/custom_appbar.dart';

class TransactionDetailsPage extends StatelessWidget {
  final CustomerTransaction transaction;

  const TransactionDetailsPage({super.key, required this.transaction});

  @override
  Widget build(BuildContext context) {
    final size = MediaQuery.of(context).size;
    final padding = size.width * 0.05;

    return Scaffold(
      appBar: CustomAppBar(
        title: 'Transaction Details',
        onBack: () => Navigator.of(context).pop(),
      ),
      body: Padding(
        padding: EdgeInsets.all(padding),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Recent transaction history',
              style: GoogleFonts.beVietnamPro(
                fontSize: 16,
                fontWeight: FontWeight.w700,
              ),
            ),
            const SizedBox(height: 16),
            Expanded(
              child: SingleChildScrollView(
                child: Container(
                  width: double.infinity,
                  padding: EdgeInsets.all(padding),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(12),
                    boxShadow: const [
                      BoxShadow(
                        color: Colors.black12,
                        blurRadius: 6,
                        offset: Offset(0, 2),
                      ),
                    ],
                  ),
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      // First column (6 fields)
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            _buildDetailItem(
                              'Transaction Number',
                              transaction.transactionNumber,
                            ),
                            const SizedBox(height: 16),
                            _buildDetailItem(
                              'User Name',
                              transaction.customerName,
                            ),
                            const SizedBox(height: 16),
                            _buildDetailItem(
                              'User ID',
                              transaction.customerId.toString(),
                            ),
                            const SizedBox(height: 16),
                            _buildDetailItem('Masjid', transaction.mosqueName),
                            const SizedBox(height: 16),
                            _buildDetailItem(
                              'Subscription Type',
                              transaction.subscriptionType,
                            ),
                            const SizedBox(height: 16),
                            _buildDetailItem(
                              'Amount',
                              transaction.amountPaidFormatted,
                            ),
                          ],
                        ),
                      ),
                      const SizedBox(width: 16),
                      // Second column (remaining 6 fields)
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            _buildDetailItem(
                              'Payment Status',
                              transaction.paymentStatus,
                            ),
                            const SizedBox(height: 16),
                            _buildDetailItem(
                              'Payment Date',
                              _formatDateTime(transaction.paymentDate),
                            ),
                            const SizedBox(height: 16),
                            _buildDetailItem(
                              'Payment Method',
                              transaction.paymentMethod,
                            ),
                            const SizedBox(height: 16),
                            _buildDetailItem(
                              'Start Date',
                              _formatDate(transaction.startDate),
                            ),
                            const SizedBox(height: 16),
                            _buildDetailItem(
                              'End Date',
                              _formatDate(transaction.endDate),
                            ),
                            const SizedBox(height: 16),
                            _buildDetailItem(
                              'Next Renewal',
                              _formatDate(transaction.nextRenewal),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
      backgroundColor: const Color(0xFFF8F8F8),
    );
  }

  Widget _buildDetailItem(String title, String value) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          title, // Use GoogleFonts.beVietnamPro for the title
          style: GoogleFonts.beVietnamPro(
            fontWeight: FontWeight.w600, // Use a slightly bolder weight
            fontSize: 14, // Keep the font size
            color: Colors.black87, // Keep the color
          ),
        ),
        const SizedBox(height: 4),
        Text(
          value.isNotEmpty ? value : 'N/A',
          style: GoogleFonts.beVietnamPro(
            fontSize: 12,
            color: Colors.grey[700],
          ), // Use GoogleFonts.beVietnamPro
        ),
      ],
    );
  }

  String _formatDate(DateTime date) {
    return '${date.day}/${date.month}/${date.year}';
  }

  String _formatDateTime(DateTime date) {
    // Format: 01 April 2025, 10:32 AM
    final formatter = DateFormat('dd MMMM yyyy, hh:mm a');
    if (date == null) {
      return 'N/A';
    }
    return formatter.format(date);
  }
}
