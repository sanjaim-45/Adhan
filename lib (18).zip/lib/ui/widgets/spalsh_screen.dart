import 'dart:io';

import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:prayerunitesss/providers/auth_providers.dart';
import 'package:prayerunitesss/ui/widgets/main_screen.dart';
import 'package:provider/provider.dart';

import '../../providers/user_details_from_login/user_details.dart';
import '../../service/api/templete_api/api_service.dart';
import '../../service/api/tokens/token_service.dart';
import '../../utils/app_urls.dart';
import '../screens/login_page/login_page.dart';

class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen>
    with SingleTickerProviderStateMixin, WidgetsBindingObserver {
  late AnimationController _controller;
  late Animation<double> _scaleAnimation;
  bool _showButton = false;
  bool _showNoInternet = false;
  bool _isDisposed = false;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);

    _controller = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1500),
    );

    _scaleAnimation = Tween<double>(
      begin: 0.5,
      end: 1.0,
    ).animate(CurvedAnimation(parent: _controller, curve: Curves.easeOutBack));

    _controller.forward();
    _controller.addStatusListener((status) {
      if (!_isDisposed) {
        _initializeApp();
      }
    });
  }

  Future<bool> _checkInternetConnection() async {
    try {
      final result = await InternetAddress.lookup('google.com');
      return result.isNotEmpty && result[0].rawAddress.isNotEmpty;
    } on SocketException catch (_) {
      return false;
    }
  }

  Future<void> _initializeApp() async {
    if (_isDisposed) return;

    final hasConnection = await _checkInternetConnection();

    if (!hasConnection) {
      setState(() => _showNoInternet = true);
      return;
    }

    try {
      // Load user details first
      await Provider.of<UserDetailsProvider>(
        context,
        listen: false,
      ).loadUserDetails();

      final auth = Provider.of<AuthProvider>(context, listen: false);

      // Check if we should maintain session
      final shouldMaintain = await TokenService.shouldMaintainSession();

      if (shouldMaintain && await TokenService.hasRefreshToken()) {
        final refreshed = await _attemptTokenRefresh();
        if (refreshed) {
          await auth.softLogin();
          _navigateToHome();
          return;
        }
      }

      // Normal auth check
      await auth.checkAuthStatus();

      if (auth.isLoggedIn == true) {
        _navigateToHome();
      } else {
        setState(() => _showButton = true);
      }
    } catch (e) {
      setState(() => _showButton = true);
    }
  }

  @override
  void dispose() {
    _isDisposed = true;
    _controller.dispose();
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }

  Future<bool> _attemptTokenRefresh() async {
    try {
      final refreshed =
          await ApiService(baseUrl: AppUrls.appUrl).refreshToken();
      if (refreshed) {
        TokenRefreshService().start();
        return true;
      }
      return false;
    } catch (e) {
      return false;
    }
  }

  void _showNoInternetDialog() {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder:
          (context) => AlertDialog(
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(16),
            ),
            backgroundColor: const Color(0xFF3B873E), // Islamic green
            title: Row(
              children: [
                Icon(Icons.wifi_off, color: Colors.amber[300]),
                SizedBox(width: 10),
                Text(
                  'No Internet Connection',
                  style: GoogleFonts.scheherazadeNew(
                    color: Colors.white,
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ],
            ),
            content: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Text(
                  'Please turn on your internet to use the prayer app.',
                  style: GoogleFonts.scheherazadeNew(
                    color: Colors.white,
                    fontSize: 15,
                  ),
                ),
                SizedBox(height: 10),
                Text(
                  '"Indeed, Allah guides whom He wills to a straight path." — Surah Al-Baqarah (2:213)',
                  style: GoogleFonts.scheherazadeNew(
                    color: Colors.amber,
                    fontStyle: FontStyle.italic,
                    fontSize: 14,
                  ),
                  textAlign: TextAlign.center,
                ),
              ],
            ),
            actions: [
              TextButton(
                onPressed: () {
                  Navigator.of(context).pop();
                  _retryConnection();
                },
                style: TextButton.styleFrom(
                  foregroundColor: Colors.amberAccent,
                  padding: EdgeInsets.symmetric(horizontal: 20),
                ),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Icon(Icons.refresh, color: Colors.amberAccent),
                    SizedBox(width: 5),
                    Text(
                      'Retry',
                      style: GoogleFonts.scheherazadeNew(
                        color: Colors.amberAccent,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
    );
  }

  Future<void> _retryConnection() async {
    final hasConnection = await _checkInternetConnection();

    if (hasConnection) {
      setState(() => _showNoInternet = false);
      _initializeApp();
    } else {
      _showNoInternetDialog();
    }
  }

  void _navigateToHome() {
    Navigator.of(
      context,
    ).pushReplacement(MaterialPageRoute(builder: (_) => const MainScreen()));
  }

  void _navigateToLogin() {
    Navigator.of(
      context,
    ).pushReplacement(MaterialPageRoute(builder: (_) => const LoginPage()));
  }

  @override
  Widget build(BuildContext context) {
    final Size size = MediaQuery.of(context).size;
    final double height = size.height;
    final double width = size.width;

    // Show the internet alert when needed
    if (_showNoInternet) {
      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (mounted) {
          _showNoInternetDialog();
        }
      });
    }

    return Scaffold(
      backgroundColor: const Color(0xFF3B873E),
      body: Stack(
        children: [
          Positioned.fill(
            child: Image.asset(
              'assets/images/spalsh_screen.png',
              fit: BoxFit.cover,
            ),
          ),
          Center(
            child: AnimatedBuilder(
              animation: _scaleAnimation,
              builder: (context, child) {
                return Transform.scale(
                  scale: _scaleAnimation.value,
                  child: child,
                );
              },
              child: Image.asset(
                'assets/images/logo.png',
                height: height * 0.2,
                width: width * 0.4,
              ),
            ),
          ),
          if (_showButton)
            Positioned(
              bottom: height * 0.05,
              left: width * 0.08,
              right: width * 0.08,
              child: AnimatedSlide(
                duration: const Duration(milliseconds: 800),
                curve: Curves.easeOut,
                offset: _showButton ? Offset.zero : const Offset(0, 0.5),
                child: AnimatedOpacity(
                  duration: const Duration(milliseconds: 800),
                  opacity: _showButton ? 1.0 : 0.0,
                  child: ElevatedButton(
                    onPressed: _navigateToLogin,
                    style: ElevatedButton.styleFrom(
                      backgroundColor: const Color(0xFFD4AF37),
                      foregroundColor: const Color(0xFF3B873E),
                      padding: EdgeInsets.symmetric(vertical: height * 0.015),
                      textStyle: GoogleFonts.beVietnamPro(
                        fontSize: width * 0.045,
                        fontWeight: FontWeight.bold,
                      ),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(12),
                      ),
                    ),
                    child: Text(
                      'Get Started',
                      style: GoogleFonts.beVietnamPro(color: Colors.white),
                    ),
                  ),
                ),
              ),
            ),
        ],
      ),
    );
  }
}
