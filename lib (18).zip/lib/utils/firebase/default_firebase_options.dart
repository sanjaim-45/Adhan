import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/foundation.dart';

class DefaultFirebaseOptions {
  static const FirebaseOptions android = FirebaseOptions(
    apiKey: 'AIzaSyBbVist4Dee-NoQYeXAjlWs3h4fdmvbtMw',
    appId: '1:379008315585:android:d9d680892488047543a440',
    messagingSenderId: '379008315585',
    projectId: 'atticafe-b9e3d',
    storageBucket: 'atticafe-b9e3d.appspot.com',
  );

  static FirebaseOptions get currentPlatform {
    if (kIsWeb) throw UnsupportedError('Web not supported');
    return android; // Android-only configuration
  }
}
