import 'dart:async';

import 'package:audio_service/audio_service.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/material.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:prayerunitesss/providers/auth_providers.dart';
import 'package:prayerunitesss/providers/check_customer/customer_provider.dart';
import 'package:prayerunitesss/providers/device_request/device_request_provider.dart';
import 'package:prayerunitesss/providers/subscription/subscription.dart';
import 'package:prayerunitesss/providers/subscription/subscription_provider.dart';
import 'package:prayerunitesss/providers/user_details_from_login/user_details.dart';
import 'package:prayerunitesss/service/api/templete_api/api_service.dart';
import 'package:prayerunitesss/service/api/tokens/token_service.dart';
import 'package:prayerunitesss/ui/screens/login_page/login_page.dart';
import 'package:prayerunitesss/ui/widgets/main_screen.dart';
import 'package:prayerunitesss/ui/widgets/prayer_card.dart';
import 'package:prayerunitesss/ui/widgets/spalsh_screen.dart';
import 'package:prayerunitesss/utils/app_urls.dart';
import 'package:prayerunitesss/utils/firebase/default_firebase_options.dart';
import 'package:provider/provider.dart';
import 'package:shared_preferences/shared_preferences.dart';

late AudioHandler _audioHandler;

// Notification handling setup
Future<void> _firebaseMessagingBackgroundHandler(RemoteMessage message) async {
  // Handle background messages
  print("Handling a background message: ${message.messageId}");
  // You can handle your notification data here
}

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp(
    name: 'adhan',
    options: DefaultFirebaseOptions.currentPlatform,
  );

  // Set up Firebase Messaging
  FirebaseMessaging.onBackgroundMessage(_firebaseMessagingBackgroundHandler);

  _audioHandler = await AudioService.init(
    builder: () => AudioPlayerHandler(),
    config: const AudioServiceConfig(
      androidNotificationChannelId: 'com.yourcompany.yourapp.channel.audio',
      androidNotificationChannelName: 'Audio playback',
      androidNotificationOngoing: true,
      androidStopForegroundOnPause: true,
    ),
  );

  runApp(const MyApp());
}

class MyApp extends StatefulWidget {
  const MyApp({super.key});

  @override
  State<MyApp> createState() => _MyAppState();
}

class _MyAppState extends State<MyApp> {
  final ApiService apiService = ApiService(baseUrl: AppUrls.appUrl);
  final FirebaseMessaging _firebaseMessaging = FirebaseMessaging.instance;
  String? _fcmToken;

  @override
  void initState() {
    super.initState();
    _initializeApp();
    _setupPushNotifications();
  }

  Future _initializeApp() async {
    final prefs = await SharedPreferences.getInstance();
    final customerIdString = prefs.getString('customerId');

    // Only start refresh service if we have tokens AND user wants to maintain session
    if (await TokenService.hasValidTokens() &&
        await TokenService.shouldMaintainSession()) {
      TokenRefreshService().start();
    }
  }

  Future<void> _setupPushNotifications() async {
    // Request permission (iOS only)
    NotificationSettings settings = await _firebaseMessaging.requestPermission(
      alert: true,
      announcement: false,
      badge: true,
      carPlay: false,
      criticalAlert: false,
      provisional: false,
      sound: true,
    );

    print('User granted permission: ${settings.authorizationStatus}');

    // Get the token each time the app loads
    _fcmToken = await _firebaseMessaging.getToken();
    print("FCM Token: $_fcmToken");

    // Save the token to your server if needed
    if (_fcmToken != null) {
      _saveTokenToServer(_fcmToken!);
    }

    // Handle token refresh
    _firebaseMessaging.onTokenRefresh.listen((newToken) {
      print("FCM Token refreshed: $newToken");
      _fcmToken = newToken;
      _saveTokenToServer(newToken);
    });

    // Foreground messages
    FirebaseMessaging.onMessage.listen((RemoteMessage message) {
      print('Got a message whilst in the foreground!');
      print('Message data: ${message.data}');

      if (message.notification != null) {
        print('Message also contained a notification: ${message.notification}');
        // You can show a local notification here
        _showLocalNotification(message);
      }
    });

    // When app is in background but not terminated
    FirebaseMessaging.onMessageOpenedApp.listen((RemoteMessage message) {
      print('A new onMessageOpenedApp event was published!');
      // Handle notification when app is opened from background
      _handleNotification(message);
    });

    // For terminated app - check if app was opened from notification
    _checkInitialNotification();
  }

  Future<void> _checkInitialNotification() async {
    RemoteMessage? initialMessage =
        await FirebaseMessaging.instance.getInitialMessage();
    if (initialMessage != null) {
      _handleNotification(initialMessage);
    }
  }

  void _handleNotification(RemoteMessage message) {
    // Navigate to specific screen based on the notification data
    // You can access data with message.data
    print('Notification data: ${message.data}');
  }

  Future<void> _showLocalNotification(RemoteMessage message) async {
    final flutterLocalNotificationsPlugin = FlutterLocalNotificationsPlugin();

    // Notification channel for Android
    final AndroidNotificationChannel channel = AndroidNotificationChannel(
      'high_importance_channel', // Same as in AndroidManifest.xml
      'High Importance Notifications',
      importance: Importance.high,
      playSound: true,
    );

    // Initialize the plugin
    await flutterLocalNotificationsPlugin.initialize(
      const InitializationSettings(
        android: AndroidInitializationSettings('@mipmap/ic_launcher'),
        iOS: DarwinInitializationSettings(),
      ),
    );

    // Create the notification
    await flutterLocalNotificationsPlugin.show(
      0, // Notification ID
      message.notification?.title ?? 'New Notification',
      message.notification?.body ?? 'You have a new message',
      NotificationDetails(
        android: AndroidNotificationDetails(
          channel.id,
          channel.name,
          icon: '@mipmap/ic_launcher',
          importance: Importance.high,
          playSound: true,
        ),
        iOS: const DarwinNotificationDetails(),
      ),
    );
  }

  Future<void> _saveTokenToServer(String token) async {
    // Implement your logic to send the token to your server
    print('Saving FCM token to server: $token');
    // Example: await apiService.saveFcmToken(token);
  }

  @override
  void dispose() {
    TokenRefreshService().stop();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return MultiProvider(
      providers: [
        ChangeNotifierProvider(create: (context) => AuthProvider()),
        ChangeNotifierProvider(
          create: (context) => UserDetailsProvider()..loadUserDetails(),
        ),
        Provider<ApiService>.value(value: apiService),
        ChangeNotifierProvider(create: (_) => SubscriptionProvider()),
        ChangeNotifierProvider(create: (_) => DeviceRequestProvider()),
        ChangeNotifierProvider(create: (_) => CustomerProvider()),
        ChangeNotifierProvider(create: (_) => SubscriptionProviders()),
      ],
      child: MaterialApp(
        debugShowCheckedModeBanner: false,
        builder: (context, child) {
          return MediaQuery(
            data: MediaQuery.of(
              context,
            ).copyWith(textScaler: TextScaler.noScaling),
            child: child!,
          );
        },
        home: FutureBuilder(
          future: SharedPreferences.getInstance(),
          builder: (context, snapshot) {
            if (snapshot.connectionState != ConnectionState.done) {
              return const SplashScreen();
            }

            final prefs = snapshot.data as SharedPreferences;
            final customerId = prefs.getString('customerId');

            return Consumer<AuthProvider>(
              builder: (context, auth, child) {
                if (auth.isLoggedIn == null) return const SplashScreen();
                return (auth.isLoggedIn! && customerId != null)
                    ? const MainScreen()
                    : const LoginPage();
              },
            );
          },
        ),
      ),
    );
  }
}
