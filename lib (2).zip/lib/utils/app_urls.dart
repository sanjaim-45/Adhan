class AppUrls{
  final appUrl = "https://prayer.leatticafe.com";
}