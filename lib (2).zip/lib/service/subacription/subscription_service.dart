import 'dart:convert';

import '../../model/api/customer_subscription/customer_subscribed.dart';
import '../../utils/app_urls.dart';
import 'package:http/http.dart' as http;

import '../api/tokens/token_service.dart';
class SubscriptionServices {
  static Future<CustomerSubscription> getCustomerSubscription(int customerId) async {
    final response = await http.get(
      Uri.parse('${AppUrls().appUrl}/api/CustomerSubscription/GetById?id=$customerId'),
      headers: {
        'Content-Type': 'application/json',
        'Authorization': 'Bearer ${await TokenService.getAccessToken()}',
      },
    );

    if (response.statusCode == 200) {
      return CustomerSubscription.fromJson(json.decode(response.body));
    } else {
      throw Exception('Failed to load subscription: ${response.statusCode}');
    }
  }
}