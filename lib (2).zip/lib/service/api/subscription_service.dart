import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:prayerunitesss/service/api/tokens/token_service.dart';
import 'package:prayerunitesss/utils/app_urls.dart';

class SubscriptionService {
  static Future<Map<String, dynamic>> getSubscriptionPlans() async {
    final response = await http.get(
      Uri.parse('${AppUrls().appUrl}/api/SubscriptionPlan/getAll'),
      headers: {
        'Content-Type': 'application/json',
        'Authorization': 'Bearer ${await TokenService.getAccessToken()}',
      },
    );

    if (response.statusCode == 200) {
      return json.decode(response.body);
    } else {
      throw Exception('Failed to load plans: ${response.statusCode}');
    }
  }

  static Future<dynamic> subscribeToPlan({
    required String customerId,
    required int planId,
  }) async {
    final response = await http.post(
      Uri.parse('${AppUrls().appUrl}/api/CustomerSubscription/create'),
      headers: {
        'Content-Type': 'application/json',
        'Authorization': 'Bearer ${await TokenService.getAccessToken()}',
      },
      body: json.encode({'userId': customerId, 'planId': planId}),
    );

    // Check if response is valid JSON
    try {
      final body = json.decode(response.body);
      return body; // This will work for structured responses like { "success": true, ... }
    } catch (e) {
      // Handle plain text response
      if (response.statusCode == 200 || response.statusCode == 201) {
        return {'message': response.body.trim()}; // Return message as map
      } else {
        throw Exception('Unexpected response: ${response.body}');
      }
    }
  }
}