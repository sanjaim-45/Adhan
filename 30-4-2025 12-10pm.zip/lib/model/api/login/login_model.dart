class LoginResponse {
  final String message;
  final LoginData data;

  LoginResponse({
    required this.message,
    required this.data,
  });

  factory LoginResponse.fromJson(Map<String, dynamic> json) {
    return LoginResponse(
      message: json['message'],
      data: LoginData.fromJson(json['data']),
    );
  }
}

class LoginData {
  final String customerId;

  LoginData({
    required this.customerId,
  });

  factory LoginData.fromJson(Map<String, dynamic> json) {
    return LoginData(
      customerId: json['customerId'].toString(),
    );
  }
}