import 'package:bottom_picker/resources/arrays.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:geolocator/geolocator.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:http/http.dart' as _httpClient;
import 'package:intl/intl.dart';
import 'package:bottom_picker/bottom_picker.dart';
import 'package:http/http.dart' as http;
import 'package:permission_handler/permission_handler.dart';
import 'package:prayerunitesss/utils/app_urls.dart';
import 'dart:convert';

import '../../../utils/font_mediaquery.dart';
import '../../widgets/prayer_card.dart';
import '../notification/notification_receiving_page.dart';
import '../subscription/upgrade.dart';

class PrayerTimesPage extends StatefulWidget {
  const PrayerTimesPage({super.key});

  @override
  State<PrayerTimesPage> createState() => _PrayerTimesPageState();
}

class _PrayerTimesPageState extends State<PrayerTimesPage> with AutomaticKeepAliveClientMixin {

  @override
  bool get wantKeepAlive => true;
  late http.Client _httpClient;

  DateTime selectedDate = DateTime.now();
  Map<String, String> prayerTimes = {};
  bool isLoading = true;
  String errorMessage = '';
  bool _locationPermissionDenied = false;

  @override
  void initState() {
    super.initState();
    _httpClient = http.Client();
    _fetchPrayerTimes();
  }

  Future<void> _showEnableLocationDialog(BuildContext context) async {
    return showDialog<void>(
      context: context,
      barrierDismissible: false,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text('Location Services Disabled'),
          content: SingleChildScrollView(
            child: ListBody(
              children: <Widget>[
                Text('To get accurate prayer times, please enable location services.'),
              ],
            ),
          ),
          actions: <Widget>[
            TextButton(
              child: Text('Cancel'),
              onPressed: () {
                Navigator.of(context).pop();
                setState(() {
                  errorMessage = 'Location services required for prayer times';
                });
              },
            ),
            TextButton(
              child: Text('Enable'),
              onPressed: () async {
                Navigator.of(context).pop();
                await Geolocator.openLocationSettings();
                // Retry after user enables location
                await Future.delayed(Duration(seconds: 1));
                _fetchPrayerTimes();
              },
            ),
          ],
        );
      },
    );
  }

  Future<void> _showPermissionDeniedDialog(BuildContext context) async {
    return showDialog<void>(
      context: context,
      barrierDismissible: false,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text('Location Permission Required'),
          content: SingleChildScrollView(
            child: ListBody(
              children: <Widget>[
                Text('Please grant location permission to get accurate prayer times.'),
              ],
            ),
          ),
          actions: <Widget>[
            TextButton(
              child: Text('Cancel'),
              onPressed: () {
                Navigator.of(context).pop();
                setState(() {
                  errorMessage = 'Location permission required for prayer times';
                });
              },
            ),
            TextButton(
              child: Text('Grant Permission'),
              onPressed: () async {
                Navigator.of(context).pop();
                await Geolocator.openAppSettings();
                // Retry after user grants permission
                await Future.delayed(Duration(seconds: 1));
                _fetchPrayerTimes();
              },
            ),
          ],
        );
      },
    );
  }

  Future<void> _fetchPrayerTimes() async {
    if (!mounted) return;

    setState(() {
      isLoading = true;
      errorMessage = '';
    });

    try {
      // Check if location service is enabled
      bool isLocationServiceEnabled = await Geolocator.isLocationServiceEnabled();
      if (!isLocationServiceEnabled) {
        setState(() {
          isLoading = false;
        });
        _showEnableLocationDialog(context);
        return;
      }

      // Check & request permission
      LocationPermission permission = await Geolocator.checkPermission();
      if (permission == LocationPermission.denied) {
        permission = await Geolocator.requestPermission();
        if (permission == LocationPermission.denied) {
          setState(() {
            isLoading = false;
            _locationPermissionDenied = true;
          });
          _showPermissionDeniedDialog(context);
          return;
        }
      }

      if (permission == LocationPermission.deniedForever) {
        setState(() {
          isLoading = false;
          _locationPermissionDenied = true;
        });
        _showPermissionDeniedDialog(context);
        return;
      }

      // Reset permission denied flag if we got here
      if (_locationPermissionDenied) {
        setState(() {
          _locationPermissionDenied = false;
        });
      }

      // Get current position
      Position position = await Geolocator.getCurrentPosition(
        desiredAccuracy: LocationAccuracy.high,
      );

      print("current latitude : ${position.latitude}");
      print("current longitude : ${position.longitude}");

      // Make API call
      final response = await _httpClient.post(
        Uri.parse('${AppUrls().appUrl}/api/PrayerTiming/GetPrayerTimings'),
        headers: {'Content-Type': 'application/json'},
        body: json.encode({
          "prayerDate": DateFormat('yyyy-MM-dd').format(selectedDate),
          "latitude": position.latitude,
          "longitude": position.longitude,
        }),
      );

      if (!mounted) return;

      if (response.statusCode == 200) {
        final data = json.decode(response.body);
        setState(() {
          prayerTimes = {
            'Fajr': data['fajr'],
            'Dhuhr': data['dhuhr'],
            'Asr': data['asr'],
            'Maghrib': data['maghrib'],
            'Isha': data['isha'],
          };
          isLoading = false;
        });
      } else {
        throw Exception('Failed to load prayer times');
      }
    } catch (e) {
      if (!mounted) return;
      setState(() {
        errorMessage = 'Failed to load prayer times. Please try again.';
        isLoading = false;
      });
    }
  }

  String getFormattedDate(DateTime date) {
    return DateFormat('dd EEE, MMMM yyyy').format(date);
  }

  void _goToPreviousDay() {
    setState(() {
      selectedDate = selectedDate.subtract(const Duration(days: 1));
      _fetchPrayerTimes();
    });
  }

  void _goToNextDay() {
    setState(() {
      selectedDate = selectedDate.add(const Duration(days: 1));
      _fetchPrayerTimes();
    });
  }

  void _pickDate(BuildContext context) {
    BottomPicker.date(
      pickerTitle: Text(
        'Set Prayer Date',
        style: GoogleFonts.beVietnamPro(
          fontWeight: FontWeight.bold,
          fontSize: getFontRegular55Size(context),
          letterSpacing: -0.5,
          color: Colors.black,
        ),
      ),
      dateOrder: DatePickerDateOrder.dmy,
      initialDateTime: selectedDate,
      pickerTextStyle: GoogleFonts.beVietnamPro(
        color: Colors.black,
        fontWeight: FontWeight.bold,
        fontSize: MediaQuery.of(context).size.width * 0.05,
      ),
      onSubmit: (pickedDate) {
        setState(() {
          selectedDate = pickedDate;
          _fetchPrayerTimes();
        });
      },
      onChange: (pickedDate) {
        print(pickedDate);
      },
      buttonStyle: BoxDecoration(
        color: Colors.blue,
        borderRadius: BorderRadius.circular(10),
        boxShadow: [
          BoxShadow(color: Colors.black26, blurRadius: 6, offset: Offset(0, 3)),
        ],
      ),
      buttonContent: Text(
        textAlign: TextAlign.center,
        "Done",
        style: GoogleFonts.beVietnamPro(
          color: Colors.white,
          fontWeight: FontWeight.bold,
          fontSize: 15,
        ),
      ),
      bottomPickerTheme: BottomPickerTheme.plumPlate,
    ).show(context);
  }

  String _getPrayerStatus(String prayerName) {
    final now = DateTime.now();

    // If viewing a date before today
    if (selectedDate.year < now.year ||
        (selectedDate.year == now.year && selectedDate.month < now.month) ||
        (selectedDate.year == now.year && selectedDate.month == now.month && selectedDate.day < now.day)) {
      return 'Completed';
    }

    // If viewing a date after today
    if (selectedDate.year > now.year ||
        (selectedDate.year == now.year && selectedDate.month > now.month) ||
        (selectedDate.year == now.year && selectedDate.month == now.month && selectedDate.day > now.day)) {
      return 'Upcoming';
    }

    // Only compare times if it's today's date
    try {
      final prayerTime = prayerTimes[prayerName]!;
      final prayerDateTime = DateFormat('HH:mm').parse(prayerTime);
      final prayerTimeToday = DateTime(
        now.year,
        now.month,
        now.day,
        prayerDateTime.hour,
        prayerDateTime.minute,
      );

      // Calculate absolute difference in minutes
      final differenceInMinutes = prayerTimeToday.difference(now).inMinutes.abs();
      final isAfterPrayerTime = now.isAfter(prayerTimeToday);

      if (isAfterPrayerTime) {
        // For times that have passed
        if (differenceInMinutes > 60) {
          return 'Completed'; // More than 1 hour passed
        } else {
          return 'Live'; // Within 1 hour after prayer time
        }
      } else {
        // For future times
        if (differenceInMinutes > 60) {
          return 'Upcoming'; // More than 1 hour before
        } else {
          return 'Live'; // Within 1 hour before prayer time
        }
      }
    } catch (e) {
      return 'Upcoming'; // Fallback in case of errors
    }
  }  Color _getStatusColor(String status) {
    switch (status) {
      case 'Completed':
        return Colors.green;
      case 'Live':
        return Colors.red;
      case 'Upcoming':
      default:
        return Color(0xFFA1812E);
    }
  }

  String _getImagePath(String prayerName) {
    switch (prayerName) {
      case 'Fajr':
        return "assets/images/cloud/Sunny.png";
      case 'Dhuhr':
        return "assets/images/cloud/Partly-cloudy.png";
      case 'Asr':
        return "assets/images/cloud/Cloudy-clear at times-night.png";
      case 'Maghrib':
        return "assets/images/cloud/Cloudy-clear at times.png";
      case 'Isha':
      default:
        return "assets/images/cloud/Clear-night.png";
    }
  }
  @override
  void dispose() {
    _httpClient.close(); // Cancel any pending requests
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    super.build(context);

    double screenHeight = MediaQuery.of(context).size.height;
    double screenWidth = MediaQuery.of(context).size.width;
    return Scaffold(
      appBar: PreferredSize(
        preferredSize: const Size.fromHeight(kToolbarHeight),
        child: AppBar(
          automaticallyImplyLeading: false,
          actions: [
            Row(
              children: [
                ElevatedButton(
                  onPressed: () {
                    Navigator.of(context).push(
                      MaterialPageRoute(
                        builder: (context) => SubscriptionPage(),
                      ),
                    );
                  },
                  style: ElevatedButton.styleFrom(
                    backgroundColor: const Color(0xFF2E7D32),
                    padding: const EdgeInsets.symmetric(
                      horizontal: 10,
                      vertical: 12,
                    ),
                  ),
                  child: Text(
                    "Upgrade",
                    style: GoogleFonts.beVietnamPro(
                      color: Colors.white,
                      letterSpacing: -0.5,
                      fontSize: getFontRegularSize(context),
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ),
                const SizedBox(width: 10),
                CircleAvatar(
                  maxRadius: getFontRegular55Size(context),
                  backgroundColor: Color(0xFFFBF7EB),
                  child: GestureDetector(
                    onTap: () {
                      Navigator.of(context).push(
                        MaterialPageRoute(
                          builder: (context) => NotificationReceivingPage(),
                        ),
                      );
                    },
                    child: Icon(
                      size: getFontRegular55Size(context),
                      Icons.notifications_none_outlined,
                      color: Colors.black,
                    ),
                  ),
                ),
                const SizedBox(width: 10),
              ],
            ),
          ],
          title: Text(
            'Prayer Times',
            style: GoogleFonts.beVietnamPro(
              fontSize: 24,
              fontWeight: FontWeight.bold,
            ),
          ),
          backgroundColor: Colors.white,
          elevation: 0,
          centerTitle: false,
        ),
      ),
      backgroundColor: Colors.white,
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.symmetric(vertical: 8),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 16),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Container(
                      width: screenWidth * 0.12,
                      height: screenHeight * 0.055,
                      decoration: BoxDecoration(
                        color: Colors.white.withOpacity(0.3),
                        borderRadius: BorderRadius.circular(5),
                        border: Border.all(
                          color: Colors.grey.withOpacity(0.2),
                          width: 1,
                        ),
                        boxShadow: [
                          BoxShadow(
                            color: Colors.grey.withOpacity(0.1),
                            spreadRadius: 2,
                            blurRadius: 5,
                            offset: const Offset(0, 0),
                          ),
                        ],
                      ),
                      child: IconButton(
                        icon: const Icon(Icons.arrow_back_ios_new, size: 18),
                        onPressed: _goToPreviousDay,
                        padding: EdgeInsets.zero,
                        constraints: BoxConstraints(),
                      ),
                    ),
                    GestureDetector(
                      onTap: () => _pickDate(context),
                      child: Text(
                        getFormattedDate(selectedDate),
                        style: GoogleFonts.beVietnamPro(fontSize: 16),
                      ),
                    ),
                    Container(
                      width: screenWidth * 0.12,
                      height: screenHeight * 0.055,
                      decoration: BoxDecoration(
                        color: Colors.white.withOpacity(0.3),
                        borderRadius: BorderRadius.circular(5),
                        border: Border.all(
                          color: Colors.grey.withOpacity(0.2),
                          width: 1,
                        ),
                        boxShadow: [
                          BoxShadow(
                            color: Colors.grey.withOpacity(0.1),
                            spreadRadius: 2,
                            blurRadius: 5,
                            offset: const Offset(0, 0),
                          ),
                        ],
                      ),
                      child: IconButton(
                        icon: const Icon(Icons.arrow_forward_ios, size: 18),
                        onPressed: _goToNextDay,
                      ),
                    ),
                  ],
                ),
              ),
              SizedBox(height: 5),
              Container(
                height: 1,
                decoration: BoxDecoration(
                  color: Colors.grey.withOpacity(0.1),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.grey.withOpacity(0.2),
                      spreadRadius: 1,
                      blurRadius: 7,
                      offset: const Offset(0, 4),
                    ),
                  ],
                ),
              ),
              Expanded(
                child: isLoading
                    ? Center(child: CircularProgressIndicator())
                    : errorMessage.isNotEmpty
                    ? Center(
                  child: Text(
                    errorMessage,
                    style: GoogleFonts.beVietnamPro(
                      color: Colors.red,
                      fontSize: 16,
                    ),
                  ),
                )
                    : ListView(
                  padding: EdgeInsets.only(top: 10),
                  children: [
                    PrayerCard(
                      imagePath: _getImagePath('Fajr'),
                      title: 'Fajr',
                      arabic: 'الفجر',
                      time: prayerTimes['Fajr'] ?? '--:--',
                      status: _getPrayerStatus('Fajr'),
                      statusColor: _getStatusColor(
                          _getPrayerStatus('Fajr')),
                      trailingIcon: Icons.notifications,
                    ),
                    PrayerCard(
                      imagePath: _getImagePath('Dhuhr'),
                      title: 'Dhuhr',
                      arabic: 'الظهر',
                      time: prayerTimes['Dhuhr'] ?? '--:--',
                      status: _getPrayerStatus('Dhuhr'),
                      statusColor: _getStatusColor(
                          _getPrayerStatus('Dhuhr')),
                      trailingIcon: Icons.notifications,
                    ),
                    PrayerCard(
                      imagePath: _getImagePath('Asr'),
                      title: 'Asr',
                      arabic: 'العصر',
                      time: prayerTimes['Asr'] ?? '--:--',
                      status: _getPrayerStatus('Asr'),
                      statusColor:
                      _getStatusColor(_getPrayerStatus('Asr')),
                    ),
                    PrayerCard(
                      imagePath: _getImagePath('Maghrib'),
                      title: 'Maghrib',
                      arabic: 'المغرب',
                      time: prayerTimes['Maghrib'] ?? '--:--',
                      status: _getPrayerStatus('Maghrib'),
                      statusColor: _getStatusColor(
                          _getPrayerStatus('Maghrib')),
                    ),
                    PrayerCard(
                      imagePath: _getImagePath('Isha'),
                      title: 'Isha',
                      arabic: 'العشاء',
                      time: prayerTimes['Isha'] ?? '--:--',
                      status: _getPrayerStatus('Isha'),
                      statusColor:
                      _getStatusColor(_getPrayerStatus('Isha')),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}void _showEnableLocationDialog(BuildContext context) {
  showDialog(
    context: context,
    builder: (context) => AlertDialog(
      title: const Text('Location Services Disabled'),
      content: const Text('Please enable location services to get accurate prayer times.'),
      actions: [
        TextButton(
          onPressed: Navigator.of(context).pop,
          child: const Text('Cancel'),
        ),
        TextButton(
          onPressed: () async {
            Navigator.of(context).pop();
            // Open app settings
            await openAppSettings();
            // Optionally, re-fetch prayer times after returning
            // _fetchPrayerTimes();
          },
          child: const Text('Open Settings'),
        ),
        TextButton(
          onPressed: () async {
            Navigator.of(context).pop();
            await Geolocator.openLocationSettings();
            // Optionally, re-fetch prayer times after returning
            // _fetchPrayerTimes();
          },
          child: const Text('Enable Location'),
        ),
      ],
    ),
  );
}