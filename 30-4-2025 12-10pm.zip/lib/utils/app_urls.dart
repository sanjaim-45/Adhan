class AppUrls{
  final appUrl = "http://192.168.0.118:8085";
}