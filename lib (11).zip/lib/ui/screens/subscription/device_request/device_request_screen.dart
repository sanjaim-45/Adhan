import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

import '../../../../utils/font_mediaquery.dart';
import 'add_new_address.dart';
import 'order_placed.dart';

class DeviceRequestScreen extends StatefulWidget {
  const DeviceRequestScreen({super.key});

  @override
  State<DeviceRequestScreen> createState() => _DeviceRequestScreenState();
}

class _DeviceRequestScreenState extends State<DeviceRequestScreen> {
  List<String?> selectedMasjids = [null];
  List<String?> selectedPlans = [null]; // Added to store selected plans
  final List<String> masjidList = ['Masjid A', 'Masjid B', 'Masjid C'];
  int currentStep = 0;
  List<Map<String, dynamic>> savedAddresses = [];
  Map<String, dynamic>? selectedAddress;
  String? selectedPaymentMethod;

  void addDevice() {
    setState(() {
      selectedMasjids.add(null);
      selectedPlans.add(null); // Add null for the new device's plan
    });
  }

  void updateMasjid(int index, String? value) {
    setState(() {
      selectedMasjids[index] = value;
      selectedPlans[index] = null; // Reset plan when masjid changes
    });
  }

  void updatePlan(int index, String? value) {
    setState(() {
      selectedPlans[index] = value;
    });
  }

  void nextStep() {
    if (currentStep == 0) {
      // Check if any masjid is selected but its corresponding plan is not
      if (selectedMasjids.asMap().entries.any(
        (entry) => entry.value != null && selectedPlans[entry.key] == null,
      )) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Please select a plan for all selected devices'),
          ),
        );
      } else if (selectedMasjids.any((masjid) => masjid != null)) {
        // Proceed if at least one masjid with a plan is selected
        setState(() {
          currentStep++;
        });
      }
      // If no masjids are selected, do nothing or show a different message if needed
    } else if (currentStep == 1 && selectedAddress != null) {
      setState(() {
        currentStep++;
        selectedPaymentMethod = 'KNET'; // Default payment method
      });
    } else if (currentStep == 1) {
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(const SnackBar(content: Text('Please add an address')));
    } else if (currentStep == 2 && selectedPaymentMethod != null) {
      Navigator.of(
        context,
      ).push(MaterialPageRoute(builder: (context) => OrderPlaced()));
    }
  }

  void previousStep() {
    if (currentStep > 0) {
      setState(() {
        currentStep--;
      });
    }
  }

  Future<void> _addNewAddress() async {
    final newAddress = await Navigator.of(
      context,
    ).push(MaterialPageRoute(builder: (context) => const AddNewAddressPage()));

    if (newAddress != null) {
      setState(() {
        savedAddresses.add(newAddress);
        selectedAddress = newAddress;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: PreferredSize(
        preferredSize: const Size.fromHeight(80),
        child: Container(
          decoration: BoxDecoration(
            color: Colors.white,
            boxShadow: [
              BoxShadow(
                color: Colors.grey.withOpacity(0.1),
                spreadRadius: 1,
                blurRadius: 8,
                offset: const Offset(0, 4),
              ),
            ],
          ),
          child: Padding(
            padding: const EdgeInsets.only(top: 20.0),
            child: AppBar(
              backgroundColor: Colors.white,
              elevation: 0,
              leadingWidth: 70,
              leading: Padding(
                padding: const EdgeInsets.only(left: 10.0),
                child: GestureDetector(
                  onTap: () => Navigator.of(context).pop(),
                  child: Container(
                    margin: const EdgeInsets.all(10),
                    decoration: BoxDecoration(
                      border: Border.all(
                        width: 1,
                        color: Colors.grey.withOpacity(0.5),
                      ),
                      borderRadius: BorderRadius.circular(5),
                    ),
                    width: 40,
                    height: 15,
                    child: const Icon(
                      Icons.arrow_back_ios_new_rounded,
                      size: 15,
                      color: Colors.black,
                    ),
                  ),
                ),
              ),
              title: Padding(
                padding: const EdgeInsets.only(top: 0.0),
                child: Text(
                  'Device Request',
                  style: GoogleFonts.beVietnamPro(
                    color: Colors.black,
                    letterSpacing: -0.5,
                    fontSize: getDynamicFontSize(context, 0.05),
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
            ),
          ),
        ),
      ),
      body: Column(
        children: [
          const SizedBox(height: 8),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Expanded(
                  child: _StepperItem(
                    label: 'Devices',
                    isActive: currentStep >= 0,
                    isCompleted: currentStep > 0,
                  ),
                ),

                _DottedLine(isActive: currentStep > 0),
                Expanded(
                  child: _StepperItem(
                    label: 'Address',
                    isActive: currentStep >= 1,
                    isCompleted: currentStep > 1,
                  ),
                ),
                _DottedLine(isActive: currentStep > 1),
                Expanded(
                  child: _StepperItem(
                    label: 'Checkout',
                    isActive: currentStep >= 2,
                    isCompleted: false,
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 16),
          Expanded(
            child: SingleChildScrollView(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: _getStepContent(currentStep),
            ),
          ),
        ],
      ),
      bottomNavigationBar: Container(
        padding: const EdgeInsets.all(16),
        color: Colors.white,
        child: Row(
          children: [
            Expanded(
              child: SizedBox(
                height: 50,
                child: ElevatedButton(
                  onPressed: nextStep,
                  style: ElevatedButton.styleFrom(
                    backgroundColor: const Color(0xFF2E7D32),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12),
                    ),
                  ),
                  child: Text(
                    currentStep == 2 ? 'Place Order' : 'Continue',
                    style: const TextStyle(fontSize: 16, color: Colors.white),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _getStepContent(int step) {
    switch (step) {
      case 0:
        return Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              'Request Speaker Devices',
              style: TextStyle(fontWeight: FontWeight.w600, fontSize: 16),
            ),
            const SizedBox(height: 12),
            ...List.generate(selectedMasjids.length, (index) {
              return Padding(
                padding: const EdgeInsets.only(bottom: 12),
                child: Container(
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(12),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black.withOpacity(0.05),
                        blurRadius: 8,
                        offset: const Offset(0, 2),
                      ),
                    ],
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'Device ${index + 1}',
                        style: const TextStyle(
                          fontWeight: FontWeight.w600,
                          color: Color(0xFF2E7D32),
                          fontSize: 16,
                        ),
                      ),
                      const SizedBox(height: 12),
                      const Text(
                        'Masjid',
                        style: TextStyle(fontWeight: FontWeight.w500),
                      ),
                      const SizedBox(height: 8),
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 12),
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(10),
                          border: Border.all(color: Colors.grey.shade300),
                        ),
                        child: DropdownButtonFormField<String>(
                          dropdownColor: Colors.white,
                          hint: const Text('Select Masjid'),
                          value: selectedMasjids[index],
                          items:
                              masjidList.map((masjid) {
                                return DropdownMenuItem(
                                  value: masjid,
                                  child: Text(masjid),
                                );
                              }).toList(),
                          onChanged: (value) => updateMasjid(index, value),
                          decoration: const InputDecoration(
                            border: InputBorder.none,
                          ),
                        ),
                      ),
                      if (selectedMasjids[index] != null) ...[
                        const SizedBox(height: 12),
                        const Text(
                          'Plan',
                          style: TextStyle(fontWeight: FontWeight.w500),
                        ),
                        const SizedBox(height: 8),
                        Container(
                          padding: const EdgeInsets.symmetric(horizontal: 12),
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(10),
                            border: Border.all(color: Colors.grey.shade300),
                          ),
                          child: DropdownButtonFormField<String>(
                            dropdownColor: Colors.white,

                            hint: const Text('Select Plan'),
                            value: selectedPlans[index],
                            items:
                                ['Yearly', 'Monthly', 'Quarterly'].map((plan) {
                                  return DropdownMenuItem(
                                    value: plan,
                                    child: Text(plan),
                                  );
                                }).toList(),
                            onChanged: (value) => updatePlan(index, value),
                            decoration: const InputDecoration(
                              border: InputBorder.none,
                            ),
                          ),
                        ),
                      ],
                    ],
                  ),
                ),
              );
            }),
            GestureDetector(
              onTap: addDevice,
              child: const Row(
                children: [
                  Icon(Icons.add, color: Color(0xFF2E7D32)),
                  SizedBox(width: 4),
                  Text(
                    'Add Another Device',
                    style: TextStyle(
                      color: Color(0xFF2E7D32),
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ],
              ),
            ),
          ],
        );
      case 1:
        return Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              'Add Address',
              style: TextStyle(fontWeight: FontWeight.w600, fontSize: 16),
            ),
            const SizedBox(height: 12),

            if (selectedAddress != null)
              Container(
                padding: const EdgeInsets.all(16),
                margin: const EdgeInsets.only(bottom: 16),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(12),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.black.withOpacity(0.05),
                      blurRadius: 8,
                      offset: const Offset(0, 2),
                    ),
                  ],
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Column(
                      children: [
                        MosqueTiles(
                          isSelected: true,
                          mosqueName: selectedAddress!['address'] ?? '',
                          email: selectedAddress!['email'] ?? '',
                          onTap: () {
                            // Handle selection logic here
                          },
                          mobileNumber: selectedAddress!['mobileNumber'] ?? '',
                          name: selectedAddress!['fullName'] ?? '',
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            if (savedAddresses.length > 1)
              Column(
                children:
                    savedAddresses.map((address) {
                      if (address == selectedAddress) return const SizedBox();
                      return GestureDetector(
                        onTap: () {
                          setState(() {
                            selectedAddress = address;
                          });
                        },
                        child: Container(
                          padding: const EdgeInsets.all(16),
                          margin: const EdgeInsets.only(bottom: 8),
                          decoration: BoxDecoration(
                            color: Colors.white,
                            borderRadius: BorderRadius.circular(12),
                            border: Border.all(
                              color:
                                  selectedAddress == address
                                      ? const Color(0xFF2E7D32)
                                      : Colors.grey.shade300,
                              width: 1.5,
                            ),
                          ),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                address['fullName'],
                                style: TextStyle(
                                  fontWeight: FontWeight.w600,
                                  fontSize: 16,
                                  color:
                                      selectedAddress == address
                                          ? const Color(0xFF2E7D32)
                                          : Colors.black,
                                ),
                              ),
                              const SizedBox(height: 8),
                              Text(address['address']),
                              if (address['isDefault'])
                                const Padding(
                                  padding: EdgeInsets.only(top: 8.0),
                                  child: Text(
                                    'Default Address',
                                    style: TextStyle(
                                      color: Color(0xFF2E7D32),
                                      fontWeight: FontWeight.w500,
                                    ),
                                  ),
                                ),
                            ],
                          ),
                        ),
                      );
                    }).toList(),
              ),
            Container(
              margin: const EdgeInsets.only(top: 16),
              padding: const EdgeInsets.symmetric(vertical: 16, horizontal: 8),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(12),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withOpacity(0.05),
                    blurRadius: 8,
                    offset: const Offset(0, 2),
                  ),
                ],
              ),
              child: GestureDetector(
                onTap: _addNewAddress,
                child: const Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Icon(Icons.add, color: Color(0xFF2E7D32)),
                    SizedBox(width: 4),
                    Text(
                      'Add New Address',
                      style: TextStyle(
                        color: Color(0xFF2E7D32),
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ],
                ),
              ),
            ),
            if (selectedMasjids.any((masjid) => masjid != null))
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisAlignment: MainAxisAlignment.start,
                children: [
                  const SizedBox(height: 16),
                  const Text(
                    'Device Price Details',
                    style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
                  ),
                  const SizedBox(height: 8),
                  Container(
                    padding: const EdgeInsets.all(16),
                    decoration: BoxDecoration(
                      boxShadow: [
                        BoxShadow(
                          color: Colors.black.withOpacity(0.05),
                          blurRadius: 8,
                          offset: const Offset(0, 2),
                        ),
                      ],
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(12),
                    ),
                    margin: const EdgeInsets.only(bottom: 16),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        ...selectedMasjids
                            .asMap()
                            .entries
                            .where((entry) => entry.value != null)
                            .map((masjidEntry) {
                              final plan = selectedPlans[masjidEntry.key];
                              double devicePrice = 0.0;
                              if (plan == 'Yearly') {
                                devicePrice = 100.00;
                              } else if (plan == 'Monthly') {
                                devicePrice = 10.00;
                              } else if (plan == 'Quarterly') {
                                devicePrice = 25.00;
                              }

                              return Padding(
                                padding: const EdgeInsets.symmetric(
                                  vertical: 4.0,
                                ),
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Row(
                                      mainAxisAlignment:
                                          MainAxisAlignment.spaceBetween,
                                      children: [
                                        Text(
                                          'Device ${masjidEntry.key + 1} ($plan)',
                                          style: const TextStyle(
                                            color: Color(0xFF2E7D32),
                                          ),
                                        ),
                                        Text(
                                          '${devicePrice.toStringAsFixed(2)} KWD ',
                                        ),
                                      ],
                                    ),
                                    const SizedBox(height: 2),
                                    Text(
                                      masjidEntry.value ?? '',
                                      style: const TextStyle(
                                        color: Colors.grey,
                                      ),
                                    ),
                                  ],
                                ),
                              );
                            })
                            .toList(),
                        const Divider(
                          height: 20,
                          thickness: 1,
                          color: Color(0xFFDBDBDB),
                        ),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            const Text(
                              'Total',
                              style: TextStyle(
                                fontWeight: FontWeight.bold,
                                fontSize: 16,
                              ),
                            ),
                            Text(
                              '${selectedMasjids.asMap().entries.where((entry) => entry.value != null).fold<double>(0.0, (sum, masjidEntry) {
                                final plan = selectedPlans[masjidEntry.key];
                                if (plan == 'Yearly') {
                                  return sum + 100.00;
                                } else if (plan == 'Monthly') {
                                  return sum + 10.00;
                                } else if (plan == 'Quarterly') {
                                  return sum + 25.00;
                                }
                                return sum;
                              }).toStringAsFixed(2)} KWD',
                              style: const TextStyle(
                                fontWeight: FontWeight.bold,
                                fontSize: 16,
                              ),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                ],
              ),
          ],
        );
      case 2:
        return Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(12),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withOpacity(0.05),
                    blurRadius: 8,
                    offset: const Offset(0, 2),
                  ),
                ],
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  if (selectedAddress != null)
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Text(
                          'Add Address',
                          style: TextStyle(
                            fontWeight: FontWeight.w600,
                            fontSize: 16,
                          ),
                        ),
                        const SizedBox(height: 12),
                        MosqueTiles(
                          isSelected: true,
                          mosqueName: selectedAddress!['address'] ?? '',
                          email: selectedAddress!['email'] ?? '',
                          onTap: () {
                            // Handle selection logic here
                          },
                          mobileNumber: selectedAddress!['mobileNumber'] ?? '',
                          name: selectedAddress!['fullName'] ?? '',
                        ),
                      ],
                    ),
                ],
              ),
            ),
            const SizedBox(height: 16),
            if (selectedMasjids.any((masjid) => masjid != null))
              Container(
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  boxShadow: [
                    BoxShadow(
                      color: Colors.black.withOpacity(0.05),
                      blurRadius: 8,
                      offset: const Offset(0, 2),
                    ),
                  ],
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(12),
                ),
                margin: const EdgeInsets.only(bottom: 16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text(
                      'Device Price Details',
                      style: TextStyle(
                        fontWeight: FontWeight.bold,
                        fontSize: 16,
                      ),
                    ),
                    const SizedBox(height: 8),
                    ...selectedMasjids
                        .asMap()
                        .entries
                        .where((entry) => entry.value != null)
                        .map((masjidEntry) {
                          final plan = selectedPlans[masjidEntry.key];
                          double devicePrice = 0.0;
                          if (plan == 'Yearly') {
                            devicePrice = 100.00;
                          } else if (plan == 'Monthly') {
                            devicePrice = 10.00;
                          } else if (plan == 'Quarterly') {
                            devicePrice = 25.00;
                          }
                          return Padding(
                            padding: const EdgeInsets.symmetric(vertical: 4.0),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Row(
                                  mainAxisAlignment:
                                      MainAxisAlignment.spaceBetween,
                                  children: [
                                    Text(
                                      'Device ${masjidEntry.key + 1} ($plan)',
                                      style: const TextStyle(
                                        color: Color(0xFF2E7D32),
                                      ),
                                    ),
                                    Text(
                                      '${devicePrice.toStringAsFixed(2)} KWD ',
                                    ),
                                  ],
                                ),
                                const SizedBox(height: 2),
                                Text(
                                  masjidEntry.value ?? '',
                                  style: const TextStyle(color: Colors.grey),
                                ),
                              ],
                            ),
                          );
                        })
                        .toList(),
                    const Divider(
                      height: 20,
                      thickness: 1,
                      color: Color(0xFFDBDBDB),
                    ),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        const Text(
                          'Total',
                          style: TextStyle(
                            fontWeight: FontWeight.bold,
                            fontSize: 16,
                          ),
                        ),
                        Text(
                          '${selectedMasjids.asMap().entries.where((entry) => entry.value != null).fold<double>(0.0, (sum, masjidEntry) {
                            final plan = selectedPlans[masjidEntry.key];
                            if (plan == 'Yearly') {
                              return sum + 100.00;
                            } else if (plan == 'Monthly') {
                              return sum + 10.00;
                            } else if (plan == 'Quarterly') {
                              return sum + 25.00;
                            }
                            return sum;
                          }).toStringAsFixed(2)} KWD',
                          style: const TextStyle(
                            fontWeight: FontWeight.bold,
                            fontSize: 16,
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(12),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withOpacity(0.05),
                    blurRadius: 8,
                    offset: const Offset(0, 2),
                  ),
                ],
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text(
                    'Payment Method',
                    style: TextStyle(fontWeight: FontWeight.w600, fontSize: 16),
                  ),
                  const SizedBox(height: 12),
                  RadioListTile<String>(
                    title: const Text('KNET (Online Payment)'),
                    value: 'KNET',
                    groupValue: selectedPaymentMethod,
                    onChanged: (value) {
                      setState(() {
                        selectedPaymentMethod = value;
                      });
                    },
                    activeColor: const Color(0xFF2E7D32),
                  ),
                  RadioListTile<String>(
                    title: const Text('Offline Payment'),
                    value: 'Offline',
                    groupValue: selectedPaymentMethod,
                    onChanged: (value) {
                      setState(() {
                        selectedPaymentMethod = value;
                      });
                    },
                    activeColor: const Color(0xFF2E7D32),
                  ),
                ],
              ),
            ),
            const SizedBox(
              height: 16,
            ), // Add some space before the bottom navigation bar
            const SizedBox(height: 16),
          ],
        );
      default:
        return Container();
    }
  }
}

class _StepperItem extends StatelessWidget {
  final String label;
  final bool isActive;
  final bool isCompleted;

  const _StepperItem({
    required this.label,
    this.isActive = false,
    this.isCompleted = false,
  });

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Text(
          label,
          style: TextStyle(
            fontSize: 12,
            fontWeight: FontWeight.w500,
            color: isActive ? Colors.black : Colors.grey,
          ),
        ),
        const SizedBox(height: 12), // Increased space here
        Container(
          padding:
              isCompleted
                  ? const EdgeInsets.all(0)
                  : const EdgeInsets.all(5), // No padding for completed
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            border:
                isCompleted
                    ? null
                    : Border.all(
                      color:
                          isActive
                              ? const Color(0xFF2E7D32)
                              : Colors.grey.shade300,
                      width: 1,
                    ),
          ),
          child:
              isCompleted
                  ? const CircleAvatar(
                    radius: 11,
                    backgroundColor: Color(0xFF2E7D32),
                    child: Icon(Icons.check, size: 10, color: Colors.white),
                  )
                  : CircleAvatar(
                    radius: 6,
                    backgroundColor:
                        isActive
                            ? const Color(0xFF2E7D32)
                            : Colors.grey.shade300,
                  ),
        ),
      ],
    );
  }
}

class _DottedLine extends StatelessWidget {
  final bool isActive;

  const _DottedLine({required this.isActive});

  @override
  Widget build(BuildContext context) {
    const lineHeight = 1.0;
    return Expanded(
      child: Padding(
        // Adjusted padding to align with the center of the CircleAvatar in _StepperItem
        padding: const EdgeInsets.only(
          top: 35.0,
        ), // Approximate vertical center of the dot/tick
        child: SizedBox(
          height: lineHeight, // Height of the line container
          child: CustomPaint(
            // The line itself
            painter: DottedLinePainter(isActive: isActive),
          ),
        ),
      ),
    );
  }
}

class DottedLinePainter extends CustomPainter {
  final bool isActive;
  DottedLinePainter({required this.isActive});

  @override
  void paint(Canvas canvas, Size size) {
    final paint =
        Paint()
          ..color = isActive ? const Color(0xFF2E7D32) : Colors.grey.shade300
          ..strokeWidth = 1.5
          ..strokeCap = StrokeCap.round;

    const dashWidth = 4;
    const dashSpace = 4;
    double startX = 0;

    while (startX < size.width) {
      // Draw line in the vertical center of the available space (size.height)
      canvas.drawLine(
        Offset(startX, size.height / 2),
        Offset(startX + dashWidth, size.height / 2),
        paint,
      );
      startX += dashWidth + dashSpace;
    }
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}

class MosqueTiles extends StatelessWidget {
  final bool isSelected;
  final String mosqueName;
  final String name;
  final String email;
  final String mobileNumber;
  final VoidCallback onTap;

  const MosqueTiles({
    Key? key,
    required this.isSelected,
    required this.mosqueName,
    required this.email,
    required this.onTap,
    required this.mobileNumber,
    required this.name,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(12),
      child: Container(
        child: Row(
          mainAxisAlignment: MainAxisAlignment.start,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Radio(
              value: true,
              groupValue: isSelected,
              onChanged: (_) => onTap(),
              activeColor: Colors.green,
            ),
            const SizedBox(width: 8),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    name,
                    style: TextStyle(color: Colors.black54, fontSize: 14),
                  ),
                  const SizedBox(height: 4),

                  Text(
                    mosqueName,
                    style: TextStyle(
                      fontWeight: FontWeight.w500,
                      color: Colors.black87,
                    ),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    email,
                    style: TextStyle(color: Colors.black54, fontSize: 14),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    mobileNumber,
                    style: TextStyle(color: Colors.black54, fontSize: 14),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
