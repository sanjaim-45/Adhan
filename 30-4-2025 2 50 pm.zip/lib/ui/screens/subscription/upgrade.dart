import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

import '../../../providers/auth_providers.dart';

class SubscriptionPage extends StatefulWidget {
  const SubscriptionPage({super.key});

  @override
  State<SubscriptionPage> createState() => _SubscriptionPageState();
}

class _SubscriptionPageState extends State<SubscriptionPage> {
  String selectedPlan = 'Monthly Plan'; // Default selected plan
  String selectedPlanId = 'plan_monthly'; // Default plan ID
  String customerId = 'cust_12345'; // Example customer ID - in real app, get from auth provider

  // Map to store plan details
  final Map<String, Map<String, dynamic>> plans = {
    'Monthly Plan': {
      'id': 'plan_monthly',
      'price': '10 KWD',
      'duration': 'month',
      'tag': 'Recommended'
    },
    'Quarterly Plan': {
      'id': 'plan_quarterly',
      'price': '20 KWD',
      'duration': '3 months',
      'tag': 'Best'
    },
    'Yearly Plan': {
      'id': 'plan_yearly',
      'price': '90 KWD',
      'duration': 'year',
      'tag': 'Best'
    },
  };

  Future<void> _subscribeToPlan() async {
    // Show loading indicator
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (context) => Center(child: CircularProgressIndicator()),
    );

    try {
      // Simulate API call delay
      await Future.delayed(Duration(seconds: 2));

      // In a real app, you would call your subscription API here
      // await SubscriptionService.subscribe(customerId: customerId, planId: selectedPlanId);

      // Close loading dialog
      Navigator.of(context).pop();

      // Show success message
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Subscription successful! Plan activated.'),
          backgroundColor: Colors.green,
        ),
      );

      // You might want to update user's subscription status in your auth provider
      // Provider.of<AuthProvider>(context, listen: false).updateSubscriptionStatus(true);

    } catch (e) {
      // Close loading dialog
      Navigator.of(context).pop();

      // Show error message
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Subscription failed: ${e.toString()}'),
          backgroundColor: Colors.red,
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    final authProvider = Provider.of<AuthProvider>(context);
    // In a real app, you might get customerId from auth provider
    // customerId = authProvider.user?.id ?? '';

    return Scaffold(
      backgroundColor: Colors.white,
      body: Column(
        children: [
          Expanded(
            child: ListView(
              children: [
                Stack(
                  children: [
                    Image.asset("assets/images/upgrade/upgrade_top.png"),
                    Positioned(
                      top: 40,
                      left: 16,
                      child: GestureDetector(
                        onTap: () => Navigator.pop(context),
                        child: Container(
                          margin: EdgeInsets.only(top: 10),
                          padding: EdgeInsets.all(8),
                          decoration: BoxDecoration(
                            color: Colors.transparent,
                            borderRadius: BorderRadius.circular(5),
                            border: Border.all(
                              color: Colors.grey.withOpacity(0.2),
                              width: 1,
                            ),
                          ),
                          child: Icon(Icons.arrow_back_ios_new),
                        ),
                      ),
                    ),
                  ],
                ),
                Column(
                  children: [
                    Column(
                      children: [
                        RichText(
                          textAlign: TextAlign.center,
                          text: TextSpan(
                            style: GoogleFonts.beVietnamPro(
                              fontSize: 25,
                              fontWeight: FontWeight.bold,
                              height: 1.5,
                              color: Colors.black,
                            ),
                            children: [
                              TextSpan(text: 'Your '),
                              TextSpan(
                                text: 'Masjid',
                                style: GoogleFonts.beVietnamPro(color: Color(0xFFA1812E)),
                              ),
                              TextSpan(text: '. Your\n'),
                              TextSpan(
                                text: 'Connection',
                                style: GoogleFonts.beVietnamPro(color: Color(0xFF2E7D32)),
                              ),
                              TextSpan(text: '. Your Time'),
                            ],
                          ),
                        ),

                        SizedBox(height: 10),
                        Text(
                          'Join Saut Al-Salaah for premium live audio streaming.\nStay connected to your masjid anytime, anywhere.\nSubscribe today.',
                          style: GoogleFonts.beVietnamPro(color: Colors.grey[600]),
                          textAlign: TextAlign.center,
                        ),
                      ],
                    ),
                    authProvider.isDemoUser
                        ? Padding(
                      padding: const EdgeInsets.all(16.0),
                      child: Container(
                        padding: EdgeInsets.all(16),
                        decoration: BoxDecoration(
                          gradient: LinearGradient(
                            colors: [Color(0xFF4CAF50), Color(0xFF006400)],
                            begin: Alignment.topLeft,
                            end: Alignment.bottomRight,
                          ),
                          borderRadius: BorderRadius.circular(12),
                        ),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Container(
                                  padding: EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                                  decoration: BoxDecoration(
                                    color: Colors.white.withOpacity(0.2),
                                    borderRadius: BorderRadius.circular(6),
                                  ),
                                  child: Text(
                                    'My Current Plan',
                                    style: GoogleFonts.beVietnamPro(
                                      color: Colors.white,
                                    ),
                                  ),
                                ),
                                Text.rich(
                                  TextSpan(
                                    children: [
                                      TextSpan(
                                        text: 'Expires on:',
                                        style: GoogleFonts.beVietnamPro(
                                          color: Colors.white,
                                        ),
                                      ),
                                      TextSpan(
                                        text: ' 25 Apr 2024',
                                        style: GoogleFonts.beVietnamPro(
                                          color: Color(0xFFF4DE8B),
                                          fontWeight: FontWeight.normal,
                                        ),
                                      ),
                                    ],
                                  ),
                                )],
                            ),
                            SizedBox(height: 15),
                            Text(
                              'Monthly',
                              style: GoogleFonts.beVietnamPro(
                                color: Colors.white,
                                fontSize: 14,
                              ),
                            ),
                            SizedBox(height: 5),
                            RichText(
                              text: TextSpan(
                                children: [
                                  TextSpan(
                                    text: '1000 KWD',
                                    style: GoogleFonts.beVietnamPro(
                                      color: Colors.white,
                                      fontSize: 18,
                                      fontWeight: FontWeight.bold,
                                    ),
                                  ),
                                  TextSpan(
                                    text: ' / month',
                                    style: GoogleFonts.beVietnamPro(
                                      color: Colors.white,
                                      fontSize: 14,
                                      fontWeight: FontWeight.normal,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                      ),
                    )
                        : SizedBox(height: 20),
                    // Subscription cards
                    ...plans.entries.map((entry) {
                      final planName = entry.key;
                      final planDetails = entry.value;
                      return Padding(
                        padding: EdgeInsets.symmetric(horizontal: 16),
                        child: SubscriptionCard(
                          title: planName,
                          price: planDetails['price'],
                          duration: planDetails['duration'],
                          tag: planDetails['tag'],
                          selected: selectedPlan == planName,
                          onTap: () {
                            setState(() {
                              selectedPlan = planName;
                              selectedPlanId = planDetails['id'];
                            });
                          },
                        ),
                      );
                    }).toList(),
                    SizedBox(height: 20),
                    Container(
                      padding: EdgeInsets.all(16),
                      margin: EdgeInsets.symmetric(horizontal: 16),
                      decoration: BoxDecoration(
                        color: Colors.yellow[50],
                        borderRadius: BorderRadius.circular(10),
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            "Features Unlocks",
                            style: GoogleFonts.beVietnamPro(
                              fontWeight: FontWeight.bold,
                              fontSize: 20,
                            ),
                          ),
                          SizedBox(height: 5),
                          Row(
                            children: [
                              Icon(Icons.check_circle, color: Colors.green),
                              SizedBox(width: 10),
                              Text(
                                  'Full access to live prayer audio',
                                  style: GoogleFonts.beVietnamPro(fontWeight: FontWeight.w600)),
                            ],
                          ),
                          SizedBox(height: 5),
                          Row(
                            children: [
                              Icon(Icons.check_circle, color: Colors.green),
                              SizedBox(width: 10),
                              Text(
                                  'Prayer notifications & reminders',
                                  style: GoogleFonts.beVietnamPro(fontWeight: FontWeight.w600)),
                            ],
                          ),
                          SizedBox(height: 5),
                          Row(
                            children: [
                              Icon(Icons.check_circle, color: Colors.green),
                              SizedBox(width: 10),
                              Text(
                                  'Priority updates',
                                  style: GoogleFonts.beVietnamPro(fontWeight: FontWeight.w600)),
                            ],
                          ),
                        ],
                      ),
                    ),
                    SizedBox(height: 20),
                  ],
                ),
              ],
            ),
          ),
          // Bottom CTA
          Container(
            padding: EdgeInsets.symmetric(horizontal: 16, vertical: 12),
            decoration: BoxDecoration(
              color: Colors.white,
              boxShadow: [BoxShadow(color: Colors.black12, blurRadius: 5)],
            ),
            child: Row(
              children: [
                Expanded(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.start,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                          plans[selectedPlan]?['duration'] ?? '3 months',
                          style: GoogleFonts.beVietnamPro(color: Color(0xFF2E7D32))),
                      Text(
                        plans[selectedPlan]?['price'] ?? '10KWD',
                        style: GoogleFonts.beVietnamPro(
                          fontWeight: FontWeight.bold,
                          fontSize: 20,
                        ),
                      ),
                    ],
                  ),
                ),
                ElevatedButton.icon(
                  onPressed: _subscribeToPlan,
                  icon: Image.asset(
                    "assets/images/upgrade/king.png",
                    height: 20,
                    width: 20,
                  ),
                  label: Text(
                      'Subscribe',
                      style: GoogleFonts.beVietnamPro(color: Colors.white)),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Color(0xFF2E7D32),
                    padding: EdgeInsets.symmetric(horizontal: 24, vertical: 16),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12),
                    ),
                  ),
                ),
              ],
            ),
          ),
          SizedBox(height: MediaQuery.of(context).size.height * 0.01),
        ],
      ),
    );
  }
}

class SubscriptionCard extends StatelessWidget {
  final String title;
  final String price;
  final String duration;
  final String tag;
  final bool selected;
  final VoidCallback? onTap;

  const SubscriptionCard({
    Key? key,
    required this.title,
    required this.price,
    required this.duration,
    required this.tag,
    this.selected = false,
    this.onTap,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Card(
        color: Colors.white,
        elevation: selected ? 3 : 0,
        shape: RoundedRectangleBorder(
          side: selected
              ? BorderSide(color: Color(0xFF2E7D32), width: 2)
              : BorderSide(color: Colors.grey[300]!),
          borderRadius: BorderRadius.circular(12),
        ),
        margin: EdgeInsets.only(bottom: 16),
        child: Padding(
          padding: EdgeInsets.all(16),
          child: Row(
            children: [
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Container(
                      padding: EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                      decoration: BoxDecoration(
                        color: Color(0xFFA1812E),
                        borderRadius: BorderRadius.circular(4),
                      ),
                      child: Text(
                          tag,
                          style: GoogleFonts.beVietnamPro(color: Colors.white, fontSize: 12)),
                    ),
                    SizedBox(height: 8),
                    Text(
                      title,
                      style: GoogleFonts.beVietnamPro(
                        color: Color(0xFF2E7D32),
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    SizedBox(height: 4),
                    Text(
                      price,
                      style: GoogleFonts.beVietnamPro(
                        fontSize: 18,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    SizedBox(height: 4),
                    Text('Per $duration', style: GoogleFonts.beVietnamPro()),
                  ],
                ),
              ),
              Icon(
                selected
                    ? Icons.radio_button_checked
                    : Icons.radio_button_unchecked,
                color: selected ? Colors.green : Colors.grey,
              ),
            ],
          ),
        ),
      ),
    );
  }
}