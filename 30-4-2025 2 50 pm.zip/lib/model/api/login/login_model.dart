class LoginResponse {
  final String message;
  final LoginData data;

  LoginResponse({
    required this.message,
    required this.data,
  });

  factory LoginResponse.fromJson(Map<String, dynamic> json) {
    return LoginResponse(
      message: json['message'],
      data: LoginData.fromJson(json['data']),
    );
  }
}

class LoginData {
  final String customerId;
  final List<dynamic> devices;
  final Subscription subscription; // Make sure this field exists

  LoginData({
    required this.customerId,
    required this.devices,
    required this.subscription, // Include in constructor
  });

  factory LoginData.fromJson(Map<String, dynamic> json) {
    return LoginData(
      customerId: json['customerId'].toString(),
      devices: json['devices'] ?? [],
      subscription: Subscription.fromJson(json['subscription']), // Ensure this matches your JSON
    );
  }
}

class Subscription {
  final String firstName;
  final String lastName;
  final String mosque;
  final String mosqueLocation;
  final dynamic subscriptionPlan; // Renamed from 'subscription' for clarity

  Subscription({
    required this.firstName,
    required this.lastName,
    required this.mosque,
    required this.mosqueLocation,
    required this.subscriptionPlan,
  });

  factory Subscription.fromJson(Map<String, dynamic> json) {
    return Subscription(
      firstName: json['firstName'] ?? '',
      lastName: json['lastName'] ?? '',
      mosque: json['mosque'] ?? '',
      mosqueLocation: json['mosqueLocation'] ?? '',
      subscriptionPlan: json['subscription'],
    );
  }
}