// user_details_provider.dart
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

class UserDetails {
  final String fullName;
  final String mosque;
  final String mosqueLocation;

  UserDetails({
    required this.fullName,
    required this.mosque,
    required this.mosqueLocation,
  });

  // Conditional getters
  String get displayMosque => mosque.isEmpty ? 'Mosque not set' : mosque;
  String get displayMosqueLocation =>
      mosqueLocation.isEmpty ? 'Location not set' : mosqueLocation;
}

class UserDetailsProvider with ChangeNotifier {
  UserDetails? _userDetails;

  UserDetails? get userDetails => _userDetails;

  Future<void> loadUserDetails() async {
    final prefs = await SharedPreferences.getInstance();
    final fullName = prefs.getString('full_name') ?? '';
    final mosque = prefs.getString('mosque') ?? 'Mosque not set';
    final mosqueLocation = prefs.getString('mosque_location') ?? 'Mosque not set';

    _userDetails = UserDetails(
      fullName: fullName,
      mosque: mosque,
      mosqueLocation: mosqueLocation,
    );
    notifyListeners();
  }

  Future<void> updateUserDetails({
    required String fullName,
    required String mosque,
    required String mosqueLocation,
  }) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('full_name', fullName);
    await prefs.setString('mosque', mosque);
    await prefs.setString('mosque_location', mosqueLocation);

    _userDetails = UserDetails(
      fullName: fullName,
      mosque: mosque,
      mosqueLocation: mosqueLocation,
    );
    notifyListeners();
  }

  Future<void> clearUserDetails() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove('full_name');
    await prefs.remove('mosque');
    await prefs.remove('mosque_location');

    _userDetails = null;
    notifyListeners();
  }
}