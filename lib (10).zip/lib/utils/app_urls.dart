class AppUrls {
  static const appUrl = "http://appfordemo.com";
}

//  final appUrl = "https://prayer.leatticafe.com";
//  static const appUrl = "http://prayer.intelligencore.ai";
