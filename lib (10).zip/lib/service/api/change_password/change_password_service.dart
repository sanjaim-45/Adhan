import 'dart:convert';

import 'package:http/http.dart' as http;
import 'package:prayerunitesss/utils/app_urls.dart';

import '../../../model/api/change_password/change_password_model.dart';
import '../tokens/token_service.dart';

class ChangePasswordService {
  static final String _baseUrl =
      '${AppUrls.appUrl}/api/Customer/ChangePassword';

  Future<ChangePasswordResponse> changePassword(
    ChangePasswordRequest request,
  ) async {
    final accessToken = await TokenService.getAccessToken();

    final url = Uri.parse(_baseUrl);
    final response = await http.post(
      url,
      headers: {
        'Content-Type': 'application/json',
        'Authorization': 'Bearer $accessToken',
      },
      body: json.encode(request.toJson()),
    );

    if (response.statusCode == 200) {
      return ChangePasswordResponse.fromJson(json.decode(response.body));
    } else {
      throw Exception('Failed to change password: ${response.statusCode}');
    }
  }
}
