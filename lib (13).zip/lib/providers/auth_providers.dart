import 'package:flutter/cupertino.dart';

import '../service/api/tokens/token_service.dart';

class AuthProvider with ChangeNotifier {
  bool? _isLoggedIn;
  bool _shouldCheckToken = true;
  bool _isOffline = false;

  bool? get isLoggedIn => _isLoggedIn;
  bool get isOffline => _isOffline;

  Future<void> checkAuthStatus() async {
    try {
      // First check if we have a persisted session
      if (await TokenService.shouldMaintainSession()) {
        // If we have a refresh token, consider ourselves logged in
        // We'll try to refresh tokens when we come back online
        if (await TokenService.getRefreshToken() != null) {
          _isLoggedIn = true;
          _isOffline = true; // Mark as offline until we successfully refresh
          notifyListeners();
          return;
        }
      }

      // Normal online check
      _isLoggedIn = await TokenService.hasValidToken();
      _isOffline = false;
      notifyListeners();
    } catch (e) {
      // If we have a refresh token, maintain session in offline mode
      if (await TokenService.shouldMaintainSession() &&
          await TokenService.getRefreshToken() != null) {
        _isLoggedIn = true;
        _isOffline = true;
      } else {
        _isLoggedIn = false;
        _isOffline = false;
      }
      notifyListeners();
    }
  }

  Future<void> login() async {
    _isLoggedIn = true;
    _shouldCheckToken = true; // Reset to check tokens normally
    notifyListeners();
  }

  Future<void> softLogin() async {
    _isLoggedIn = true;
    _shouldCheckToken = false; // Skip token validation checks
    notifyListeners();
  }

  Future<void> logout() async {
    await TokenService.clearTokens();
    _isLoggedIn = false;
    _shouldCheckToken = true;
    notifyListeners();
  }
}
