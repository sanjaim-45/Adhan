import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:http/http.dart' as http;
import 'package:pinput/pinput.dart';
import 'package:prayerunitesss/ui/screens/login_page/forgot_password/reset_password.dart';
import 'package:prayerunitesss/utils/app_urls.dart';

import '../../../../service/api/auth/auth_api_service.dart';
import '../../../../utils/font_mediaquery.dart';

class ForgotPassword extends StatefulWidget {
  const ForgotPassword({super.key});

  @override
  State<ForgotPassword> createState() => _ForgotPasswordState();
}

class _ForgotPasswordState extends State<ForgotPassword>
    with SingleTickerProviderStateMixin {
  final _formKey = GlobalKey<FormState>();
  late AnimationController _controller;
  late Animation<double> _animation;
  bool _isLoading = false;
  final TextEditingController _emailController = TextEditingController();
  final FocusNode _emailFocusNode = FocusNode();

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      duration: const Duration(seconds: 2),
      vsync: this,
    )..repeat(reverse: true);
    _animation = Tween<double>(
      begin: -0.05,
      end: 0.05,
    ).animate(CurvedAnimation(parent: _controller, curve: Curves.easeInOut));
  }

  @override
  void dispose() {
    _controller.dispose();
    _emailController.dispose();
    _emailFocusNode.dispose();
    super.dispose();
  }

  Future<void> _handleContinue() async {
    if (_formKey.currentState!.validate()) {
      setState(() {
        _isLoading = true;
      });

      try {
        final authService = AuthApiService(
          baseUrl: AppUrls.appUrl,
          client: http.Client(),
        );

        final response = await authService.forgotPassword(
          _emailController.text,
        );
        print(response.message);

        if (mounted) {
          // ✅ Show success toast
          Fluttertoast.showToast(
            msg: response.message,
            toastLength: Toast.LENGTH_SHORT,
            gravity: ToastGravity.TOP,
            backgroundColor: Colors.green,
            textColor: Colors.white,
            fontSize: 14.0,
          );

          // ✅ Show OTP bottom sheet
          showModalBottomSheet(
            context: context,
            isScrollControlled: true,
            backgroundColor: Colors.transparent,
            builder:
                (context) => Padding(
                  padding: EdgeInsets.only(
                    bottom: MediaQuery.of(context).viewInsets.bottom,
                  ),
                  child: OTPBottomSheet(
                    contactInfo: _emailController.text,
                    onEditPressed: () {
                      Navigator.of(context).pop();
                      WidgetsBinding.instance.addPostFrameCallback((_) {
                        _emailFocusNode.requestFocus();
                      });
                    },
                  ),
                ),
          );
        }
      } catch (e) {
        print(e);
        if (mounted) {
          // ❌ Show error toast
          Fluttertoast.showToast(
            msg: e.toString(),
            toastLength: Toast.LENGTH_SHORT,
            gravity: ToastGravity.TOP,
            backgroundColor: Colors.red,
            textColor: Colors.white,
            fontSize: 14.0,
          );
        }
      } finally {
        if (mounted) {
          setState(() {
            _isLoading = false;
          });
        }
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final mediaQuery = MediaQuery.of(context);
    final screenHeight = mediaQuery.size.height;
    final screenWidth = mediaQuery.size.width;

    return Scaffold(
      backgroundColor: const Color(0xFF3B873E),
      body: Form(
        key: _formKey,
        child: Column(
          children: [
            // Top logo section (same as your original code)
            SizedBox(
              height: screenHeight * 0.22,
              child: Stack(
                clipBehavior: Clip.none,
                children: [
                  Align(
                    alignment: Alignment.topCenter,
                    child: Padding(
                      padding: EdgeInsets.only(top: screenHeight * 0.08),
                      child: Image.asset(
                        'assets/images/logo.png',
                        height: screenHeight * 0.12,
                        width: screenWidth * 0.30,
                      ),
                    ),
                  ),
                  Positioned(
                    top: screenHeight * 0.001,
                    right: screenWidth * 0.013,
                    child: Image.asset(
                      'assets/images/logo_blur.png',
                      height: screenHeight * 0.27,
                      width: screenWidth * 0.50,
                    ),
                  ),
                ],
              ),
            ),

            // Login form
            Expanded(
              child: Container(
                width: double.infinity,
                padding: EdgeInsets.symmetric(
                  horizontal: screenWidth * 0.05,
                  vertical: screenHeight * 0.04,
                ),
                decoration: const BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.only(
                    topLeft: Radius.circular(28),
                    topRight: Radius.circular(28),
                  ),
                ),
                child: SingleChildScrollView(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'Forgot your password?',
                        style: GoogleFonts.beVietnamPro(
                          fontSize: getFontBoldSize(context),
                          fontWeight: FontWeight.w700,
                          letterSpacing: -0.5,
                        ),
                      ),
                      Text(
                        'Enter your email and we\'ll send you a reset link.',
                        style: GoogleFonts.beVietnamPro(
                          fontSize: getFontRegularSize(context),
                          color: Colors.grey[700],
                          letterSpacing: -0.5,
                        ),
                      ),
                      SizedBox(height: screenHeight * 0.03),

                      // Username Field
                      Text(
                        'Email or Mobile Number',
                        style: GoogleFonts.beVietnamPro(
                          fontWeight: FontWeight.w600,
                          fontSize: getFontRegularSize(context),
                          letterSpacing: -0.5,
                        ),
                      ),
                      const SizedBox(height: 5),
                      CustomTextField(
                        controller: _emailController,
                        focusNode: _emailFocusNode,
                        hintText: 'Enter your email or Mobile number',
                        validator: Validator().validateEmailAndPhone,
                        keyboardType: TextInputType.emailAddress,
                        contentPadding: const EdgeInsets.symmetric(
                          vertical: 9,
                          horizontal: 12,
                        ),
                      ),

                      const SizedBox(height: 30),

                      // Login Button
                      SizedBox(
                        width: double.infinity,
                        height: screenHeight * 0.055,
                        child: ElevatedButton(
                          onPressed: _isLoading ? null : _handleContinue,
                          style: ElevatedButton.styleFrom(
                            backgroundColor: const Color(0xFF2D7C3F),
                            padding: const EdgeInsets.symmetric(vertical: 10),
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(10),
                            ),
                            elevation: 0,
                          ),
                          child:
                              _isLoading
                                  ? const CircularProgressIndicator(
                                    color: Colors.white,
                                    strokeWidth: 2,
                                  )
                                  : const Text(
                                    'Continue',
                                    style: TextStyle(
                                      color: Colors.white,
                                      fontWeight: FontWeight.w600,
                                    ),
                                  ),
                        ),
                      ),
                      SizedBox(height: 5),

                      Align(
                        alignment: Alignment.center,
                        child: TextButton(
                          onPressed: () {
                            Navigator.of(context).pop();
                          },
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: [
                              Transform.scale(
                                scale:
                                    1.5, // Increase the size to make the icon appear bolder
                                child: const Icon(
                                  Icons.arrow_back,
                                  size: 12, // Base size
                                  color: Color(0xFF3A4354),
                                ),
                              ),
                              const SizedBox(width: 4),
                              const Text(
                                'Back to Login in',
                                style: TextStyle(color: Color(0xFF3A4354)),
                              ),
                            ],
                          ),
                        ),
                      ),
                      SizedBox(
                        height: MediaQuery.of(context).size.height * 0.01,
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class OTPBottomSheet extends StatefulWidget {
  final String contactInfo;
  final VoidCallback onEditPressed;

  const OTPBottomSheet({
    super.key,
    required this.contactInfo,
    required this.onEditPressed,
  });

  @override
  _OTPBottomSheetState createState() => _OTPBottomSheetState();
}

class _OTPBottomSheetState extends State<OTPBottomSheet> {
  final pinController = TextEditingController();
  final _formKey = GlobalKey<FormState>();
  int secondsRemaining = 30;
  late final countdownTimer;
  bool _isLoading = false;

  @override
  void initState() {
    super.initState();
    countdownTimer = Future.delayed(const Duration(seconds: 1), tick);
  }

  @override
  void dispose() {
    pinController.dispose();
    super.dispose();
  }

  void tick() {
    if (mounted && secondsRemaining > 0) {
      setState(() => secondsRemaining--);
      Future.delayed(const Duration(seconds: 1), tick);
    }
  }

  String _formatTime(int seconds) {
    final duration = Duration(seconds: seconds);
    final minutes = duration.inMinutes.remainder(60).toString().padLeft(2, '0');
    final secs = duration.inSeconds.remainder(60).toString().padLeft(2, '0');
    return "$minutes:$secs";
  }

  String _formattedContact() {
    final String contact = widget.contactInfo;
    if (RegExp(r'^[0-9]{10}$').hasMatch(contact)) {
      return "+91 $contact";
    }
    return contact;
  }

  Future<void> _verifyOtp() async {
    if (!_formKey.currentState!.validate()) return;

    setState(() {
      _isLoading = true;
    });

    try {
      final authService = AuthApiService(
        baseUrl: AppUrls.appUrl,
        client: http.Client(),
      );

      final response = await authService.verifyResetPasswordOtp(
        otp: pinController.text,
        userIdentifier: widget.contactInfo,
      );

      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(response.message),
            backgroundColor: Colors.green,
          ),
        );

        // Print the response as requested
        if (kDebugMode) {
          print('OTP Verification Response: ${response.message}');
        }

        Navigator.of(context).push(
          MaterialPageRoute(
            builder:
                (context) => ResetPasswordUi(contactInfo: widget.contactInfo),
          ),
        );
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text(e.toString()), backgroundColor: Colors.red),
        );
      }
    } finally {
      if (mounted) {
        setState(() {
          _isLoading = false;
        });
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final defaultPinTheme = PinTheme(
      width: 56,
      height: 56,
      textStyle: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(10),
        border: Border.all(color: Colors.grey.shade300),
      ),
    );

    return Form(
      key: _formKey,
      child: Container(
        padding: const EdgeInsets.all(20),
        decoration: const BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.vertical(top: Radius.circular(25)),
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.start,
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisSize: MainAxisSize.min,
          children: [
            const Text(
              "OTP Verification",
              style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 8),
            Row(
              children: [
                Expanded(
                  child: RichText(
                    text: TextSpan(
                      style: const TextStyle(color: Colors.black),
                      children: [
                        const TextSpan(text: "OTP was sent to "),
                        TextSpan(
                          text: _formattedContact(),
                          style: const TextStyle(fontWeight: FontWeight.bold),
                        ),
                      ],
                    ),
                  ),
                ),
                IconButton(
                  icon: const Icon(Icons.edit, size: 16, color: Colors.blue),
                  onPressed: widget.onEditPressed,
                ),
              ],
            ),
            const SizedBox(height: 20),
            Pinput(
              length: 6,
              controller: pinController,
              defaultPinTheme: defaultPinTheme,
              focusedPinTheme: defaultPinTheme.copyWith(
                decoration: defaultPinTheme.decoration!.copyWith(
                  border: Border.all(color: Colors.blue),
                ),
              ),
              validator: (value) {
                if (value == null || value.length != 6) {
                  return 'Please enter 6-digit OTP';
                }
                return null;
              },
              onCompleted: (pin) => _verifyOtp(),
            ),
            const SizedBox(height: 10),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                RichText(
                  text: TextSpan(
                    children: [
                      const TextSpan(
                        text: "Time Remaining ",
                        style: TextStyle(color: Colors.grey, fontSize: 12),
                      ),
                      TextSpan(
                        text: _formatTime(secondsRemaining),
                        style: const TextStyle(
                          color: Color(0xFF4E50C3),
                          fontSize: 12,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ],
                  ),
                ),
                GestureDetector(
                  onTap:
                      secondsRemaining == 0
                          ? () {
                            setState(() => secondsRemaining = 30);
                            tick();
                          }
                          : null,
                  child: RichText(
                    text: TextSpan(
                      children: [
                        const TextSpan(
                          text: "Didn't receive OTP? ",
                          style: TextStyle(color: Colors.black, fontSize: 12),
                        ),
                        TextSpan(
                          text: 'Resend',
                          style: TextStyle(
                            fontSize: 12,
                            color:
                                secondsRemaining == 0
                                    ? Colors.grey
                                    : const Color(0xFF4E50C3),
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 16),
            SizedBox(
              width: double.infinity,
              child: ElevatedButton(
                onPressed: _isLoading ? null : _verifyOtp,
                style: ElevatedButton.styleFrom(
                  padding: EdgeInsets.zero,
                  backgroundColor: Colors.transparent,
                  shadowColor: Colors.transparent,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(30),
                  ),
                ),
                child: Ink(
                  decoration: BoxDecoration(
                    gradient: const LinearGradient(
                      colors: [Color(0xFF8285D4), Color(0xFF4C46D7)],
                      begin: Alignment.topCenter,
                      end: Alignment.bottomCenter,
                    ),
                    borderRadius: BorderRadius.circular(30),
                  ),
                  child: Container(
                    alignment: Alignment.center,
                    padding: const EdgeInsets.symmetric(vertical: 10),
                    child:
                        _isLoading
                            ? const CircularProgressIndicator(
                              color: Colors.white,
                              strokeWidth: 2,
                            )
                            : const Text(
                              'Verify Otp',
                              style: TextStyle(
                                color: Colors.white,
                                fontWeight: FontWeight.w600,
                              ),
                            ),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class DeviceUtils {
  static bool isTablet(BuildContext context) {
    return MediaQuery.of(context).size.shortestSide >= 600;
  }
}
