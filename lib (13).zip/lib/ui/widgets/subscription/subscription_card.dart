import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:intl/intl.dart';
import 'package:prayerunitesss/utils/app_urls.dart';
import 'package:provider/provider.dart';

import '../../../providers/subscription/subscription_provider.dart';
import '../../../service/api/templete_api/api_service.dart';
import '../../../utils/font_mediaquery.dart';
import '../../screens/subscription/upgrade.dart';

class SubscriptionCard extends StatelessWidget {
  const SubscriptionCard({super.key});

  @override
  Widget build(BuildContext context) {
    final subscriptionProvider = Provider.of<SubscriptionProvider>(context);
    final apiService = ApiService(baseUrl: AppUrls.appUrl);

    // Fetch subscription data when widget is built
    WidgetsBinding.instance.addPostFrameCallback((_) {
      subscriptionProvider.fetchSubscription(apiService);
    });

    // if (subscriptionProvider.isLoading) {
    //   return const Center(child: Text("fail"));
    // }

    if (subscriptionProvider.errorMessage.isNotEmpty) {
      return Center(child: Text(subscriptionProvider.errorMessage));
    }

    if (subscriptionProvider.hasNoSubscription ||
        subscriptionProvider.subscription == null) {
      return _buildSubscribeNowCard(context);
    }

    final subscription = subscriptionProvider.subscription!;
    final formattedEndDate = DateFormat('d MMM y').format(subscription.endDate);

    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          colors: [Color(0xFF004408), Color(0xFF2E7D32)],
          begin: Alignment.centerRight,
          end: Alignment.centerLeft,
        ),
        borderRadius: BorderRadius.circular(16),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Container(
                decoration: BoxDecoration(
                  color: const Color(0xFF73A876),
                  borderRadius: BorderRadius.circular(5),
                ),
                padding: const EdgeInsets.symmetric(horizontal: 5, vertical: 5),
                child: Text(
                  "My Current Plan",
                  style: GoogleFonts.beVietnamPro(
                    color: Colors.white,
                    fontSize: 12,
                  ),
                ),
              ),
              const SizedBox(height: 8),
              Text(
                subscription.planName,
                style: GoogleFonts.beVietnamPro(
                  color: Colors.white,
                  fontSize: 14,
                ),
              ),
              Text.rich(
                TextSpan(
                  children: [
                    TextSpan(
                      text: '${subscription.price} ${subscription.currency}',
                      style: GoogleFonts.beVietnamPro(
                        color: Colors.white,
                        fontSize: 18,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    TextSpan(
                      text: ' / month',
                      style: GoogleFonts.beVietnamPro(
                        color: Colors.white,
                        fontSize: 14,
                        fontWeight: FontWeight.normal,
                      ),
                    ),
                  ],
                ),
              ),
              Text.rich(
                TextSpan(
                  children: [
                    TextSpan(
                      text: 'Expires on:',
                      style: GoogleFonts.beVietnamPro(
                        color: Colors.white,
                        fontSize: 12,
                      ),
                    ),
                    TextSpan(
                      text: ' $formattedEndDate',
                      style: GoogleFonts.beVietnamPro(
                        color: const Color(0xFFF4DE8B),
                        fontSize: 12,
                        fontWeight: FontWeight.normal,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
          Transform.translate(
            offset: Offset(
              MediaQuery.of(context).size.width * 0.01,
              MediaQuery.of(context).size.height * 0.03,
            ),
            child: ElevatedButton(
              onPressed: () {
                Navigator.of(context).push(
                  MaterialPageRoute(builder: (context) => SubscriptionPage()),
                );
              },
              style: ElevatedButton.styleFrom(
                backgroundColor: const Color(0xFFD4AF37),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(30),
                ),
              ),
              child: Text(
                'Upgrade',
                style: GoogleFonts.beVietnamPro(color: Colors.white),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildSubscribeNowCard(BuildContext context) {
    final width = MediaQuery.of(context).size.width;
    return Container(
      padding: EdgeInsets.all(0),
      decoration: BoxDecoration(
        color: const Color(0xFF2E7D32),
        borderRadius: BorderRadius.circular(10),
      ),
      child: ListTile(
        contentPadding: EdgeInsets.symmetric(vertical: 0, horizontal: 20),
        leading: Image.asset(
          "assets/images/upgrade/king.png",
          height: width * 0.05,
          width: width * 0.05,
        ),
        title: Text(
          "Subscribe Now",
          style: GoogleFonts.beVietnamPro(
            fontSize: getFontRegularSize(context),
            letterSpacing: -0.5,
            color: Colors.white,
          ),
        ),
        trailing: Icon(
          Icons.arrow_forward_ios,
          size: getFontRegularSize(context),
          color: Colors.white,
        ),
        onTap: () {
          Navigator.of(
            context,
          ).push(MaterialPageRoute(builder: (context) => SubscriptionPage()));
        },
        dense: true,
        isThreeLine: false,
      ),
    );
  }
}
