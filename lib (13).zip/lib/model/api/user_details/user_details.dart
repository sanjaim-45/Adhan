// class UserDetails {
//   final String fullName;
//   final String mosque;
//   final String mosqueLocation;
//
//   UserDetails({
//     required this.fullName,
//     required this.mosque,
//     required this.mosqueLocation,
//   });
//
//   factory UserDetails.fromMap(Map<String, String> map) {
//     return UserDetails(
//       fullName: map['fullName'] ?? '',
//       mosque: map['mosque'] ?? '',
//       mosqueLocation: map['mosqueLocation'] ?? '',
//     );
//   }
// }