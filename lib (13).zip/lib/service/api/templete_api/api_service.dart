import 'dart:async';
import 'dart:convert';

import 'package:flutter/cupertino.dart';
import 'package:http/http.dart' as http;
import 'package:prayerunitesss/model/api/subscription/current_subscription_model.dart';

import '../../../model/api/transaction/transaction_response.dart';
import '../tokens/token_service.dart';

class ApiService {
  final String baseUrl;
  Timer? _refreshTimer;
  Timer? _countdownTimer;
  bool _isTimerRunning = false;
  int _countdown = 5 * 60; // 5 minutes in seconds

  ApiService({required this.baseUrl});

  Future<void> startTokenRefreshTimer() async {
    if (_isTimerRunning) return;

    final refreshToken = await TokenService.getRefreshToken();
    if (refreshToken == null) {
      _stopTimers();
      return;
    }

    _isTimerRunning = true;
    _startTimers();
  }

  void _startTimers() {
    // Cancel existing timers if any
    _stopTimers();

    // Initial print
    _printTimeRemaining(_countdown);

    // Countdown timer (every second)
    _countdownTimer = Timer.periodic(const Duration(seconds: 1), (timer) {
      _countdown--;
      _printTimeRemaining(_countdown);

      if (_countdown <= 0) {
        _countdown = 5 * 60; // Reset to 5 minutes
      }
    });

    // Main refresh timer (every 5 minutes)
    _refreshTimer = Timer.periodic(const Duration(minutes: 5), (timer) async {
      debugPrint('======== TOKEN REFRESH STARTED ========');
      final refreshToken = await TokenService.getRefreshToken();
      if (refreshToken == null) {
        _stopTimers();
        return;
      }

      debugPrint('--- Initiating token refresh at ${DateTime.now()} ---');
      final success = await this.refreshToken(); // Call the refreshToken method
      if (!success) {
        _stopTimers();
        return;
      }
      debugPrint('--- Token refresh completed at ${DateTime.now()} ---');
      debugPrint('======== TOKEN REFRESH FINISHED ========');

      // Reset countdown after successful refresh
      _countdown = 5 * 60;
    });
  }

  void _printTimeRemaining(int seconds) {
    final minutes = (seconds ~/ 60);
    final remainingSeconds = seconds % 60;
    final timeStr =
        '${minutes.toString().padLeft(2, '0')}:${remainingSeconds.toString().padLeft(2, '0')}';
    debugPrint('🔃 Token refresh in: $timeStr');
  }

  void _stopTimers() {
    _refreshTimer?.cancel();
    _countdownTimer?.cancel();
    _refreshTimer = null;
    _countdownTimer = null;
    _isTimerRunning = false;
    debugPrint('🛑 Token refresh timers stopped');
  }

  void dispose() {
    _stopTimers();
  }

  Future<http.Response> sendRequest(
    String url,
    String method, {
    Map<String, String>? headers,
    dynamic body,
    bool retry = true,
  }) async {
    if (await TokenService.shouldMaintainSession()) {
      // If access token is expired but we have a refresh token
      if (await TokenService.isAccessTokenExpired() &&
          await TokenService.getRefreshToken() != null) {
        try {
          final refreshed = await refreshToken();
          if (!refreshed && retry) {
            throw Exception('Failed to refresh token');
          }
        } catch (e) {
          // If we're maintaining session, don't throw - let the API call fail naturally
          // This allows offline functionality
          if (!await TokenService.shouldMaintainSession()) {
            rethrow;
          }
        }
      }
    }
    final accessToken = await TokenService.getAccessToken();
    final defaultHeaders = {
      'Content-Type': 'application/json',
      if (accessToken != null) 'Authorization': 'Bearer $accessToken',
    };

    if (headers != null) {
      defaultHeaders.addAll(headers);
    }

    final uri = Uri.parse(url);
    http.Response response;

    try {
      switch (method.toUpperCase()) {
        case 'GET':
          response = await http.get(uri, headers: defaultHeaders);
          break;
        case 'POST':
          response = await http.post(
            uri,
            headers: defaultHeaders,
            body: body != null ? json.encode(body) : null,
          );
          break;
        default:
          throw Exception('Unsupported HTTP method');
      }

      // Still handle 401 errors in case the token expires between refreshes
      if (response.statusCode == 401 && retry) {
        final refreshed = await refreshToken();
        if (refreshed) {
          return sendRequest(
            url,
            method,
            headers: headers,
            body: body,
            retry: false,
          );
        }
      }

      return response;
    } catch (e) {
      throw Exception('Request failed: $e');
    }
  }

  Future<bool> cancelSubscription(int subscriptionId) async {
    try {
      final response = await sendRequest(
        '$baseUrl/api/CustomerSubscription/Cancel?subscriptionId=$subscriptionId',
        'POST',
      );

      if (response.statusCode == 200) {
        return true;
      } else {
        throw Exception(
          'Failed to cancel subscription: ${response.statusCode}',
        );
      }
    } catch (e) {
      throw Exception('Failed to cancel subscription: $e');
    }
  }

  // services/api_service.dart
  Future<TransactionResponse?> getAllCustomerTransactions() async {
    try {
      final response = await sendRequest(
        '$baseUrl/api/CustomerSubscription/GetAllCustomerTransactions',
        'GET',
      );

      if (response.statusCode == 200) {
        return TransactionResponse.fromJson(json.decode(response.body));
      } else if (response.statusCode == 404) {
        // No active subscription found
        return null;
      } else {
        throw Exception('Failed to load subscription: ${response.statusCode}');
      }
    } catch (e) {
      throw Exception('Failed to load subscription: $e');
    }
  }

  // Add this method to your ApiService class
  // Updated API service method
  Future<CurrentSubscriptionModel?> getCurrentSubscription() async {
    try {
      final response = await sendRequest(
        '$baseUrl/api/CustomerSubscription/GetByCustomerId',
        'GET',
      );

      if (response.statusCode == 200) {
        final jsonData = json.decode(response.body);

        // Check if the response is an empty array
        if (jsonData is List && jsonData.isEmpty) {
          return null;
        }

        return CurrentSubscriptionModel.fromJson(jsonData);
      } else if (response.statusCode == 404) {
        // No active subscription found
        return null;
      } else {
        throw Exception('Failed to load subscription: ${response.statusCode}');
      }
    } catch (e) {
      throw Exception('Failed to load subscription: $e');
    }
  }

  Future<bool> refreshToken() async {
    try {
      final refreshToken = await TokenService.getRefreshToken();
      if (refreshToken == null) return false;

      final refreshUrl = Uri.parse('$baseUrl/api/RefreshToken/refresh-token');
      final refreshResponse = await http.post(
        refreshUrl,
        headers: {'Content-Type': 'application/json'},
        body: json.encode({'token': refreshToken}),
      );

      if (refreshResponse.statusCode == 200) {
        final data = json.decode(refreshResponse.body);
        await TokenService.saveTokens(
          data['accessToken'],
          data['refreshToken'],
        );
        return true;
      } else if (refreshResponse.statusCode == 401) {
        // Only clear tokens if we get an explicit unauthorized response
        await TokenService.clearTokens();
        return false;
      } else {
        // For other status codes, don't clear tokens - might be temporary issue
        return false;
      }
    } catch (e) {
      // Don't clear tokens on network/parsing errors - might be temporary
      return false;
    }
  }
}
