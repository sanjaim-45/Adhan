import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:provider/provider.dart';

import '../../../model/api/login/login_model.dart';
import '../../../providers/auth_providers.dart';
import '../../../providers/user_details_from_login/user_details.dart';
import '../../../utils/app_urls.dart';
import '../tokens/token_service.dart';

class LoginService {
  static Future<LoginResponse> login({
    required String userName,
    required String password,
    required BuildContext context,
    bool maintainSession = false, // New parameter
  }) async {
    final url = Uri.parse('${AppUrls.appUrl}/api/Login/Login');
    final response = await http.post(
      url,
      headers: {'Content-Type': 'application/json'},
      body: json.encode({'userName': userName, 'password': password}),
    );

    if (response.statusCode == 200) {
      final data = json.decode(response.body); // ✅ Add this line
      final loginResponse = LoginResponse.fromJson(data);

      // Save session preference
      await TokenService.setMaintainSession(maintainSession);

      final accessToken = _getHeaderCaseInsensitive(
        response.headers,
        'access-token',
      );
      final refreshToken = _getHeaderCaseInsensitive(
        response.headers,
        'refresh-token',
      );
      final accessExpiresIn =
          data['accessTokenExpiresIn'] ?? 300; // 5 min default
      final refreshExpiresIn =
          data['refreshTokenExpiresIn'] ?? 604800; // 7 days default

      if (accessToken == null || refreshToken == null) {
        throw Exception('Tokens not found in response headers');
      }

      // Save tokens
      await TokenService.saveTokens(
        accessToken,
        refreshToken,
        accessTokenExpiresIn: accessExpiresIn,
        refreshTokenExpiresIn: refreshExpiresIn,
      );

      // Start auto-refresh
      TokenRefreshService().start();

      // Update auth state
      await Provider.of<AuthProvider>(context, listen: false).login();

      // Save user details
      final userDetailsProvider = Provider.of<UserDetailsProvider>(
        context,
        listen: false,
      );
      if (loginResponse.customerDetailResponse.subscription != null) {
        final subscription = loginResponse.customerDetailResponse.subscription;
        await userDetailsProvider.updateUserDetails(
          fullName: '${subscription.firstName} ${subscription.lastName}',
          mosque: subscription.mosque,
          mosqueLocation: subscription.mosqueLocation,
        );

        final plan = subscription.subscriptionPlan;
        await userDetailsProvider.updateSubscriptionDetails(
          planName: plan.planName,
          billingCycle: plan.billingCycle,
          price: plan.price,
          currency: plan.currency,
          remainingDays: plan.remainingDays,
        );
      } else {
        await userDetailsProvider.updateUserDetails(
          fullName: '',
          mosque: '',
          mosqueLocation: '',
        );
        await userDetailsProvider.clearSubscription();
      }

      return loginResponse;
    } else {
      throw Exception('Failed to login: ${response.statusCode}');
    }
  }

  static Future<bool> checkPersistedAuth(BuildContext context) async {
    final maintainSession = await TokenService.shouldMaintainSession();
    if (maintainSession) {
      final authProvider = Provider.of<AuthProvider>(context, listen: false);
      await authProvider.softLogin();
      return true;
    }
    return false;
  }

  static Future<void> logout(BuildContext context) async {
    try {
      TokenRefreshService().stop(); // Stop refresh timer

      await TokenService.clearTokens();
      await Provider.of<AuthProvider>(context, listen: false).logout();
      await Provider.of<UserDetailsProvider>(
        context,
        listen: false,
      ).clearUserDetails();
    } catch (e) {
      await TokenService.clearTokens();
      rethrow;
    }
  }
}

String? _getHeaderCaseInsensitive(Map<String, String> headers, String key) {
  final lowerKey = key.toLowerCase();
  for (final headerKey in headers.keys) {
    if (headerKey.toLowerCase() == lowerKey) {
      return headers[headerKey];
    }
  }
  return null;
}
