import 'dart:async';
import 'dart:convert';

import 'package:flutter/foundation.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';

import '../../../utils/app_urls.dart';

class TokenService {
  static const String _accessTokenKey = 'access_token';
  static const String _refreshTokenKey = 'refresh_token';
  static const String _tokenExpiryKey = 'token_expiry';

  // Add this method to check refresh token validity separately
  static Future<bool> isRefreshTokenValid() async {
    final prefs = await SharedPreferences.getInstance();
    final refreshToken = prefs.getString(_refreshTokenKey);
    final refreshTokenExpiry = prefs.getInt('refresh_token_expiry');

    if (refreshToken == null || refreshTokenExpiry == null) return false;

    return DateTime.now().millisecondsSinceEpoch < refreshTokenExpiry;
  }

  static Future<bool> hasValidSession() async {
    final maintainSession = await shouldMaintainSession();
    if (!maintainSession) return false;

    final refreshToken = await getRefreshToken();
    if (refreshToken == null) return false;

    // If we're maintaining session and have a refresh token, consider it valid
    // We'll try to refresh when we come back online
    return true;
  }

  // Modify saveTokens to handle refresh token expiry separately
  static Future<void> saveTokens(
    String accessToken,
    String refreshToken, {
    int accessTokenExpiresIn = 300, // 5 minutes
    int refreshTokenExpiresIn = 7 * 24 * 60 * 60, // 7 days in seconds
  }) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_accessTokenKey, accessToken);
    await prefs.setString(_refreshTokenKey, refreshToken);

    final accessExpiry =
        DateTime.now()
            .add(Duration(seconds: accessTokenExpiresIn))
            .millisecondsSinceEpoch;
    final refreshExpiry =
        DateTime.now()
            .add(Duration(seconds: refreshTokenExpiresIn))
            .millisecondsSinceEpoch;

    await prefs.setInt(_tokenExpiryKey, accessExpiry);
    await prefs.setInt('refresh_token_expiry', refreshExpiry);
  }

  static Future<String?> getAccessToken() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString(_accessTokenKey);
  }

  static Future<String?> getRefreshToken() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString(_refreshTokenKey);
  }

  static Future<bool> shouldMaintainSession() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getBool('maintain_session') ?? false;
  }

  static Future<void> setMaintainSession(bool value) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool('maintain_session', value);
  }

  static Future<bool> isAccessTokenExpired() async {
    final prefs = await SharedPreferences.getInstance();
    final expiryTime = prefs.getInt(_tokenExpiryKey);
    if (expiryTime == null) return true;
    return DateTime.now().millisecondsSinceEpoch >= expiryTime;
  }

  static Future<bool> hasValidToken() async {
    final accessToken = await getAccessToken();
    final refreshToken = await getRefreshToken();
    final isExpired = await isAccessTokenExpired();
    return accessToken != null && refreshToken != null && !isExpired;
  }

  static Future<void> clearTokens() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove(_accessTokenKey);
    await prefs.remove(_refreshTokenKey);
    await prefs.remove(_tokenExpiryKey);
  }
}

class TokenRefreshService {
  static final TokenRefreshService _instance = TokenRefreshService._internal();
  Timer? _refreshTimer;
  bool _isRunning = false;

  factory TokenRefreshService() => _instance;

  TokenRefreshService._internal();

  void start() {
    stop(); // Prevent multiple timers
    _refreshTimer = Timer.periodic(
      Duration(minutes: 5),
      (_) => _refreshToken(),
    );
    print("Token refresh service started");
  }

  void stop() {
    _refreshTimer?.cancel();
    _refreshTimer = null;
    _isRunning = false;
    if (kDebugMode) {
      print('🛑 Token refresh service stopped');
    }
  }

  Future<void> _checkAndRefresh() async {
    if (kDebugMode) {
      print('🔄 Checking token status...');
    }

    final refreshToken = await TokenService.getRefreshToken();
    if (refreshToken == null) {
      if (kDebugMode) {
        print('❌ No refresh token available');
      }
      stop();
      return;
    }

    if (await TokenService.isAccessTokenExpired()) {
      if (kDebugMode) {
        print('⏳ Token expired or about to expire - refreshing...');
      }
      await _refreshToken();
    } else {
      if (kDebugMode) {
        print('✅ Token still valid');
      }
    }
  }

  Future<bool> _refreshToken() async {
    if (_isRunning) return false;
    _isRunning = true;

    try {
      if (kDebugMode) {
        print('🔄 Attempting token refresh...');
      }

      final refreshToken = await TokenService.getRefreshToken();
      if (refreshToken == null) {
        if (kDebugMode) {
          print('❌ No refresh token available');
        }
        return false;
      }

      final response = await http
          .post(
            Uri.parse('${AppUrls.appUrl}/api/RefreshToken/refresh-token'),
            headers: {'Content-Type': 'application/json'},
            body: json.encode({'token': refreshToken}),
          )
          .timeout(const Duration(seconds: 10));

      if (response.statusCode == 200) {
        final data = json.decode(response.body);
        await TokenService.saveTokens(
          data['accessToken'],
          data['refreshToken'],
          accessTokenExpiresIn: data['accessTokenExpiresIn'] ?? 300,
          refreshTokenExpiresIn: data['refreshTokenExpiresIn'] ?? 604800,
        );

        if (kDebugMode) {
          print('✅ Token refresh successful');
        }
        return true;
      } else if (response.statusCode == 401) {
        // Only clear tokens if we get explicit unauthorized response
        if (kDebugMode) {
          print('🔴 Refresh token rejected - clearing tokens');
        }
        await TokenService.clearTokens();
        return false;
      } else {
        // For other status codes, don't clear tokens - might be temporary server issue
        if (kDebugMode) {
          print(
            '⚠️ Token refresh failed (Status: ${response.statusCode}) - maintaining current tokens',
          );
        }
        return false;
      }
    } on TimeoutException {
      if (kDebugMode) {
        print('⏳ Token refresh timed out - maintaining current tokens');
      }
      return false;
    } catch (e) {
      if (kDebugMode) {
        print(
          '⚠️ Token refresh error (${e.runtimeType}) - maintaining current tokens',
        );
      }
      return false;
    } finally {
      _isRunning = false;
    }
  }
}
