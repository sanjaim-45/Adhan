import 'dart:async';

import 'package:audio_service/audio_service.dart';
import 'package:flutter/material.dart';
import 'package:prayerunitesss/providers/auth_providers.dart';
import 'package:prayerunitesss/providers/subscription/subscription_provider.dart';
import 'package:prayerunitesss/providers/user_details_from_login/user_details.dart';
import 'package:prayerunitesss/service/api/templete_api/api_service.dart';
import 'package:prayerunitesss/service/api/tokens/token_service.dart';
import 'package:prayerunitesss/ui/screens/login_page/login_page.dart';
import 'package:prayerunitesss/ui/widgets/main_screen.dart';
import 'package:prayerunitesss/ui/widgets/prayer_card.dart';
import 'package:prayerunitesss/ui/widgets/spalsh_screen.dart';
import 'package:prayerunitesss/utils/app_urls.dart';
import 'package:provider/provider.dart';

late AudioHandler _audioHandler;

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  _audioHandler = await AudioService.init(
    builder: () => AudioPlayerHandler(),
    config: const AudioServiceConfig(
      androidNotificationChannelId: 'com.yourcompany.yourapp.channel.audio',
      androidNotificationChannelName: 'Audio playback',
      androidNotificationOngoing: true,
      androidStopForegroundOnPause: true,
    ),
  );
  runApp(const MyApp());
}

class MyApp extends StatefulWidget {
  const MyApp({super.key});

  @override
  State<MyApp> createState() => _MyAppState();
}

class _MyAppState extends State<MyApp> {
  final ApiService apiService = ApiService(baseUrl: AppUrls.appUrl);

  @override
  void initState() {
    super.initState();
    _initializeApp();
  }

  Future<void> _initializeApp() async {
    // Start refresh service if logged in
    if (await TokenService.hasValidToken()) {
      TokenRefreshService().start();
    }
  }

  @override
  void dispose() {
    TokenRefreshService().stop();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return MultiProvider(
      providers: [
        ChangeNotifierProvider(create: (context) => AuthProvider()),
        ChangeNotifierProvider(create: (context) => UserDetailsProvider()),
        Provider<ApiService>.value(value: apiService),
        ChangeNotifierProvider(create: (_) => SubscriptionProvider()),
      ],
      child: MaterialApp(
        debugShowCheckedModeBanner: false,
        home: Consumer<AuthProvider>(
          builder: (context, auth, child) {
            if (auth.isLoggedIn == null) return const SplashScreen();
            return auth.isLoggedIn! ? const MainScreen() : const LoginPage();
          },
        ),
      ),
    );
  }
}
