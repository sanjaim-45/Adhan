class Order {
  final int orderId;
  final DateTime orderDate;
  final DateTime? deliveryDate;
  final String deliveryStatus;
  final String paymentMethod;
  final List<Item> items;

  Order({
    required this.orderId,
    required this.orderDate,
    this.deliveryDate,
    required this.deliveryStatus,
    required this.paymentMethod,
    required this.items,
  });

  factory Order.fromJson(Map<String, dynamic> json) {
    return Order(
      orderId: json['orderId'],
      orderDate: DateTime.parse(json['orderDate']),
      deliveryDate:
          json['deliveryDate'] != null
              ? DateTime.parse(json['deliveryDate'])
              : null,
      deliveryStatus: json['deliveryStatus'],
      paymentMethod: json['paymentMethod'],
      items:
          (json['items'] as List).map((item) => Item.fromJson(item)).toList(),
    );
  }
}

class Item {
  final String deviceName;
  final String serialNumber;
  final String mosqueName;
  final String subscriptionPlan;
  final DateTime startDate;
  final DateTime endDate;
  final bool subscriptionStatus;
  final String paymentStatus;
  final String paymentMethod;

  Item({
    required this.deviceName,
    required this.serialNumber,
    required this.mosqueName,
    required this.subscriptionPlan,
    required this.startDate,
    required this.endDate,
    required this.subscriptionStatus,
    required this.paymentStatus,
    required this.paymentMethod,
  });

  factory Item.fromJson(Map<String, dynamic> json) {
    return Item(
      deviceName: json['deviceName'],
      serialNumber: json['serialNumber'],
      mosqueName: json['mosqueName'],
      subscriptionPlan: json['subscriptionPlan'],
      startDate: DateTime.parse(json['startDate']),
      endDate: DateTime.parse(json['endDate']),
      subscriptionStatus: json['subscriptionStatus'],
      paymentStatus: json['paymentStatus'],
      paymentMethod: json['paymentMethod'],
    );
  }
}
