import 'dart:async';

import 'package:audio_service/audio_service.dart';
import 'package:flutter/material.dart';
import 'package:prayerunitesss/providers/auth_providers.dart';
import 'package:prayerunitesss/providers/device_request/device_request_provider.dart';
import 'package:prayerunitesss/providers/subscription/subscription_provider.dart';
import 'package:prayerunitesss/providers/user_details_from_login/user_details.dart';
import 'package:prayerunitesss/service/api/templete_api/api_service.dart';
import 'package:prayerunitesss/service/api/tokens/token_service.dart';
import 'package:prayerunitesss/service/prayer/prayer_alarm_service.dart';
import 'package:prayerunitesss/ui/screens/login_page/login_page.dart';
import 'package:prayerunitesss/ui/widgets/main_screen.dart';
import 'package:prayerunitesss/ui/widgets/prayer_card.dart';
import 'package:prayerunitesss/ui/widgets/spalsh_screen.dart';
import 'package:prayerunitesss/utils/app_urls.dart';
import 'package:provider/provider.dart';
import 'package:shared_preferences/shared_preferences.dart';

late AudioHandler _audioHandler;

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await PrayerAlarmService.initialize();
  _audioHandler = await AudioService.init(
    builder: () => AudioPlayerHandler(),
    config: const AudioServiceConfig(
      androidNotificationChannelId: 'com.yourcompany.yourapp.channel.audio',
      androidNotificationChannelName: 'Audio playback',
      androidNotificationOngoing: true,
      androidStopForegroundOnPause: true,
    ),
  );
  runApp(const MyApp());
}

class MyApp extends StatefulWidget {
  const MyApp({super.key});

  @override
  State<MyApp> createState() => _MyAppState();
}

class _MyAppState extends State<MyApp> {
  final ApiService apiService = ApiService(baseUrl: AppUrls.appUrl);

  @override
  void initState() {
    super.initState();
    _initializeApp();
  }

  Future _initializeApp() async {
    // Check if customer ID exists in SharedPreferences
    final prefs = await SharedPreferences.getInstance();
    final customerIdString = prefs.getString('customerId');

    // Start refresh service if logged in and customer ID exists
    if (await TokenService.hasValidTokens() && customerIdString != null) {
      TokenRefreshService().start();
    }
  }

  @override
  void dispose() {
    TokenRefreshService().stop();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return MultiProvider(
      providers: [
        ChangeNotifierProvider(create: (context) => AuthProvider()),
        ChangeNotifierProvider(
          create: (context) => UserDetailsProvider()..loadUserDetails(),
        ),
        Provider<ApiService>.value(value: apiService),
        ChangeNotifierProvider(create: (_) => SubscriptionProvider()),
        ChangeNotifierProvider(create: (_) => DeviceRequestProvider()),
      ],
      child: MaterialApp(
        debugShowCheckedModeBanner: false,
        home: FutureBuilder(
          future: SharedPreferences.getInstance(),
          builder: (context, snapshot) {
            if (snapshot.connectionState != ConnectionState.done) {
              return const SplashScreen();
            }

            final prefs = snapshot.data as SharedPreferences;
            final customerId = prefs.getString('customerId');

            return Consumer<AuthProvider>(
              builder: (context, auth, child) {
                if (auth.isLoggedIn == null) return const SplashScreen();
                // If customerId is null, force login page regardless of auth status
                return (auth.isLoggedIn! && customerId != null)
                    ? const MainScreen()
                    : const LoginPage();
              },
            );
          },
        ),
      ),
    );
  }
}
