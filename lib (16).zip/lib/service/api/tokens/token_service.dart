import 'dart:async';
import 'dart:convert';

import 'package:flutter/foundation.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';

import '../../../utils/app_urls.dart';

class TokenService {
  static const String _accessTokenKey = 'access_token';
  static const String _refreshTokenKey = 'refresh_token';

  static Future<void> saveTokens(
    String accessToken,
    String refreshToken,
  ) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_accessTokenKey, accessToken);
    await prefs.setString(_refreshTokenKey, refreshToken);
  }

  static Future<String?> getAccessToken() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString(_accessTokenKey);
  }

  static Future<String?> getRefreshToken() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString(_refreshTokenKey);
  }

  static Future<bool> shouldMaintainSession() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getBool('maintain_session') ?? false;
  }

  static Future<void> setMaintainSession(bool value) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool('maintain_session', value);
  }

  static Future<bool> hasValidTokens() async {
    final accessToken = await getAccessToken();
    final refreshToken = await getRefreshToken();
    return accessToken != null && refreshToken != null;
  }

  static Future<void> clearTokens() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove(_accessTokenKey);
    await prefs.remove(_refreshTokenKey);
    await prefs.remove('maintain_session');
  }
}

class TokenRefreshService {
  static final TokenRefreshService _instance = TokenRefreshService._internal();
  Timer? _refreshTimer;
  bool _isRunning = false;

  factory TokenRefreshService() => _instance;

  TokenRefreshService._internal();

  void start() {
    if (_refreshTimer != null) return;

    // Check every 4 minutes (less than access token expiry)
    _refreshTimer = Timer.periodic(
      const Duration(minutes: 4),
      (_) => _checkAndRefresh(),
    );
    if (kDebugMode) {
      print('🔄 Token refresh service started');
    }
  }

  void stop() {
    _refreshTimer?.cancel();
    _refreshTimer = null;
    _isRunning = false;
    if (kDebugMode) {
      print('🛑 Token refresh service stopped');
    }
  }

  Future<void> _checkAndRefresh() async {
    if (_isRunning) return;
    _isRunning = true;

    try {
      if (kDebugMode) {
        print('🔄 Checking token status...');
      }

      // Only proceed if we have both tokens
      if (!(await TokenService.hasValidTokens())) {
        if (kDebugMode) {
          print('❌ Missing one or both tokens - stopping refresh');
        }
        stop();
        return;
      }

      await _refreshToken();
    } catch (e) {
      if (kDebugMode) {
        print('⚠️ Error during token check: ${e.toString()}');
      }
    } finally {
      _isRunning = false;
    }
  }

  Future<bool> _refreshToken() async {
    try {
      final refreshToken = await TokenService.getRefreshToken();
      if (refreshToken == null) {
        if (kDebugMode) {
          print('❌ No refresh token available');
        }
        return false;
      }

      if (kDebugMode) {
        print('🔄 Attempting token refresh...');
      }

      final response = await http
          .post(
            Uri.parse('${AppUrls.appUrl}/api/RefreshToken/refresh-token'),
            headers: {'Content-Type': 'application/json'},
            body: json.encode({'token': refreshToken}),
          )
          .timeout(const Duration(seconds: 10));

      if (response.statusCode == 200) {
        final data = json.decode(response.body);

        // Save new tokens (backend handles expiration)
        await TokenService.saveTokens(
          data['accessToken'],
          data['refreshToken'],
        );

        if (kDebugMode) {
          print('✅ Token refresh successful');
        }
        return true;
      } else {
        if (kDebugMode) {
          print('⚠️ Token refresh failed with status: ${response.statusCode}');
        }
        return false;
      }
    } on TimeoutException {
      if (kDebugMode) {
        print('⏳ Token refresh timed out');
      }
      return false;
    } catch (e) {
      if (kDebugMode) {
        print('⚠️ Token refresh error: ${e.toString()}');
      }
      return false;
    }
  }
}
