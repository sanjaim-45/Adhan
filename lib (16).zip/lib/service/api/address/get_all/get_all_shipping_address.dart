// lib/services/api/shipping_address_api_service.dart
import 'dart:convert';

import 'package:http/http.dart' as http;

import '../../../../model/api/address/shipping_address_create_model.dart';
import '../../tokens/token_service.dart';

class ShippingAddressGetAllApiService {
  final String baseUrl;
  final http.Client client;

  ShippingAddressGetAllApiService({
    required this.baseUrl,
    required this.client,
  });

  Future<List<ShippingAddress>> getShippingAddresses() async {
    final url = Uri.parse(
      '$baseUrl/api/CustomerShippingAddress/GetShippingAddress',
    );

    // Get the stored access token
    final accessToken = await TokenService.getAccessToken();

    if (accessToken == null || accessToken.isEmpty) {
      throw Exception('No access token found');
    }

    try {
      final response = await client.get(
        url,
        headers: {
          'Content-Type': 'application/json',
          'Authorization': 'Bearer $accessToken',
        },
      );

      print('Response Status: ${response.statusCode}');
      print('Response Body: ${response.body}');

      if (response.statusCode == 200) {
        if (response.body.isEmpty) {
          throw Exception('Server returned empty response');
        }

        try {
          final List<dynamic> decodedJson = json.decode(response.body);
          return decodedJson
              .map((addressJson) => ShippingAddress.fromJson(addressJson))
              .toList();
        } catch (e) {
          throw Exception('Failed to decode JSON: $e');
        }
      } else {
        throw Exception(
          'Failed to fetch shipping addresses (Status: ${response.statusCode})\n'
          'Response: ${response.body.isNotEmpty ? response.body : "No error message"}',
        );
      }
    } catch (e) {
      throw Exception('Network error: $e');
    }
  }
}
