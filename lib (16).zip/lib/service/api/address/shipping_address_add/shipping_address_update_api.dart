// shipping_address_update_service.dart
import 'dart:convert';

import 'package:http/http.dart' as http;

import '../../tokens/token_service.dart';

class ShippingAddressUpdateApiService {
  final String baseUrl;
  final http.Client client;

  ShippingAddressUpdateApiService({
    required this.baseUrl,
    required this.client,
  });

  Future<Map<String, dynamic>> updateShippingAddress({
    required int addressId,
    required String fullName,
    required String phoneNumber,
    required String email,
    required String address,
    required bool makeDefault,
  }) async {
    final accessToken = await TokenService.getAccessToken();

    if (accessToken == null || accessToken.isEmpty) {
      throw Exception('No access token found');
    }
    try {
      final url = Uri.parse(
        '$baseUrl/api/CustomerShippingAddress/UpdateShippingAddress?addressId=$addressId',
      );

      final response = await client.post(
        url,
        headers: {
          'Content-Type': 'application/json',
          'Authorization': 'Bearer $accessToken',
        },
        body: jsonEncode({
          'fullName': fullName,
          'phoneNumber': phoneNumber,
          'email': email,
          'address': address,
          'makeDefault': makeDefault,
        }),
      );

      if (response.statusCode == 200) {
        return jsonDecode(response.body);
      } else {
        throw Exception(
          'Failed to update shipping address: ${response.statusCode}',
        );
      }
    } catch (e) {
      // Handle any exceptions that occur during the API call or JSON decoding.
      // You can log the error, show a user-friendly message, or re-throw a custom exception.
      // For example:
      // print('Error updating shipping address: $e');
      throw Exception('Failed to update shipping address. Please try again.');
    }
  }
}
