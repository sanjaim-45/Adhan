import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:just_audio/just_audio.dart';
import 'package:timezone/data/latest.dart' as tz;
import 'package:timezone/timezone.dart' as tz;

class PrayerAlarmService {
  static final FlutterLocalNotificationsPlugin _notificationsPlugin =
      FlutterLocalNotificationsPlugin();
  static final AudioPlayer _audioPlayer = AudioPlayer();
  static bool _isInitialized = false;

  static Future<void> initialize() async {
    if (_isInitialized) return;

    tz.initializeTimeZones();

    // Initialize notifications
    const AndroidInitializationSettings initializationSettingsAndroid =
        AndroidInitializationSettings('@mipmap/ic_launcher');

    final InitializationSettings initializationSettings =
        InitializationSettings(android: initializationSettingsAndroid);

    await _notificationsPlugin.initialize(
      initializationSettings,
      onDidReceiveNotificationResponse: (NotificationResponse response) async {
        // Handle notification tap if needed
        await _playAdhanAudio();
      },
    );

    // Create notification channel
    const AndroidNotificationChannel channel = AndroidNotificationChannel(
      'prayer_alerts_channel',
      'Prayer Alerts',
      description: 'Notifications for upcoming prayer times',
      importance: Importance.max,
      playSound: true,
      sound: RawResourceAndroidNotificationSound('adhan'),
    );

    await _notificationsPlugin
        .resolvePlatformSpecificImplementation<
          AndroidFlutterLocalNotificationsPlugin
        >()
        ?.createNotificationChannel(channel);

    _isInitialized = true;
  }

  static Future<void> schedulePrayerAlerts(
    Map<String, String> prayerTimes,
  ) async {
    // Cancel all existing notifications
    await _notificationsPlugin.cancelAll();

    // Schedule alerts for each prayer
    await _schedulePrayerAlert('Fajr', prayerTimes['fajr']!);
    await _schedulePrayerAlert('Dhuhr', prayerTimes['dhuhr']!);
    await _schedulePrayerAlert('Asr', prayerTimes['asr']!);
    await _schedulePrayerAlert('Maghrib', prayerTimes['maghrib']!);
    await _schedulePrayerAlert('Isha', prayerTimes['isha']!);
  }

  static Future<void> _schedulePrayerAlert(
    String prayerName,
    String prayerTime,
  ) async {
    final now = DateTime.now();
    final prayerDateTime = _parseTimeString(prayerTime);

    // Schedule 10 minutes before prayer
    final alertTime = prayerDateTime.subtract(const Duration(minutes: 10));

    if (alertTime.isAfter(now)) {
      // Schedule notification with sound
      await _scheduleNotification(
        prayerName,
        'Prayer time for $prayerName is in 10 minutes',
        alertTime,
      );
    }
  }

  static Future _scheduleNotification(
    String prayerName, // Add prayerName as a parameter
    String body,
    DateTime scheduledTime,
  ) async {
    const AndroidNotificationDetails androidPlatformChannelSpecifics =
        AndroidNotificationDetails(
          'prayer_alerts_channel', // Same as channel id
          'Prayer Alerts',
          channelDescription: 'Notifications for upcoming prayer times',
          importance: Importance.max,
          priority: Priority.high,
          playSound: true,
          sound: RawResourceAndroidNotificationSound('adhan'),
          enableVibration: true,
        );

    const NotificationDetails platformChannelSpecifics = NotificationDetails(
      android: androidPlatformChannelSpecifics,
    );

    await _notificationsPlugin.zonedSchedule(
      prayerName.hashCode, // Use prayerName to generate a unique ID
      prayerName, // Use prayerName as the title
      body,
      tz.TZDateTime.from(scheduledTime, tz.local),
      platformChannelSpecifics,
      androidScheduleMode: AndroidScheduleMode.exactAllowWhileIdle,
      matchDateTimeComponents: DateTimeComponents.dateAndTime,
    );
  }

  static Future<void> _playAdhanAudio() async {
    try {
      await _audioPlayer.stop(); // Stop any currently playing audio
      await _audioPlayer.setAsset('assets/audio/adhan.mp3');
      await _audioPlayer.play();
    } catch (e) {
      print('Error playing adhan audio: $e');
    }
  }

  static DateTime _parseTimeString(String timeStr) {
    final now = DateTime.now();
    final parts = timeStr.split(':');
    return DateTime(
      now.year,
      now.month,
      now.day,
      int.parse(parts[0]),
      int.parse(parts[1]),
    );
  }

  static Future<void> cancelAllAlarms() async {
    await _notificationsPlugin.cancelAll();
    await _audioPlayer.stop();
  }
}
