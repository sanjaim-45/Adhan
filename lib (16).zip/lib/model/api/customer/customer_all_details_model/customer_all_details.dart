class CustomerAllDetails {
  final bool success;
  final String message;
  final List<CustomerAll>? data;

  CustomerAllDetails({required this.success, required this.message, this.data});

  factory CustomerAllDetails.fromJson(Map<String, dynamic> json) {
    return CustomerAllDetails(
      success: json['success'] as bool,
      message: json['message'] as String,
      data:
          json['data'] != null
              ? (json['data'] as List)
                  .map((i) => CustomerAll.fromJson(i))
                  .toList()
              : null,
    );
  }
}

class CustomerAll {
  final int customerId;
  final String fullName;
  final String phoneNumber;
  final String email;
  final String? profileImagePath;
  final String? address;
  final String? civilId;
  final String? civilIdExpiryDate;
  final String createdDate;
  final bool isActive;
  final List<CustomerDevice> devices;

  CustomerAll({
    required this.customerId,
    required this.fullName,
    required this.phoneNumber,
    required this.email,
    this.profileImagePath,
    this.address,
    this.civilId,
    this.civilIdExpiryDate,
    required this.createdDate,
    required this.isActive,
    required this.devices,
  });

  factory CustomerAll.fromJson(Map<String, dynamic> json) {
    return CustomerAll(
      customerId: json['customerId'] as int,
      fullName: json['fullName'] as String,
      phoneNumber: json['phoneNumber'] as String,
      email: json['email'] as String,
      profileImagePath: json['profileImagePath'] as String?,
      address: json['address'] as String?,
      civilId: json['civilId'] as String?,
      civilIdExpiryDate: json['civilIdExpiryDate'] as String?,
      createdDate: json['createdDate'] as String,
      isActive: json['isActive'] as bool,
      devices:
          json['devices'] != null
              ? (json['devices'] as List)
                  .map((i) => CustomerDevice.fromJson(i))
                  .toList()
              : [],
    );
  }
}

class CustomerDevice {
  final int customerDeviceMapId;
  final int deviceId;
  final String deviceName;
  final String serialNumber;
  final String macAddress;
  final String ipAddress;
  final String qrPath;
  final bool deviceStatus;
  final String deviceCreatedDate;
  final Mosquess? mosque;
  final Subscriptionss subscription;

  CustomerDevice({
    required this.customerDeviceMapId,
    required this.deviceId,
    required this.deviceName,
    required this.serialNumber,
    required this.macAddress,
    required this.ipAddress,
    required this.qrPath,
    required this.deviceStatus,
    required this.deviceCreatedDate,
    this.mosque,
    required this.subscription,
  });

  factory CustomerDevice.fromJson(Map<String, dynamic> json) {
    return CustomerDevice(
      customerDeviceMapId: json['customerDeviceMapId'] as int,
      deviceId: json['deviceId'] as int,
      deviceName: json['deviceName'] as String,
      serialNumber: json['serialNumber'] as String,
      macAddress: json['macAddress'] as String,
      ipAddress: json['ipAddress'] as String,
      qrPath: json['qrPath'] as String,
      deviceStatus: json['deviceStatus'] as bool,
      deviceCreatedDate: json['deviceCreatedDate'] as String,
      mosque: json['mosque'] != null ? Mosquess.fromJson(json['mosque']) : null,
      subscription: Subscriptionss.fromJson(json['subscription']),
    );
  }
}

class Mosquess {
  final int mosqueId;
  final String mosqueName;
  final String mosqueLocation;
  final String streetName;
  final String area;
  final String city;
  final String governorate;
  final String paciNumber;
  final String contactPersonName;
  final String contactNumber;
  final bool mosqueMapStatus;
  final String mosqueMapCreatedDate;

  Mosquess({
    required this.mosqueId,
    required this.mosqueName,
    required this.mosqueLocation,
    required this.streetName,
    required this.area,
    required this.city,
    required this.governorate,
    required this.paciNumber,
    required this.contactPersonName,
    required this.contactNumber,
    required this.mosqueMapStatus,
    required this.mosqueMapCreatedDate,
  });

  factory Mosquess.fromJson(Map<String, dynamic> json) {
    return Mosquess(
      mosqueId: json['mosqueId'] as int,
      mosqueName: json['mosqueName'] as String,
      mosqueLocation: json['mosqueLocation'] as String,
      streetName: json['streetName'] as String,
      area: json['area'] as String,
      city: json['city'] as String,
      governorate: json['governorate'] as String,
      paciNumber: json['paciNumber'] as String,
      contactPersonName: json['contactPersonName'] as String,
      contactNumber: json['contactNumber'] as String,
      mosqueMapStatus: json['mosqueMapStatus'] as bool,
      mosqueMapCreatedDate: json['mosqueMapCreatedDate'] as String,
    );
  }
}

class Subscriptionss {
  final int subscriptionID;
  final int planID;
  final String startDate;
  final String endDate;
  final String paymentStatus;
  final double paidAmount;
  final String paymentMethod;
  final bool subscriptionStatus;

  Subscriptionss({
    required this.subscriptionID,
    required this.planID,
    required this.startDate,
    required this.endDate,
    required this.paymentStatus,
    required this.paidAmount,
    required this.paymentMethod,
    required this.subscriptionStatus,
  });

  factory Subscriptionss.fromJson(Map<String, dynamic> json) {
    return Subscriptionss(
      subscriptionID: json['subscriptionID'] as int,
      planID: json['planID'] as int,
      startDate: json['startDate'] as String,
      endDate: json['endDate'] as String,
      paymentStatus: json['paymentStatus'] as String,
      paidAmount: (json['paidAmount'] as num).toDouble(),
      paymentMethod: json['paymentMethod'] as String,
      subscriptionStatus: json['subscriptionStatus'] as bool,
    );
  }
}
