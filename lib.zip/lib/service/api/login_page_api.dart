import 'dart:convert';
import 'package:http/http.dart' as http;

import '../../model/api/login/login_model.dart';
import '../../utils/app_urls.dart';

class LoginService {

  static Future<LoginResponse> login({
    required String userName,
    required String password,
  }) async {
    final url = Uri.parse('${AppUrls().appUrl}/api/Login/Login');

    final response = await http.post(
      url,
      headers: {
        'Content-Type': 'application/json',
      },
      body: json.encode({
        'userName': userName,
        'password': password,
      }),
    );

    if (response.statusCode == 200) {
      return LoginResponse.fromJson(json.decode(response.body));
    } else {
      throw Exception('Failed to login: ${response.statusCode}');
    }
  }
}