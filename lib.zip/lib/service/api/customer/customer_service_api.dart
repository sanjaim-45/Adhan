import 'dart:convert';
import 'package:http/http.dart' as http;

import '../../../model/api/edit_customer/edit_customer_api_model.dart';

class CustomerService {
  final String baseUrl;

  CustomerService({required this.baseUrl});

  Future<Map<String, dynamic>> getCustomerById(int id) async {
    final response = await http.get(
      Uri.parse('$baseUrl/api/Customer/getCustomerById?id=$id'),
    );

    if (response.statusCode == 200) {
      return jsonDecode(response.body);
    } else {
      throw Exception('Failed to load customer data');
    }
  }

  Future<EditCustomerResponse> editCustomer(EditCustomerRequest request) async {
    final response = await http.post(
      Uri.parse('$baseUrl/api/Customer/EditCustomer'),
      headers: {
        'Content-Type': 'application/json',
      },
      body: json.encode(request.toJson()),
    );

    if (response.statusCode == 200) {
      return EditCustomerResponse.fromJson(json.decode(response.body));
    } else {
      throw Exception('Failed to update customer: ${response.statusCode}');
    }
  }
}