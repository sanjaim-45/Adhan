import 'dart:convert';
import 'dart:ui';

import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:intl/intl.dart';
import 'package:provider/provider.dart';

import '../../../providers/auth_providers.dart';
import '../../../utils/app_urls.dart';
import '../../widgets/prayer_card.dart';
import '../notification/notification_receiving_page.dart';
import '../subscription/upgrade.dart';
import 'package:http/http.dart' as http;

class PrayerHomePage extends StatefulWidget {
  const PrayerHomePage({super.key});

  @override
  State<PrayerHomePage> createState() => _PrayerHomePageState();
}

class _PrayerHomePageState extends State<PrayerHomePage> with AutomaticKeepAliveClientMixin {
  DateTime selectedDate = DateTime.now();
  Map<String, String> prayerTimes = {};
  bool isLoading = true;
  String errorMessage = '';
  @override
  bool get wantKeepAlive => true;
  late http.Client _httpClient;


  // Add your base URL and location coordinates here
  final double latitude = 12.8954570; // Replace with your actual latitude
  final double longitude = 80.1410546; // Replace with your actual longitude

  @override
  void initState() {
    super.initState();
    _httpClient = http.Client();

    _fetchPrayerTimes();
  }

  Future<void> _fetchPrayerTimes() async {
    if (!mounted) return;

    setState(() {
      isLoading = true;
      errorMessage = '';
    });

    try {
      final response = await _httpClient.post(
        Uri.parse('${AppUrls().appUrl}/api/PrayerTiming/GetPrayerTimings'),
        headers: {'Content-Type': 'application/json'},
        body: json.encode({
          "prayerDate": DateFormat('yyyy-MM-dd').format(selectedDate),
          "latitude": latitude,
          "longitude": longitude,
        }),
      );

      if (!mounted) return;

      if (response.statusCode == 200) {
        final data = json.decode(response.body);
        setState(() {
          prayerTimes = {
            'Fajr': data['fajr'],
            'Dhuhr': data['dhuhr'],
            'Asr': data['asr'],
            'Maghrib': data['maghrib'],
            'Isha': data['isha'],
          };
          isLoading = false;
        });
      } else {
        throw Exception('Failed to load prayer times');
      }
    } catch (e) {
      if (!mounted) return;
      setState(() {
        errorMessage = 'Failed to load prayer times. Please try again.';
        isLoading = false;
      });
    }
  }

  String _getPrayerStatus(String prayerName) {
    final now = DateTime.now();

    // If viewing a different day than today
    if (selectedDate.year != now.year ||
        selectedDate.month != now.month ||
        selectedDate.day != now.day) {
      return 'Upcoming';
    }

    try {
      final prayerTime = prayerTimes[prayerName]!;
      final prayerDateTime = DateFormat('HH:mm').parse(prayerTime);
      final prayerTimeToday = DateTime(
        now.year,
        now.month,
        now.day,
        prayerDateTime.hour,
        prayerDateTime.minute,
      );

      // Calculate absolute difference in minutes
      final differenceInMinutes = prayerTimeToday.difference(now).inMinutes.abs();
      final isAfterPrayerTime = now.isAfter(prayerTimeToday);

      if (isAfterPrayerTime) {
        // For times that have passed
        if (differenceInMinutes > 60) {
          return 'Completed'; // More than 1 hour passed
        } else {
          return 'Live'; // Within 1 hour after prayer time
        }
      } else {
        // For future times
        if (differenceInMinutes > 60) {
          return 'Upcoming'; // More than 1 hour before
        } else {
          return 'Live'; // Within 1 hour before prayer time
        }
      }
    } catch (e) {
      return 'Upcoming'; // Fallback in case of errors
    }
  }
  Color _getStatusColor(String status) {
    switch (status) {
      case 'Completed':
        return Colors.green;
      case 'Live':
        return Colors.red;
      case 'Upcoming':
      default:
        return Color(0xFFA1812E);
    }
  }

  String _getImagePath(String prayerName) {
    switch (prayerName) {
      case 'Fajr':
        return "assets/images/cloud/Sunny.png";
      case 'Dhuhr':
        return "assets/images/cloud/Partly-cloudy.png";
      case 'Asr':
        return "assets/images/cloud/Cloudy-clear at times-night.png";
      case 'Maghrib':
        return "assets/images/cloud/Cloudy-clear at times.png";
      case 'Isha':
      default:
        return "assets/images/cloud/Clear-night.png";
    }
  }
  @override
  void dispose() {
    _httpClient.close(); // Cancel any pending requests
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    super.build(context); // Important!

    final authProvider = Provider.of<AuthProvider>(context);

    final mediaQuery = MediaQuery.of(context);
    final screenHeight = mediaQuery.size.height;
    final screenWidth = mediaQuery.size.width;

    return Scaffold(
      backgroundColor: const Color(0xFF0C5E38),
      body: Column(
        children: [
          Stack(
            children: [
              Container(
                width: double.infinity,
                padding: EdgeInsets.only(
                  top: screenHeight * 0.04,
                  right: screenWidth * 0.05,
                ),
                decoration: const BoxDecoration(
                  gradient: RadialGradient(
                    center: Alignment.center,
                    radius: 0.8,
                    colors: [Color(0xFF2E7D32), Color(0xFF004408)],
                  ),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Padding(
                      padding: EdgeInsets.only(left: screenWidth * 0.05),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          // Logo Column
                          Image.asset(
                            "assets/images/name_logo.png",
                            height: screenHeight * 0.08,
                            width: screenWidth * 0.3,
                          ),

                          // Upgrade & Notification
                          Row(
                            children: [
                              // Only show Upgrade button if NOT a demo user
                              if (authProvider.isDemoUser)
                                ElevatedButton(
                                  onPressed: () {
                                    Navigator.of(context).push(
                                      MaterialPageRoute(
                                        builder:
                                            (context) => SubscriptionPage(),
                                      ),
                                    );
                                  },
                                  style: ElevatedButton.styleFrom(
                                    backgroundColor: const Color(0xFFA1812E),
                                    padding: EdgeInsets.symmetric(
                                      horizontal: screenWidth * 0.03,
                                      vertical: screenHeight * 0.015,
                                    ),
                                  ),
                                  child: Text(
                                    "Upgrade",
                                    style: GoogleFonts.beVietnamPro(
                                      color: Colors.white,
                                      fontWeight: FontWeight.w600,
                                      fontSize: screenWidth * 0.035,
                                    ),
                                  ),
                                ),
                              // Add spacing only if Upgrade button is shown
                              SizedBox(width: screenWidth * 0.02),
                              // Always show the notification icon
                              CircleAvatar(
                                radius: screenWidth * 0.05,
                                backgroundColor: Colors.white,
                                child: GestureDetector(
                                  onTap: () {
                                    Navigator.of(context).push(
                                      MaterialPageRoute(
                                        builder:
                                            (context) =>
                                                NotificationReceivingPage(),
                                      ),
                                    );
                                  },
                                  child: Icon(
                                    Icons.notifications_none_outlined,
                                    size: screenWidth * 0.05,
                                    color: Colors.black,
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),

                    // authProvider.isDemoUser
                    //   ?
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Padding(
                          padding: EdgeInsets.only(
                            left: screenWidth * 0.05,
                            top: screenHeight * 0.010,
                          ),
                          child: Row(
                            children: [
                              Text(
                                "NEXT PRAYER IN",
                                style: GoogleFonts.beVietnamPro(
                                  color: Colors.white70,
                                  fontSize: screenWidth * 0.03,
                                ),
                              ),
                              SizedBox(width: screenWidth * 0.02),
                              Container(
                                decoration: BoxDecoration(
                                  color: const Color(0xFFD4AF37),
                                  borderRadius: BorderRadius.circular(5),
                                ),
                                padding: EdgeInsets.symmetric(
                                  vertical: screenHeight * 0.004,
                                  horizontal: screenWidth * 0.02,
                                ),
                                child: Text(
                                  "51.25",
                                  style: GoogleFonts.beVietnamPro(
                                    fontSize: screenWidth * 0.025,
                                    color: Colors.white,
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),

                        // Maghrib + Arabic + Time
                        Padding(
                          padding: EdgeInsets.only(
                            left: screenWidth * 0.05,
                            top: screenHeight * 0.01,
                          ),
                          child: Text(
                            "Maghrib",
                            style: GoogleFonts.beVietnamPro(
                              fontSize: screenWidth * 0.08,
                              color: Colors.white,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ),
                        Padding(
                          padding: EdgeInsets.only(left: screenWidth * 0.05),
                          child: Text(
                            "المغرب",
                            style: GoogleFonts.beVietnamPro(
                              color: Colors.white,
                              fontSize: screenWidth * 0.04,
                            ),
                          ),
                        ),
                        Padding(
                          padding: EdgeInsets.only(
                            left: screenWidth * 0.05,
                            top: screenHeight * 0.005,
                          ),
                          child: Row(
                            children: [
                              Icon(
                                Icons.wb_sunny_outlined,
                                color: Colors.amber,
                                size: screenWidth * 0.06,
                              ),
                              SizedBox(width: screenWidth * 0.01),
                              Text(
                                DateFormat('hh:mm a').format(DateTime.now()),
                                style: GoogleFonts.beVietnamPro(
                                  fontSize: screenWidth * 0.055,
                                  color: Colors.white,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                    //:
                    // Column(
                    //   crossAxisAlignment: CrossAxisAlignment.start,
                    //
                    //   children: [
                    //         Padding(
                    //           padding: EdgeInsets.only(
                    //             left: screenWidth * 0.05,
                    //             top: screenHeight * 0.01,
                    //           ),
                    //           child: Text(
                    //             "🕌 Unlock the Voice of the Masjid",
                    //             style: GoogleFonts.beVietnamPro(
                    //               fontSize: screenWidth * 0.045,
                    //               color: Colors.white,
                    //               fontWeight: FontWeight.bold,
                    //             ),
                    //           ),
                    //         ),
                    //
                    //         Padding(
                    //           padding: EdgeInsets.only(
                    //             left: screenWidth * 0.05,
                    //             top: screenHeight * 0.01,
                    //           ),
                    //           child: Text(
                    //             "Subscribe monthly to listen to live salah directly from your masjid, wherever you are.",
                    //             style: GoogleFonts.beVietnamPro(
                    //               fontSize: screenWidth * 0.03,
                    //               color: Colors.white,
                    //               fontWeight: FontWeight.w400,
                    //             ),
                    //           ),
                    //         ),
                    //         SizedBox(
                    //           height: MediaQuery.of(context).size.height * 0.01,
                    //         ),
                    //         Padding(
                    //           padding: EdgeInsets.only(
                    //             left: screenWidth * 0.05,
                    //           ),
                    //           child: ElevatedButton.icon(
                    //             onPressed: () {
                    //               Navigator.of(context).push(MaterialPageRoute(builder: (context) => SubscriptionPage(),));
                    //             },
                    //             icon: Image.asset(
                    //               "assets/images/upgrade/king.png",
                    //               height:
                    //                   MediaQuery.of(context).size.height *
                    //                   0.020, // responsive height
                    //               width:
                    //                   MediaQuery.of(context).size.height *
                    //                   0.020, // responsive width
                    //             ),
                    //             label: Text(
                    //               'Subscribe',
                    //               style: GoogleFonts.beVietnamPro(
                    //                 color: Colors.white,
                    //                 fontSize:
                    //                     MediaQuery.of(context).size.width *
                    //                     0.03, // responsive text
                    //               ),
                    //             ),
                    //             style: ElevatedButton.styleFrom(
                    //               backgroundColor: const Color(0xFFD4AF37),
                    //               padding: EdgeInsets.symmetric(
                    //                 horizontal:
                    //                     MediaQuery.of(context).size.width *
                    //                     0.03,
                    //                 vertical:
                    //                     MediaQuery.of(context).size.height *
                    //                     0.018,
                    //               ),
                    //               shape: RoundedRectangleBorder(
                    //                 borderRadius: BorderRadius.circular(
                    //                   MediaQuery.of(context).size.height * 0.03,
                    //                 ),
                    //               ),
                    //             ),
                    //           ),
                    //         ),
                    //         SizedBox(
                    //           height: MediaQuery.of(context).size.height * 0.01,
                    //         ),
                    //       ],
                    //     ),
                    // Border image
                    Image.asset(
                      "assets/images/border_ui.png",
                      fit: BoxFit.cover,
                    ),
                  ],
                ),
              ),

              // Positioned Decorative Images
              Positioned(
                top: screenHeight * 0.05,
                right: screenWidth * 0.34,
                child: Transform.translate(
                  offset: Offset(0, screenHeight * 0.01),
                  child: Image.asset(
                    "assets/images/lamp_shot.png",
                    height: screenHeight * 0.1,
                  ),
                ),
              ),
              Positioned(
                top: screenHeight * 0.1,
                right: screenWidth * 0.26,
                child: Transform.translate(
                  offset: Offset(0, screenHeight * 0.01),
                  child: Image.asset(
                    "assets/images/lamp.png",
                    height: screenHeight * 0.1,
                  ),
                ),
              ),
              Positioned(
                top: screenHeight * 0.12,
                right: -screenWidth * 0.05,
                child: Transform.translate(
                  offset: Offset(0, screenHeight * 0.01),
                  child: Image.asset(
                    "assets/images/logo_blur.png",
                    height: screenHeight * 0.21,
                    width: screenWidth * 0.45,
                  ),
                ),
              ),
            ],
          ),

          // Bottom white section
          // Replace the Expanded widget section with this:
          Expanded(
            child: Stack(
              children: [
                // White background content (prayer cards)
                Container(
                  color: Colors.white,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Divider(
                        height: 0,
                        color: Colors.yellow,
                        thickness: 5,
                      ),
                      SizedBox(height: screenHeight * 0.015),
                      Padding(
                        padding: EdgeInsets.symmetric(
                          horizontal: screenWidth * 0.035,
                        ),
                        child: Text(
                          "🙌 Stay Aligned with the Call of Prayer",
                          style: GoogleFonts.beVietnamPro(
                            fontWeight: FontWeight.bold,
                            fontSize: screenWidth * 0.045,
                            letterSpacing: -0.4,
                          ),
                        ),
                      ),
                      Padding(
                        padding: EdgeInsets.symmetric(
                          horizontal: screenWidth * 0.035,
                          vertical: screenHeight * 0.005,
                        ),
                        child: Text(
                          "Check today’s prayer timings and stay connected to your masjid, wherever you are.",
                          style: GoogleFonts.beVietnamPro(
                            color: Colors.grey,
                            fontSize: screenWidth * 0.035,
                            letterSpacing: -0.4,
                          ),
                        ),
                      ),
                      Expanded(
                        child: ListView(
                          padding: EdgeInsets.only(top: screenHeight * 0.01),
                          children: [
                            PrayerCard(
                              imagePath: _getImagePath('Fajr'),
                              title: 'Fajr',
                              arabic: 'الفجر',
                              time: prayerTimes['Fajr'] ?? '--:--',
                              status: _getPrayerStatus('Fajr'),
                              statusColor: _getStatusColor(
                                  _getPrayerStatus('Fajr')),
                              trailingIcon: Icons.notifications,
                            ),
                            PrayerCard(
                              imagePath: _getImagePath('Dhuhr'),
                              title: 'Dhuhr',
                              arabic: 'الظهر',
                              time: prayerTimes['Dhuhr'] ?? '--:--',
                              status: _getPrayerStatus('Dhuhr'),
                              statusColor: _getStatusColor(
                                  _getPrayerStatus('Dhuhr')),
                              trailingIcon: Icons.notifications,
                            ),
                            PrayerCard(
                              imagePath: _getImagePath('Asr'),
                              title: 'Asr',
                              arabic: 'العصر',
                              time: prayerTimes['Asr'] ?? '--:--',
                              status: _getPrayerStatus('Asr'),
                              statusColor:
                              _getStatusColor(_getPrayerStatus('Asr')),
                            ),
                            PrayerCard(
                              imagePath: _getImagePath('Maghrib'),
                              title: 'Maghrib',
                              arabic: 'المغرب',
                              time: prayerTimes['Maghrib'] ?? '--:--',
                              status: _getPrayerStatus('Maghrib'),
                              statusColor: _getStatusColor(
                                  _getPrayerStatus('Maghrib')),
                            ),
                            PrayerCard(
                              imagePath: _getImagePath('Isha'),
                              title: 'Isha',
                              arabic: 'العشاء',
                              time: prayerTimes['Isha'] ?? '--:--',
                              status: _getPrayerStatus('Isha'),
                              statusColor:
                              _getStatusColor(_getPrayerStatus('Isha')),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),

                // Blur overlay (only shown if NOT a demo user)
                // if (!authProvider.isDemoUser)
                //   Positioned.fill(
                //     child: ClipRect(
                //       child: BackdropFilter(
                //         filter: ImageFilter.blur(sigmaX: 1, sigmaY: 1),
                //         child: Container(
                //           color: Colors.white.withOpacity(0.3),
                //           alignment: Alignment.center,
                //           child: Column(
                //             mainAxisAlignment: MainAxisAlignment.center,
                //             children: [],
                //           ),
                //         ),
                //       ),
                //     ),
                //   ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
