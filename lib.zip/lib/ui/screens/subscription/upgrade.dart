import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

import '../../../providers/auth_providers.dart';

class SubscriptionPage extends StatefulWidget {
  const SubscriptionPage({super.key});

  @override
  State<SubscriptionPage> createState() => _SubscriptionPageState();
}

class _SubscriptionPageState extends State<SubscriptionPage> {
  String selectedPlan = 'Monthly Plan'; // Default selected plan

  @override
  Widget build(BuildContext context) {
    final authProvider = Provider.of<AuthProvider>(context);

    return Scaffold(
      backgroundColor: Colors.white,
      body: Column(
        children: [
          Expanded(
            child: ListView(
              children: [
                Stack(
                  children: [
                    Image.asset("assets/images/upgrade/upgrade_top.png"),
                    Positioned(
                      top: 40, // Adjust based on your status bar height
                      left: 16,
                      child: GestureDetector(
                        onTap: () {
                          // Handle back button press
                          Navigator.pop(context);
                        },
                        child: Container(
                          margin: EdgeInsets.only(top: 10),
                          padding: EdgeInsets.all(8),
                          decoration: BoxDecoration(
                            color:
                                Colors
                                    .transparent, // Optional, set the background color if needed
                            borderRadius: BorderRadius.circular(5),
                            border: Border.all(
                              color: Colors.grey.withOpacity(
                                0.2,
                              ), // Set the border color
                              width: 1, // Set the border width
                            ),
                          ),
                          child: Icon(Icons.arrow_back_ios_new),
                        ),
                      ),
                    ),
                  ],
                ),
                Column(
                  children: [
                    Column(
                      children: [
                        RichText(
                          textAlign: TextAlign.center,
                          text: TextSpan(
                            style: GoogleFonts.beVietnamPro(
                              fontSize: 25,
                              fontWeight: FontWeight.bold,
                              height: 1.5,
                              color: Colors.black, // Default text color
                            ),
                            children: [
                              TextSpan(text: 'Your '),
                              TextSpan(
                                text: 'Masjid',
                                style: GoogleFonts.beVietnamPro(color: Color(0xFFA1812E)),
                              ),
                              TextSpan(text: '. Your\n '),
                              TextSpan(
                                text: 'Connection',
                                style: GoogleFonts.beVietnamPro(color: Color(0xFF2E7D32)),
                              ),
                              TextSpan(text: '. Your Time'),
                            ],
                          ),
                        ),

                        SizedBox(height: 10),
                        Text(
                          'Join Saut Al-Salaah for premium live audio streaming.\nStay connected to your masjid anytime, anywhere.\nSubscribe today.',
                          style: GoogleFonts.beVietnamPro(color: Colors.grey[600]),
                          textAlign: TextAlign.center,
                        ),
                      ],
                    ),

                    authProvider.isDemoUser
                        ?Padding(
                      padding: const EdgeInsets.all(16.0),
                      child: Container(
                        padding: EdgeInsets.all(16),
                        decoration: BoxDecoration(
                          gradient: LinearGradient(
                            colors: [Color(0xFF4CAF50), Color(0xFF006400)], // light to dark green
                            begin: Alignment.topLeft,
                            end: Alignment.bottomRight,
                          ),
                          borderRadius: BorderRadius.circular(12),
                        ),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Container(
                                  padding: EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                                  decoration: BoxDecoration(
                                    color: Colors.white.withOpacity(0.2),
                                    borderRadius: BorderRadius.circular(6),
                                  ),
                                  child: Text(
                                    'My Current Plan',
                                    style: GoogleFonts.beVietnamPro(
                                      color: Colors.white,
                                    ),

                                  ),
                                ),
                                Text.rich(
                                  TextSpan(
                                    children: [
                                      TextSpan(
                                        text: 'Expires on:',
                                        style: GoogleFonts.beVietnamPro(
                                          color: Colors.white,
                                        ),
                                      ),
                                      TextSpan(
                                        text: ' 25 Apr 2024',
                                        style: GoogleFonts.beVietnamPro(
                                          color: Color(0xFFF4DE8B),
                                          // Smaller font size for 'month'
                                          fontWeight:
                                          FontWeight
                                              .normal, // Not bold for 'month'
                                        ),
                                      ),
                                    ],
                                  ),

                                )],
                            ),
                            SizedBox(height: 15),
                            Text(
                              'Monthly',
                              style: GoogleFonts.beVietnamPro(
                                color: Colors.white,
                                fontSize: 14,
                              ),

                            ),
                            SizedBox(height: 5),
                            RichText(
                              text: TextSpan(
                                children: [
                                  TextSpan(
                                    text: '1000 KWD',
                                    style: GoogleFonts.beVietnamPro(
                                      color: Colors.white,
                                      fontSize: 18,
                                      fontWeight: FontWeight.bold,
                                    ),
                                  ),
                                  TextSpan(
                                    text: ' / month',
                                    style: GoogleFonts.beVietnamPro(
                                      color: Colors.white,
                                      fontSize:
                                      14, // Smaller font size for 'month'
                                      fontWeight:
                                      FontWeight
                                          .normal, // Not bold for 'month'
                                    ),

                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                      ),
                    )


                        : SizedBox(height: 20,),

                    Padding(
                      padding: EdgeInsets.symmetric(horizontal: 16),
                      child: SubscriptionCard(
                        title: 'Monthly Plan',
                        price: '1000 KWD',
                        tag: 'Recommended',
                        selected: selectedPlan == 'Monthly Plan',
                        onTap: () {
                          setState(() {
                            selectedPlan = 'Monthly Plan';
                          });
                        },
                      ),
                    ),
                    Padding(
                      padding: EdgeInsets.symmetric(horizontal: 16),
                      child: SubscriptionCard(
                        title: 'Quarterly Plan',
                        price: '20 KWD',
                        tag: 'Best',
                        selected: selectedPlan == 'Quarterly Plan',
                        onTap: () {
                          setState(() {
                            selectedPlan = 'Quarterly Plan';
                          });
                        },
                      ),
                    ),
                    Padding(
                      padding: EdgeInsets.symmetric(horizontal: 16),
                      child: SubscriptionCard(
                        title: 'Yearly Plan',
                        price: '30 KWD',
                        tag: 'Best',
                        selected: selectedPlan == 'Yearly Plan',
                        onTap: () {
                          setState(() {
                            selectedPlan = 'Yearly Plan';
                          });
                        },
                      ),
                    ),
                    SizedBox(height: 20),
                    Container(
                      padding: EdgeInsets.all(16),
                      margin: EdgeInsets.symmetric(horizontal: 16),
                      decoration: BoxDecoration(
                        color: Colors.yellow[50],
                        borderRadius: BorderRadius.circular(10),
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            "Features Unlocks",
                            style: GoogleFonts.beVietnamPro(
                              fontWeight: FontWeight.bold,
                              fontSize: 20,
                            ),
                          ),
                          SizedBox(height: 5),
                          Row(
                            children: [
                              Icon(Icons.check_circle, color: Colors.green),
                              SizedBox(width: 10),
                              Text(
                                'Full access to live prayer audio',
                                style: GoogleFonts.beVietnamPro(fontWeight: FontWeight.w600),
                              ),
                            ],
                          ),
                          SizedBox(height: 5),
                          Row(
                            children: [
                              Icon(Icons.check_circle, color: Colors.green),
                              SizedBox(width: 10),
                              Text(
                                'Prayer notifications & reminders',
                                style: GoogleFonts.beVietnamPro(fontWeight: FontWeight.w600),
                              ),
                            ],
                          ),
                          SizedBox(height: 5),
                          Row(
                            children: [
                              Icon(Icons.check_circle, color: Colors.green),
                              SizedBox(width: 10),
                              Text(
                                'Priority updates',
                                style: GoogleFonts.beVietnamPro(fontWeight: FontWeight.w600),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                    SizedBox(height: 20),
                  ],
                ),
              ],
            ),
          ),
          // Bottom CTA
          Container(
            padding: EdgeInsets.symmetric(horizontal: 16, vertical: 12),
            decoration: BoxDecoration(
              color: Colors.white,
              boxShadow: [BoxShadow(color: Colors.black12, blurRadius: 5)],
            ),
            child: Row(
              children: [
                Expanded(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.start,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        "3 months",
                        style: GoogleFonts.beVietnamPro(color: Color(0xFF2E7D32)),
                      ),
                      Text(
                        "10KWD",
                        style: GoogleFonts.beVietnamPro(
                          fontWeight: FontWeight.bold,
                          fontSize: 20,
                        ),
                      ),
                    ],
                  ),
                ),
                ElevatedButton.icon(
                  onPressed: () {
                    Navigator.of(context).push(
                      MaterialPageRoute(
                        builder: (context) => SubscriptionPage(),
                      ),
                    );
                  },
                  icon: Image.asset(
                    "assets/images/upgrade/king.png",
                    height: 20,
                    width: 20,
                  ),
                  label: Text(
                    'Subscribe',
                    style: GoogleFonts.beVietnamPro(color: Colors.white),
                  ),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Color(0xFF2E7D32),
                    padding: EdgeInsets.symmetric(horizontal: 24, vertical: 16),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12),
                    ),
                  ),
                ),
              ],
            ),
          ),
          SizedBox(height: MediaQuery.of(context).size.height * 0.01),
        ],
      ),
    );
  }
}

class SubscriptionCard extends StatelessWidget {
  final String title;
  final String price;
  final String tag;
  final bool selected;
  final VoidCallback? onTap;

  const SubscriptionCard({
    Key? key,
    required this.title,
    required this.price,
    required this.tag,
    this.selected = false,
    this.onTap,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Card(
        color: Colors.white,
        elevation: selected ? 3 : 0,
        shape: RoundedRectangleBorder(
          side:
              selected
                  ? BorderSide(color: Color(0xFF2E7D32), width: 2)
                  : BorderSide(color: Colors.grey[300]!),
          borderRadius: BorderRadius.circular(12),
        ),
        margin: EdgeInsets.only(bottom: 16),
        child: Padding(
          padding: EdgeInsets.all(16),
          child: Row(
            children: [
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Container(
                      padding: EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                      decoration: BoxDecoration(
                        color: Color(0xFFA1812E),
                        borderRadius: BorderRadius.circular(4),
                      ),
                      child: Text(
                        tag,
                        style: GoogleFonts.beVietnamPro(color: Colors.white, fontSize: 12),
                      ),
                    ),
                    SizedBox(height: 8),
                    Text(
                      title,
                      style: GoogleFonts.beVietnamPro(
                        color: Color(0xFF2E7D32),
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    SizedBox(height: 4),
                    Text(
                      '$price / month',
                      style: GoogleFonts.beVietnamPro(
                        fontSize: 18,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    SizedBox(height: 4),
                    Text('Subscribe today.', style: GoogleFonts.beVietnamPro()),
                  ],
                ),
              ),
              Icon(
                selected
                    ? Icons.radio_button_checked
                    : Icons.radio_button_unchecked,
                color: selected ? Colors.green : Colors.grey,
              ),
            ],
          ),
        ),
      ),
    );
  }
}
