import 'dart:convert';

import 'package:http/http.dart' as http;

import '../../../model/api/mosque/mosque_model.dart';

class MosqueService {
  final String baseUrl;

  MosqueService({required this.baseUrl});

  Future<MosqueResponse> getAllMosques() async {
    final response = await http.get(
      Uri.parse('$baseUrl/api/Mosque/getAllMosques'),
    );

    if (response.statusCode == 200) {
      return MosqueResponse.fromJson(json.decode(response.body));
    } else {
      throw Exception('Failed to load mosques');
    }
  }
}
