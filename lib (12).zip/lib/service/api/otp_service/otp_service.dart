// otp_service.dart

import 'dart:convert';

import 'package:flutter/cupertino.dart';
import 'package:http/http.dart' as http;
import 'package:provider/provider.dart';

import '../../../model/api/OTP/otp_models.dart';
import '../../../model/api/login/login_model.dart';
import '../../../providers/user_details_from_login/user_details.dart';
import '../templete_api/api_service.dart';
import '../tokens/token_service.dart';

class OtpService {
  final ApiService apiService;

  OtpService({required this.apiService});

  Future<OtpResponse> sendOtp(String phoneOrEmail) async {
    final url =
        '${apiService.baseUrl}/api/Customer/ResendOtp?PhoneOrEmail=$phoneOrEmail';

    final response = await apiService.sendRequest(
      url,
      'POST',
      headers: {'Content-Type': 'application/json'},
    );

    if (response.statusCode == 200) {
      return OtpResponse.fromJson(json.decode(response.body));
    } else {
      throw Exception('Failed to send OTP: ${response.statusCode}');
    }
  }

  Future<OtpResponse> sendOuterOtp(String phoneOrEmail) async {
    final url = Uri.parse(
      '${apiService.baseUrl}/api/Customer/ResendOtp?PhoneOrEmail=$phoneOrEmail',
    );

    final response = await http.post(
      url,
      headers: {'Content-Type': 'application/json'},
    );

    if (response.statusCode == 200) {
      return OtpResponse.fromJson(json.decode(response.body));
    } else {
      throw Exception('Failed to send OTP');
    }
  }

  Future<OtpResponse> verifyPhoneOuterOtp({
    required String phoneOrEmail,
    required String code,
  }) async {
    final url = Uri.parse(
      '${apiService.baseUrl}/api/Customer/VerifyChangePhoneOtp',
    );

    final body =
        VerifyOtpRequest(phoneOrEmail: phoneOrEmail, code: code).toJson();

    final response = await http.post(
      url,
      headers: {'Content-Type': 'application/json'},
      body: json.encode(body),
    );

    if (response.statusCode == 200) {
      return OtpResponse.fromJson(json.decode(response.body));
    } else {
      throw Exception('Failed to verify OTP');
    }
  }

  Future<OtpResponse> verifyPhoneOtp({
    required String phoneOrEmail,
    required String code,
  }) async {
    final url = '${apiService.baseUrl}/api/Customer/VerifyChangePhoneOtp';

    final body =
        VerifyOtpRequest(phoneOrEmail: phoneOrEmail, code: code).toJson();

    final response = await apiService.sendRequest(
      url,
      'POST',
      headers: {'Content-Type': 'application/json'},
      body: body,
    );

    if (response.statusCode == 200) {
      return OtpResponse.fromJson(json.decode(response.body));
    } else {
      throw Exception('Failed to verify OTP: ${response.statusCode}');
    }
  }

  // Add this to your otp_service.dart
  Future<LoginResponse> verifyLoginOtp({
    required String userName,
    required String otp,
    required BuildContext context,
  }) async {
    final url = '${apiService.baseUrl}/api/Login/LoginWithOtp';

    final body = {'userName': userName, 'otp': otp};

    final response = await apiService.sendRequest(
      url,
      'POST',
      headers: {'Content-Type': 'application/json'},
      body: body,
    );

    if (response.statusCode == 200) {
      // Parse the response body
      final loginResponse = LoginResponse.fromJson(json.decode(response.body));

      // Case-insensitive header lookup
      final accessToken = _getHeaderCaseInsensitive(
        response.headers,
        'access-token',
      );
      final refreshToken = _getHeaderCaseInsensitive(
        response.headers,
        'refresh-token',
      );

      if (accessToken == null || refreshToken == null) {
        throw Exception(
          'Tokens not found in response headers. Available headers: ${response.headers.keys}',
        );
      }

      // Save tokens to SharedPreferences
      await TokenService.saveTokens(accessToken, refreshToken);

      // Save user details
      final userDetailsProvider = Provider.of<UserDetailsProvider>(
        context,
        listen: false,
      );

      if (loginResponse.customerDetailResponse.subscription != null) {
        final subscription = loginResponse.customerDetailResponse.subscription!;

        await userDetailsProvider.updateUserDetails(
          fullName: '${subscription.firstName} ${subscription.lastName}',
          mosque: subscription.mosque,
          mosqueLocation: subscription.mosqueLocation,
        );

        // ✅ Only update subscription details if subscriptionPlan is not null
        if (subscription.subscriptionPlan != null) {
          final plan = subscription.subscriptionPlan!;
          await userDetailsProvider.updateSubscriptionDetails(
            planName: plan.planName,
            billingCycle: plan.billingCycle,
            price: plan.price,
            currency: plan.currency,
            remainingDays: plan.remainingDays,
          );
        } else {
          // Clear or skip subscription details
          await userDetailsProvider.clearSubscription();
        }
      } else {
        // No subscription at all
        await userDetailsProvider.updateUserDetails(
          fullName: '',
          mosque: '',
          mosqueLocation: '',
        );
        await userDetailsProvider.clearSubscription();
      }

      return loginResponse;
    } else {
      throw Exception('Failed to verify OTP: ${response.statusCode}');
    }
  }

  static String? _getHeaderCaseInsensitive(
    Map<String, String> headers,
    String key,
  ) {
    final lowerKey = key.toLowerCase();
    for (final headerKey in headers.keys) {
      if (headerKey.toLowerCase() == lowerKey) {
        return headers[headerKey];
      }
    }
    return null;
  }
}
