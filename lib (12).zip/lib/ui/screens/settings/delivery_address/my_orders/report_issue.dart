import 'dart:io';

import 'package:dotted_border/dotted_border.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:image_picker/image_picker.dart';
import 'package:path/path.dart' as path;

import '../../../../../utils/font_mediaquery.dart';
import 'request_submitted.dart';

class ReturnRequestFormPage extends StatefulWidget {
  const ReturnRequestFormPage({super.key});

  @override
  State<ReturnRequestFormPage> createState() => _ReturnRequestFormPageState();
}

class _ReturnRequestFormPageState extends State<ReturnRequestFormPage> {
  final _formKey = GlobalKey<FormState>();
  String? selectedReason;
  bool useSavedAddress = false;
  List<XFile> _selectedImages = [];

  final List<String> reasons = [
    "Device not working",
    "Received wrong item",
    "Damaged on arrival",
    "Other",
  ];

  Future<void> _pickImages() async {
    final ImagePicker picker = ImagePicker();
    final List<XFile>? images = await picker.pickMultiImage();

    if (images != null) {
      setState(() {
        _selectedImages.addAll(images);
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: PreferredSize(
        preferredSize: const Size.fromHeight(80),
        child: Container(
          decoration: BoxDecoration(
            color: Colors.white,
            boxShadow: [
              BoxShadow(
                color: Colors.grey.withOpacity(0.1),
                spreadRadius: 1,
                blurRadius: 8,
                offset: const Offset(0, 4),
              ),
            ],
          ),
          child: Padding(
            padding: const EdgeInsets.only(
              top: 20.0,
            ), // Add padding to push content down
            child: AppBar(
              backgroundColor: Colors.white,
              elevation: 0,
              leadingWidth: 70,
              leading: Padding(
                padding: const EdgeInsets.only(left: 10.0),
                child: GestureDetector(
                  onTap: () => Navigator.of(context).pop(),
                  child: Container(
                    margin: EdgeInsets.all(10),
                    decoration: BoxDecoration(
                      border: Border.all(
                        width: 1,
                        color: Colors.grey.withOpacity(0.5),
                      ), // Optional: specify color
                      borderRadius: BorderRadius.circular(5),
                    ),

                    width: 40,
                    height: 15, // This constrains the arrow container size
                    child: const Icon(
                      Icons.arrow_back_ios_new_rounded,
                      size: 15, // Icon size
                      color: Colors.black,
                    ),
                  ),
                ),
              ),
              title: Padding(
                padding: const EdgeInsets.only(
                  top: 0.0,
                ), // Adjust title position if needed
                child: Text(
                  'Return Request Forms',
                  style: GoogleFonts.beVietnamPro(
                    color: Colors.black,
                    letterSpacing: -0.5,
                    fontSize: getDynamicFontSize(context, 0.05),
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
            ),
          ),
        ),
      ),

      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Form(
          key: _formKey,
          child: ListView(
            children: [
              const Text(
                "Reason for Return",
                style: TextStyle(fontWeight: FontWeight.w600),
              ),
              const SizedBox(height: 8),
              DropdownButtonFormField<String>(
                icon: const Icon(Icons.keyboard_arrow_down_sharp),
                iconEnabledColor: const Color(0xFF2E7D32),
                dropdownColor: Colors.white,
                hint: const Text("e.g. Device not working"),
                style: TextStyle(color: Colors.black),

                value: selectedReason,
                items:
                    reasons
                        .map(
                          (reason) => DropdownMenuItem(
                            value: reason,
                            child: Text(reason),
                          ),
                        )
                        .toList(),
                onChanged: (value) {
                  setState(() {
                    selectedReason = value;
                  });
                },
                menuMaxHeight: 200,
                // offset: const Offset(0, -10), // This property is not available for DropdownButtonFormField
                decoration: InputDecoration(
                  contentPadding: const EdgeInsets.symmetric(
                    horizontal: 12,
                    vertical: 16,
                  ),
                  enabledBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(12),
                    borderSide: const BorderSide(
                      color: Color(0xFFEBEBEB),
                    ), // Default color #EBEBEB
                  ),
                  focusedBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(12),
                    borderSide: const BorderSide(
                      color: Color(0xFF2E7D32),
                    ), // Color when focused
                  ),
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(12),
                    borderSide: const BorderSide(
                      color: Color(0xFFEBEBEB),
                    ), // Default color #EBEBEB
                  ),
                ),
              ),
              const SizedBox(height: 16),
              const Text(
                "Reason Details",
                style: TextStyle(fontWeight: FontWeight.w600),
              ),
              const SizedBox(height: 8),
              TextFormField(
                maxLines: 3,
                decoration: InputDecoration(
                  hintStyle: TextStyle(color: Color(0xFFA1A1A1)),
                  hintText:
                      'e.g., "Speaker has a crack and does not power on."',
                  enabledBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(12),
                    borderSide: const BorderSide(
                      color: Color(0xFFEBEBEB),
                    ), // Default color #EBEBEB
                  ),
                  focusedBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(12),
                    borderSide: const BorderSide(
                      color: Color(0xFF2E7D32),
                    ), // Color when focused
                  ),
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(12),
                    borderSide: const BorderSide(
                      color: Color(0xFFEBEBEB),
                    ), // Default color #EBEBEB
                  ),
                ),
              ),
              const SizedBox(height: 16),
              const Text(
                "Upload Photos",
                style: TextStyle(fontWeight: FontWeight.w600),
              ),
              const SizedBox(height: 8),
              GestureDetector(
                onTap: () {
                  _pickImages();
                },
                child: const DottedBorderWidget(),
              ),
              const SizedBox(height: 12),
              if (_selectedImages.isNotEmpty)
                ListView.builder(
                  shrinkWrap: true,
                  physics: const NeverScrollableScrollPhysics(),
                  itemCount: _selectedImages.length,
                  itemBuilder: (context, index) {
                    final image = _selectedImages[index];
                    return UploadedFileWidget(
                      fileName: path.basename(image.path),
                      fileSize:
                          "${(File(image.path).lengthSync() / 1024).toStringAsFixed(2)} KB",
                      imagePath: image.path, // Pass the image path
                      onDelete: () {
                        setState(() {
                          _selectedImages.removeAt(index);
                        });
                      },
                      onView: () {
                        showDialog(
                          context: context,
                          builder: (BuildContext context) {
                            return Dialog(
                              child: Column(
                                mainAxisSize: MainAxisSize.min,
                                children: [Image.file(File(image.path))],
                              ),
                            );
                          },
                        );
                      },
                    );
                  },
                ),
              const SizedBox(height: 12),
              CheckboxListTile(
                title: const Text("Use saved delivery address"),
                value: useSavedAddress,
                onChanged: (val) {
                  setState(() {
                    useSavedAddress = val!;
                  });
                },
                controlAffinity: ListTileControlAffinity.leading,
                contentPadding: EdgeInsets.zero,
              ),
              const SizedBox(height: 16),
              SizedBox(
                width: double.infinity,
                child: ElevatedButton(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Color(0xFF2E7D32),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12),
                    ),
                    padding: const EdgeInsets.symmetric(vertical: 16),
                  ),
                  onPressed: () {
                    if (_formKey.currentState!.validate()) {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) => const RequestSubmitted(),
                        ),
                      );
                    }
                  },
                  child: const Text(
                    'Submit Request',
                    style: TextStyle(fontSize: 16, color: Colors.white),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class DottedBorderWidget extends StatelessWidget {
  const DottedBorderWidget({super.key});

  @override
  Widget build(BuildContext context) {
    return DottedBorder(
      options: RectDottedBorderOptions(
        dashPattern: [10, 5],
        strokeWidth: 1,
        color: Color(0xFFEBEBEB),
        padding: EdgeInsets.all(16),
      ),
      child: Container(
        height: 120,
        decoration: BoxDecoration(borderRadius: BorderRadius.circular(12)),
        child: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: const [
              CircleAvatar(
                backgroundColor: Color(0xFFF5F5F5),
                child: Icon(
                  Icons.upload_file_outlined,
                  size: 28,
                  color: Color(0xFF2E7D32),
                ),
              ),
              SizedBox(height: 8),
              Text(
                "Click to Upload",
                style: TextStyle(
                  color: Color(0xFF2E7D32),
                  fontWeight: FontWeight.w600,
                ),
              ),
              SizedBox(height: 4),
              Text("(Max. File size: 5 MB)", style: TextStyle()),
            ],
          ),
        ),
      ),
    );
  }
}

class UploadedFileWidget extends StatelessWidget {
  final String fileName;
  final String fileSize;
  final VoidCallback onDelete;
  final VoidCallback onView;
  final String imagePath; // Add this line

  const UploadedFileWidget({
    super.key,
    required this.fileName,
    required this.fileSize,
    required this.onDelete,
    required this.onView,
    required this.imagePath, // Add this line
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.only(bottom: 8.0),
      decoration: BoxDecoration(
        border: Border.all(color: Color(0xFFEBEBEB)),
        borderRadius: BorderRadius.circular(12),
      ),
      child: ListTile(
        leading: SizedBox(
          width: 40, // Constrain the width of the leading widget
          child: Image.file(
            File(imagePath), // Use the picked image path
            width: 40,
            height: 40,
            fit: BoxFit.cover,
          ),
        ),
        title: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text(
              fileName,
              style: TextStyle(fontSize: 12, fontWeight: FontWeight.bold),
            ),
            Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                InkWell(
                  onTap: onDelete,
                  child: Image.asset(
                    'assets/images/trash.png', // Ensure this path is correct
                    width: 24, // Adjust size as needed
                    height: 24, // Adjust size as needed
                  ),
                ),
              ],
            ),
          ],
        ),
        subtitle: Column(
          mainAxisAlignment: MainAxisAlignment.start,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(fileSize, style: TextStyle(color: Color(0xFF989692))),
            InkWell(
              onTap: onView,
              child: const Text(
                "Click to View",
                style: TextStyle(
                  color: Color(0xFFA020F0),
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
