import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

import '../../../../utils/font_mediaquery.dart';

class AddDeliveryAddressPage extends StatefulWidget {
  const AddDeliveryAddressPage({super.key});

  @override
  _AddDeliveryAddressPageState createState() => _AddDeliveryAddressPageState();
}

class _AddDeliveryAddressPageState extends State<AddDeliveryAddressPage> {
  final _fullNameController = TextEditingController();
  final _mobileNumberController = TextEditingController();
  final _emailController = TextEditingController();
  final _addressController = TextEditingController();
  bool isDefault = false;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: PreferredSize(
        preferredSize: const Size.fromHeight(80),
        child: Container(
          decoration: BoxDecoration(
            color: Colors.white,
            boxShadow: [
              BoxShadow(
                color: Colors.grey.withOpacity(0.1),
                spreadRadius: 1,
                blurRadius: 8,
                offset: const Offset(0, 4),
              ),
            ],
          ),
          child: Padding(
            padding: const EdgeInsets.only(
              top: 20.0,
            ), // Add padding to push content down
            child: AppBar(
              backgroundColor: Colors.white,
              elevation: 0,
              leadingWidth: 70,
              leading: Padding(
                padding: const EdgeInsets.only(left: 10.0),
                child: GestureDetector(
                  onTap: () => Navigator.of(context).pop(),
                  child: Container(
                    margin: EdgeInsets.all(10),
                    decoration: BoxDecoration(
                      border: Border.all(
                        width: 1,
                        color: Colors.grey.withOpacity(0.5),
                      ), // Optional: specify color
                      borderRadius: BorderRadius.circular(5),
                    ),

                    width: 40,
                    height: 15, // This constrains the arrow container size
                    child: const Icon(
                      Icons.arrow_back_ios_new_rounded,
                      size: 15, // Icon size
                      color: Colors.black,
                    ),
                  ),
                ),
              ),
              title: Padding(
                padding: const EdgeInsets.only(
                  top: 0.0,
                ), // Adjust title position if needed
                child: Text(
                  'Delivery Address',
                  style: GoogleFonts.beVietnamPro(
                    color: Colors.black,
                    letterSpacing: -0.5,
                    fontSize: getDynamicFontSize(context, 0.05),
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
            ),
          ),
        ),
      ),
      body: Padding(
        padding: const EdgeInsets.fromLTRB(
          16.0,
          16.0,
          16.0,
          0,
        ), // Adjust bottom padding to 0
        child: Column(
          // Changed from ListView to Column
          children: <Widget>[
            Expanded(
              // Wrap the scrollable content in Expanded
              child: ListView(
                children: <Widget>[
                  _buildTextField(
                    label: 'Full Name',
                    hint: 'e.g. Ahmed Al-Mutairi',
                    controller: _fullNameController,
                  ),
                  _buildTextField(
                    label: 'Mobile Number',
                    hint: 'e.g. +965 50123456',
                    controller: _mobileNumberController,
                    keyboardType: TextInputType.phone,
                  ),
                  _buildTextField(
                    label: 'Email Address',
                    hint: 'e.g. ahmed@email.com',
                    controller: _emailController,
                    keyboardType: TextInputType.emailAddress,
                  ),
                  _buildTextField(
                    label: 'Home Address',
                    hint: 'e.g. 123 Main St, Kuwait City',
                    controller: _addressController,
                    maxLines: 3,
                  ),
                  Row(
                    children: [
                      Checkbox(
                        value: isDefault,
                        onChanged: (val) {
                          setState(() {
                            isDefault = val ?? false;
                          });
                        },
                      ),
                      Text("Make this my default Address"),
                    ],
                  ),
                ],
              ),
            ),
            SizedBox(height: 20),
            Padding(
              // Add padding for the button
              padding: const EdgeInsets.only(bottom: 16.0),
              child: SizedBox(
                height: 56,
                width: double.infinity, // Make button take full width
                child: ElevatedButton(
                  onPressed: () {
                    // Add save logic here
                  },
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Color(0xFF2E7D32),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12),
                    ),
                  ),
                  child: Text(
                    'Save Address',
                    style: TextStyle(fontSize: 16, color: Colors.white),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildTextField({
    required String label,
    required String hint,
    required TextEditingController controller,
    TextInputType keyboardType = TextInputType.text,
    int maxLines = 1,
  }) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 16.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            label,
            style: TextStyle(
              fontWeight: FontWeight.w600,
              color: Color(0xFF3A4354),
            ),
          ),
          SizedBox(height: 8),
          TextField(
            controller: controller,
            keyboardType: keyboardType,
            maxLines: maxLines,
            decoration: InputDecoration(
              hintText: hint,
              hintStyle: TextStyle(color: Color(0xFFA1A1A1)),
              filled: true,
              fillColor: Colors.white,
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(12),
                borderSide: BorderSide(color: Colors.grey.shade300),
              ),
              enabledBorder: OutlineInputBorder(
                borderRadius: BorderRadius.circular(12),
                borderSide: BorderSide(color: Colors.grey.shade300),
              ),
              contentPadding: EdgeInsets.symmetric(
                horizontal: 16,
                vertical: 14,
              ),
            ),
          ),
        ],
      ),
    );
  }
}

// @override
// Widget build(BuildContext context) {
//   return Scaffold(
//     backgroundColor: Colors.white,
//     appBar: PreferredSize(
//       preferredSize: const Size.fromHeight(80),
//       child: Container(
//         decoration: BoxDecoration(
//           color: Colors.white,
//           boxShadow: [
//             BoxShadow(
//               color: Colors.grey.withOpacity(0.1),
//               spreadRadius: 1,
//               blurRadius: 8,
//               offset: const Offset(0, 4),
//             ),
//           ],
//         ),
//         child: Padding(
//           padding: const EdgeInsets.only(
//             top: 20.0,
//           ), // Add padding to push content down
//           child: AppBar(
//             backgroundColor: Colors.white,
//             elevation: 0,
//             leadingWidth: 70,
//             leading: Padding(
//               padding: const EdgeInsets.only(left: 10.0),
//               child: GestureDetector(
//                 onTap: () => Navigator.of(context).pop(),
//                 child: Container(
//                   margin: EdgeInsets.all(10),
//                   decoration: BoxDecoration(
//                     border: Border.all(
//                       width: 1,
//                       color: Colors.grey.withOpacity(0.5),
//                     ), // Optional: specify color
//                     borderRadius: BorderRadius.circular(5),
//                   ),
//
//                   width: 40,
//                   height: 15, // This constrains the arrow container size
//                   child: const Icon(
//                     Icons.arrow_back_ios_new_rounded,
//                     size: 15, // Icon size
//                     color: Colors.black,
//                   ),
//                 ),
//               ),
//             ),
//             title: Padding(
//               padding: const EdgeInsets.only(
//                 top: 0.0,
//               ), // Adjust title position if needed
//               child: Text(
//                 'Delivery Address',
//                 style: GoogleFonts.beVietnamPro(
//                   color: Colors.black,
//                   letterSpacing: -0.5,
//                   fontSize: getDynamicFontSize(context, 0.05),
//                   fontWeight: FontWeight.bold,
//                 ),
//               ),
//             ),
//           ),
//         ),
//       ),
//     ),
//     body: Padding(
//       padding: const EdgeInsets.fromLTRB(
//         16.0,
//         16.0,
//         16.0,
//         0,
//       ), // Adjust bottom padding to 0
//       child: Column(
//         // Changed from ListView to Column
//         children: <Widget>[
//           Expanded(
//             // Wrap the scrollable content in Expanded
//             child: ListView(
//               children: <Widget>[
//                 _buildTextField(
//                   label: 'Full Name',
//                   hint: 'e.g. Ahmed Al-Mutairi',
//                   controller: _fullNameController,
//                 ),
//                 _buildTextField(
//                   label: 'Mobile Number',
//                   hint: 'e.g. +965 50123456',
//                   controller: _mobileNumberController,
//                   keyboardType: TextInputType.phone,
//                 ),
//                 _buildTextField(
//                   label: 'Email Address',
//                   hint: 'e.g. ahmed@email.com',
//                   controller: _emailController,
//                   keyboardType: TextInputType.emailAddress,
//                 ),
//                 _buildTextField(
//                   label: 'Home Address',
//                   hint: 'e.g. 123 Main St, Kuwait City',
//                   controller: _addressController,
//                   maxLines: 3,
//                 ),
//                 Row(
//                   children: [
//                     Checkbox(
//                       value: isDefault,
//                       onChanged: (val) {
//                         setState(() {
//                           isDefault = val ?? false;
//                         });
//                       },
//                     ),
//                     Text("Make this my default Address"),
//                   ],
//                 ),
//               ],
//             ),
//           ),
//           SizedBox(height: 20),
//           Padding(
//             // Add padding for the button
//             padding: const EdgeInsets.only(bottom: 16.0),
//             child: SizedBox(
//               height: 56,
//               width: double.infinity, // Make button take full width
//               child: ElevatedButton(
//                 onPressed: () {
//                   // Add save logic here
//                 },
//                 style: ElevatedButton.styleFrom(
//                   backgroundColor: Color(0xFF2E7D32),
//                   shape: RoundedRectangleBorder(
//                     borderRadius: BorderRadius.circular(12),
//                   ),
//                 ),
//                 child: Text(
//                   'Save Address',
//                   style: TextStyle(fontSize: 16, color: Colors.white),
//                 ),
//               ),
//             ),
//           ),
//         ],
//       ),
//     ),
//   );
// }
