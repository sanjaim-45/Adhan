import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:prayerunitesss/service/api/delete_account/delete_account_service.dart';
import 'package:prayerunitesss/ui/screens/settings/change_password/change_password_ui.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../../../utils/font_mediaquery.dart';
import '../login_page/login_page.dart';

class SettingsPage extends StatefulWidget {
  const SettingsPage({super.key});

  @override
  State<SettingsPage> createState() => _SettingsPageState();
}

class _SettingsPageState extends State<SettingsPage> {
  bool isEnglish = true;

  @override
  Widget build(BuildContext context) {
    final mediaQuery = MediaQuery.of(context);
    final screenHeight = mediaQuery.size.height;
    final screenWidth = mediaQuery.size.width;
    return Scaffold(
      appBar: PreferredSize(
        preferredSize: const Size.fromHeight(kToolbarHeight),
        child: Container(
          decoration: BoxDecoration(
            color: Colors.white,
            boxShadow: [
              BoxShadow(
                color: Colors.grey.withOpacity(0.1),
                spreadRadius: 1,
                blurRadius: 8,
                offset: const Offset(0, 4),
              ),
            ],
          ),
          child: AppBar(
            backgroundColor: Colors.white,
            elevation: 1,
            leadingWidth: 70,
            leading: Padding(
              padding: const EdgeInsets.only(left: 10.0),
              child: GestureDetector(
                onTap: () => Navigator.of(context).pop(),
                child: Container(
                  margin: EdgeInsets.all(10),
                  decoration: BoxDecoration(
                    border: Border.all(
                      width: 1,
                      color: Colors.grey.withOpacity(0.5),
                    ), // Optional: specify color
                    borderRadius: BorderRadius.circular(5),
                  ),

                  width: 40,
                  height: 15, // This constrains the arrow container size
                  child: const Icon(
                    Icons.arrow_back_ios_new_rounded,
                    size: 15, // Icon size
                    color: Colors.black,
                  ),
                ),
              ),
            ),
            title: Text(
              'Settings',
              style: GoogleFonts.beVietnamPro(
                color: Colors.black,
                letterSpacing: -0.5,
                fontSize: getDynamicFontSize(context, 0.05),
                fontWeight: FontWeight.bold,
              ),
            ),
          ),
        ),
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          // Preferred Language Section
          const Text(
            'Preferred Language',
            style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
          ),
          const SizedBox(height: 8),
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(12),
              boxShadow: const [
                BoxShadow(
                  color: Colors.black12,
                  blurRadius: 6,
                  offset: Offset(0, 2),
                ),
              ],
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(
                  "Select the language you'd like to use for this App.",
                  style: TextStyle(color: Color(0xFF333333)),
                ),
                const SizedBox(height: 12),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    const Text('Arabic'),

                    SwitchTheme(
                      data: SwitchThemeData(
                        thumbColor: MaterialStateProperty.resolveWith<Color>((
                          states,
                        ) {
                          return Colors.white; // Thumb color (always white)
                        }),
                        trackColor: MaterialStateProperty.resolveWith<Color>((
                          states,
                        ) {
                          if (states.contains(MaterialState.selected)) {
                            return const Color(
                              0xFF3B873E,
                            ); // Active track color (green)
                          }
                          return const Color(
                            0xFFF2F4F7,
                          ); // Inactive track color (gray)
                        }),
                        trackOutlineColor:
                            WidgetStateProperty.resolveWith<Color>((states) {
                              if (states.contains(WidgetState.selected)) {
                                return Colors
                                    .transparent; // No border when active
                              }
                              return Colors
                                  .transparent; // Black border when inactive
                            }),
                        trackOutlineWidth:
                            WidgetStateProperty.resolveWith<double>((states) {
                              return 0.0; // Border width (1px)
                            }),
                      ),
                      child: Switch(
                        value: !isEnglish,
                        onChanged: (value) {
                          setState(() {
                            isEnglish = !value;
                          });
                        },
                        materialTapTargetSize: MaterialTapTargetSize.padded,
                      ),
                    ),
                    // Switch(
                    //   value: !isEnglish,
                    //   onChanged: (value) {
                    //     setState(() {
                    //       isEnglish = !value;
                    //     });
                    //   },
                    // ),
                  ],
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    const Text('English'),
                    SwitchTheme(
                      data: SwitchThemeData(
                        thumbColor: MaterialStateProperty.resolveWith<Color>((
                          states,
                        ) {
                          return Colors.white; // Thumb color (always white)
                        }),
                        trackColor: MaterialStateProperty.resolveWith<Color>((
                          states,
                        ) {
                          if (states.contains(MaterialState.selected)) {
                            return const Color(
                              0xFF3B873E,
                            ); // Active track color (green)
                          }
                          return const Color(
                            0xFFF2F4F7,
                          ); // Inactive track color (gray)
                        }),
                        trackOutlineColor:
                            WidgetStateProperty.resolveWith<Color>((states) {
                              if (states.contains(WidgetState.selected)) {
                                return Colors
                                    .transparent; // No border when active
                              }
                              return Colors
                                  .transparent; // Black border when inactive
                            }),
                        trackOutlineWidth:
                            WidgetStateProperty.resolveWith<double>((states) {
                              return 0.0; // Border width (1px)
                            }),
                      ),
                      child: Switch(
                        value: !isEnglish,
                        onChanged: (value) {
                          setState(() {
                            isEnglish = !value;
                          });
                        },
                        materialTapTargetSize: MaterialTapTargetSize.padded,
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
          const SizedBox(height: 24),

          // Account Section
          const Text(
            'Account',
            style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
          ),
          const SizedBox(height: 8),
          _buildAccountTile(
            Icons.lock_outline,
            'Change Password',
            onTap: () {
              Navigator.of(context).push(
                MaterialPageRoute(builder: (context) => ChangePasswordPage()),
              );
            },
          ),
          _buildAccountTile(
            Icons.delete_outline,
            'Delete My Account',
            iconColor: Colors.green,
            onTap: () async {
              final prefs = await SharedPreferences.getInstance();
              final customerIdString = prefs.getString('customerId');

              if (customerIdString != null) {
                final customerId = int.parse(
                  customerIdString,
                ); // Convert to int
                return showDeleteAccountBottomSheet(context, customerId);
              }
            },
          ),

          const SizedBox(height: 24),

          // Policies & Support
          const Text(
            'Policies & Support',
            style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
          ),
          const SizedBox(height: 8),
          _buildPolicyTile(Icons.fact_check_outlined, 'Terms & Conditions'),
          _buildPolicyTile(Icons.verified_user_outlined, 'Privacy Policy'),
        ],
      ),
      backgroundColor: const Color(0xFFF9F9F9),
    );
  }

  Widget _buildAccountTile(
    IconData icon,
    String title, {
    Color iconColor = Colors.green,
    required VoidCallback onTap,
  }) {
    return Container(
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(12),
      ),
      child: ListTile(
        leading: Icon(icon, color: iconColor),
        title: Text(title),
        onTap: onTap, // now uses the passed-in callback
      ),
    );
  }

  Widget _buildPolicyTile(IconData icon, String title) {
    return Card(
      color: Colors.white,
      elevation: 0,
      margin: const EdgeInsets.symmetric(vertical: 4),
      child: ListTile(
        leading: Icon(icon, color: Colors.green),
        title: Text(title),
        onTap: () {
          // TODO: Navigate or perform action
        },
      ),
    );
  }
}

void showDeleteAccountBottomSheet(BuildContext context, int customerId) {
  showModalBottomSheet(
    backgroundColor: Colors.white,
    context: context,
    isScrollControlled: true,
    shape: RoundedRectangleBorder(
      borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
    ),
    builder: (context) {
      return Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Align(
              alignment: Alignment.topRight,
              child: GestureDetector(
                onTap: () => Navigator.of(context).pop(),
                child: Container(
                  padding: const EdgeInsets.all(6),
                  decoration: BoxDecoration(
                    border: Border.all(color: Colors.grey.shade300),
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: const Icon(Icons.close, size: 20),
                ),
              ),
            ),
            const SizedBox(height: 20),
            // Trash Icon
            Image.asset(
              "assets/images/delete_account_ui.png",
              height: 120,
              width: 130,
            ),
            const SizedBox(height: 16),
            // Title
            const Text(
              'Delete Account',
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 12),
            // Description
            Text(
              'Your account will be deleted. If you change your mind, you can log back in before the process is complete to cancel the request.',
              textAlign: TextAlign.center,
              style: TextStyle(fontSize: 14, fontWeight: FontWeight.w400),
            ),
            const SizedBox(height: 24),
            // Button
            SizedBox(
              width: double.infinity,
              child: ElevatedButton(
                style: ElevatedButton.styleFrom(
                  backgroundColor: Color(0xFF2E7D32),
                  padding: const EdgeInsets.symmetric(vertical: 14),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(10),
                  ),
                ),
                onPressed: () async {
                  final apiService = DeleteAccountService();
                  final success = await apiService.deleteCustomerAccount(
                    customerId,
                  );

                  if (success) {
                    Navigator.of(context).pop(); // Close the bottom sheet
                    ScaffoldMessenger.of(context).showSnackBar(
                      SnackBar(content: Text('Account deleted successfully')),
                    );

                    // Navigate to LoginPage with pushReplacement
                    Navigator.of(context).pushReplacement(
                      MaterialPageRoute(builder: (context) => LoginPage()),
                    );
                  } else {
                    ScaffoldMessenger.of(context).showSnackBar(
                      SnackBar(content: Text('Failed to delete account')),
                    );
                  }
                },
                child: const Text(
                  'Confirm Account Deletion',
                  style: TextStyle(color: Colors.white, fontSize: 16),
                ),
              ),
            ),
            const SizedBox(height: 10),
          ],
        ),
      );
    },
  );
}
