// models/transaction_model.dart
import 'package:flutter/material.dart';

class TransactionResponse {
  final String message;
  final List<CustomerTransaction> data;

  TransactionResponse({required this.message, required this.data});

  factory TransactionResponse.fromJson(Map<String, dynamic> json) {
    return TransactionResponse(
      message: json['message'],
      data:
          (json['data'] as List)
              .map((item) => CustomerTransaction.fromJson(item))
              .toList(),
    );
  }
}

class CustomerTransaction {
  final int customerId;
  final DateTime paymentDate;
  final DateTime startDate;
  final DateTime endDate;
  final double amount;
  final bool isCancelled;

  CustomerTransaction({
    required this.customerId,
    required this.paymentDate,
    required this.startDate,
    required this.endDate,
    required this.amount,
    required this.isCancelled,
  });

  factory CustomerTransaction.fromJson(Map<String, dynamic> json) {
    return CustomerTransaction(
      customerId: json['customerId'],
      paymentDate: DateTime.parse(json['paymentDate']),
      startDate: DateTime.parse(json['startDate']),
      endDate: DateTime.parse(json['endDate']),
      amount: json['amount'].toDouble(),
      isCancelled: json['isCancelled'],
    );
  }

  String get status => isCancelled ? 'Cancelled' : 'Paid';
  Color get statusColor => isCancelled ? Colors.red : Colors.green;
  Color get statusBgColor =>
      isCancelled ? Colors.red[100]! : Colors.green[100]!;
}
