import 'package:flutter/material.dart';
import 'package:pinput/pinput.dart';
import 'package:prayerunitesss/ui/widgets/create_account/signup_controller.dart';

class OTPVerificationStep extends StatelessWidget {
  final SignupController controller;

  const OTPVerificationStep({super.key, required this.controller});

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text('OTP Verification', style: TextStyle(fontWeight: FontWeight.bold)),
        const SizedBox(height: 4),
        Text(
          'Enter the 6-digit code sent to your mobile number',
          style: TextStyle(color: Colors.grey[700]),
        ),
        const SizedBox(height: 16),
        Center(
          child: Pinput(
            length: 6,
            controller: controller.otpController,
            defaultPinTheme: controller.defaultPinTheme,
            focusedPinTheme: controller.defaultPinTheme.copyDecorationWith(
              border: Border.all(color: const Color(0xFF3B873E)),
            ),
            validator: (value) {
              if (value == null || value.isEmpty) {
                return 'Please enter the OTP';
              }
              if (value.length != 6) {
                return 'OTP must be 6 digits';
              }
              return null;
            },
            showCursor: true,
            onCompleted: (pin) => debugPrint(pin),
          ),
        ),
        const SizedBox(height: 16),
        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text("Didn't receive code? ", style: TextStyle()),
            GestureDetector(
              onTap: () {
                // Resend OTP logic here
              },
              child: Text(
                "Resend",
                style: TextStyle(
                  color: const Color(0xFF2E7D32),
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
          ],
        ),
        const SizedBox(height: 24),
      ],
    );
  }
}
