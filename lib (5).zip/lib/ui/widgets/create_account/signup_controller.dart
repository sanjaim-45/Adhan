import 'package:flutter/material.dart';
import 'package:pinput/pinput.dart';

class SignupController extends ChangeNotifier {
  final GlobalKey<FormState> formKey = GlobalKey<FormState>();
  int currentStep = 1;
  bool isAccountCreated = false;
  bool showValidationErrors = false;

  // Controllers
  final TextEditingController fullNameController = TextEditingController();
  final TextEditingController emailController = TextEditingController();
  final TextEditingController phoneController = TextEditingController();
  final TextEditingController passwordController = TextEditingController();
  final TextEditingController confirmPasswordController =
      TextEditingController();
  final TextEditingController idNumberController = TextEditingController();
  final TextEditingController idExpiryController = TextEditingController();
  final TextEditingController otpController = TextEditingController();

  String get currentStepText {
    switch (currentStep) {
      case 1:
        return "Step 1 of 3";
      case 2:
        return "Step 2 of 3";
      case 3:
        return "Step 3 of 3";
      default:
        return "";
    }
  }

  String get currentStepTitle {
    switch (currentStep) {
      case 1:
        return "Basic Information";
      case 2:
        return "Document Verification";
      case 3:
        return "OTP Verification";
      default:
        return "";
    }
  }

  @override
  void dispose() {
    fullNameController.dispose();
    emailController.dispose();
    phoneController.dispose();
    passwordController.dispose();
    confirmPasswordController.dispose();
    super.dispose();
  }

  PinTheme get defaultPinTheme => PinTheme(
    width: 56,
    height: 56,
    textStyle: const TextStyle(fontSize: 20, color: Colors.black),
    decoration: BoxDecoration(
      border: Border.all(color: const Color(0xFFEBEBEB)),
      borderRadius: BorderRadius.circular(8),
    ),
  );

  double getFontRegularSize(BuildContext context) {
    return 14.0; // You can make this dynamic if needed
  }
}
