import 'package:flutter/material.dart';
import 'package:prayerunitesss/ui/screens/login_page/login_page.dart';

import '../../widgets/create_account/basic_info_step.dart';
import '../../widgets/create_account/document_verify_step.dart';
import '../../widgets/create_account/otp_verification_step.dart';
import '../../widgets/create_account/signup_controller.dart';
import '../../widgets/create_account/success_message.dart';

class SignupScreen extends StatefulWidget {
  const SignupScreen({super.key});

  @override
  State<SignupScreen> createState() => _SignupScreenState();
}

class _SignupScreenState extends State<SignupScreen> {
  final SignupController _controller = SignupController();

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF2E7D32),
      body: SafeArea(
        child: Container(
          margin: const EdgeInsets.only(top: 50),
          child: Column(
            children: [
              const Align(
                alignment: Alignment.topCenter,
                child: Image(
                  image: AssetImage('assets/images/name_logo.png'),
                  height: 40,
                ),
              ),
              const SizedBox(height: 20),
              Expanded(
                child: Container(
                  padding: const EdgeInsets.all(20.0),
                  decoration: const BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.vertical(
                      top: Radius.circular(25),
                    ),
                  ),
                  child: Form(
                    key: _controller.formKey,
                    child:
                        _controller.isAccountCreated
                            ? SuccessMessage(
                              onLoginPressed: () {
                                Navigator.of(context).pushReplacement(
                                  MaterialPageRoute(
                                    builder: (context) => LoginPage(),
                                  ),
                                );
                              },
                            )
                            : Column(
                              children: [
                                Container(
                                  padding: const EdgeInsets.symmetric(
                                    horizontal: 16,
                                  ),
                                  child: Row(
                                    mainAxisAlignment:
                                        MainAxisAlignment.spaceBetween,
                                    children: [
                                      Container(
                                        margin: const EdgeInsets.only(top: 10),
                                        padding: const EdgeInsets.all(8),
                                        decoration: BoxDecoration(
                                          color: Colors.white,
                                          borderRadius: BorderRadius.circular(
                                            5,
                                          ),
                                          border: Border.all(
                                            color: Colors.grey.withOpacity(0.2),
                                            width: 1,
                                          ),
                                          boxShadow: [
                                            BoxShadow(
                                              color: Colors.grey.withOpacity(
                                                0.1,
                                              ),
                                              spreadRadius: 2,
                                              blurRadius: 5,
                                              offset: const Offset(0, 0),
                                            ),
                                          ],
                                        ),
                                        child: InkWell(
                                          child: const Icon(
                                            Icons.arrow_back_ios_new,
                                          ),
                                          onTap: () {
                                            if (_controller.currentStep == 1) {
                                              Navigator.of(context).pop();
                                            } else {
                                              setState(
                                                () => _controller.currentStep--,
                                              );
                                            }
                                          },
                                        ),
                                      ),
                                      Column(
                                        children: [
                                          Text(
                                            _controller.currentStepText,
                                            style: const TextStyle(
                                              color: Colors.grey,
                                            ),
                                          ),
                                          Text(
                                            _controller.currentStepTitle,
                                            style: const TextStyle(
                                              color: Color(0xFF2E7D32),
                                            ),
                                          ),
                                        ],
                                      ),
                                    ],
                                  ),
                                ),
                                const SizedBox(height: 10),
                                Expanded(
                                  child: LayoutBuilder(
                                    builder: (context, constraints) {
                                      return SingleChildScrollView(
                                        physics:
                                            const AlwaysScrollableScrollPhysics(),
                                        child: ConstrainedBox(
                                          constraints: BoxConstraints(
                                            minHeight: constraints.maxHeight,
                                          ),
                                          child: IntrinsicHeight(
                                            child: Padding(
                                              padding:
                                                  const EdgeInsets.symmetric(
                                                    horizontal: 16,
                                                  ),
                                              child: _buildCurrentStep(),
                                            ),
                                          ),
                                        ),
                                      );
                                    },
                                  ),
                                ),
                                if (_controller.currentStep == 2 ||
                                    _controller.currentStep == 3)
                                  Padding(
                                    padding: const EdgeInsets.fromLTRB(
                                      16,
                                      16,
                                      16,
                                      20,
                                    ),
                                    child: SizedBox(
                                      width: double.infinity,
                                      child: ElevatedButton(
                                        onPressed: () {
                                          _controller.showValidationErrors =
                                              true;
                                          _controller.notifyListeners();

                                          if (_controller.formKey.currentState!
                                              .validate()) {
                                            if (_controller.currentStep == 2) {
                                              setState(() {
                                                _controller.currentStep = 3;
                                                _controller
                                                        .showValidationErrors =
                                                    false;
                                              });
                                            } else if (_controller
                                                    .currentStep ==
                                                3) {
                                              setState(() {
                                                _controller.isAccountCreated =
                                                    true;
                                                _controller
                                                        .showValidationErrors =
                                                    false;
                                              });
                                            }
                                          }
                                        },
                                        style: ElevatedButton.styleFrom(
                                          backgroundColor: const Color(
                                            0xFF2D7C3F,
                                          ),
                                          padding: const EdgeInsets.symmetric(
                                            vertical: 14,
                                          ),
                                          shape: RoundedRectangleBorder(
                                            borderRadius: BorderRadius.circular(
                                              10,
                                            ),
                                          ),
                                        ),
                                        child: Text(
                                          _controller.currentStep == 2
                                              ? 'Next'
                                              : 'Create Account',
                                          style: TextStyle(
                                            fontSize: _controller
                                                .getFontRegularSize(context),
                                            fontWeight: FontWeight.w500,
                                            color: Colors.white,
                                          ),
                                        ),
                                      ),
                                    ),
                                  ),
                              ],
                            ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildCurrentStep() {
    switch (_controller.currentStep) {
      case 1:
        return BasicInfoStep(
          controller: _controller,
          showError: _controller.showValidationErrors,
          onNextPressed: () {
            _controller.showValidationErrors = true;
            _controller.notifyListeners();
            if (_controller.formKey.currentState!.validate()) {
              setState(() {
                _controller.currentStep = 2;
                _controller.showValidationErrors = false;
              });
            }
          },
        );
      case 2:
        return DocumentVerifyStep(controller: _controller);
      case 3:
        return OTPVerificationStep(controller: _controller);
      default:
        return const SizedBox();
    }
  }
}
