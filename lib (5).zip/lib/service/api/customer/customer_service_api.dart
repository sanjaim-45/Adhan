import 'dart:convert';

import 'package:http/http.dart' as http;

import '../../../model/api/edit_customer/edit_customer_api_model.dart';
import '../templete_api/api_service.dart';
import '../tokens/token_service.dart';

class CustomerService {
  final String baseUrl;
  final ApiService _apiService;

  CustomerService({required this.baseUrl})
    : _apiService = ApiService(baseUrl: baseUrl);

  Future<Map<String, dynamic>> getCustomerById(int id) async {
    final response = await _apiService.sendRequest(
      '$baseUrl/api/Customer/getCustomerById?id=$id',
      'GET',
    );

    if (response.statusCode == 200) {
      return jsonDecode(response.body);
    } else if (response.statusCode == 401) {
      // Token refresh already attempted by ApiService
      throw Exception('Authentication failed. Please login again.');
    } else {
      throw Exception('Failed to load customer data: ${response.statusCode}');
    }
  }

  Future<http.Response> editCustomer(EditCustomerRequest request) async {
    final uri = Uri.parse('$baseUrl/api/Customer/EditCustomer');

    // Renamed the variable from 'request' to 'multipartRequest' to avoid shadowing
    var multipartRequest = http.MultipartRequest('POST', uri);

    // Add fields using the parameter 'request' (EditCustomerRequest)
    multipartRequest.fields['CustomerId'] = request.customerId.toString();
    multipartRequest.fields['FirstName'] = request.firstName;
    multipartRequest.fields['LastName'] = request.lastName;
    multipartRequest.fields['PhoneNumber'] = request.phoneNumber;
    multipartRequest.fields['Email'] = request.email;
    if (request.civilId != null) {
      multipartRequest.fields['CivilId'] = request.civilId!;
    }
    if (request.passportNumber != null) {
      multipartRequest.fields['PassportNumber'] = request.passportNumber!;
    }
    multipartRequest.fields['Status'] = request.status.toString();
    multipartRequest.fields['UserTypeId'] = request.userTypeId.toString();

    // Add headers (including authorization)
    final accessToken = await TokenService.getAccessToken();
    if (accessToken != null) {
      multipartRequest.headers['Authorization'] = 'Bearer $accessToken';
    }

    try {
      var response = await multipartRequest.send();
      return http.Response.fromStream(response);
    } catch (e) {
      throw Exception('Failed to edit customer: $e');
    }
  }
}
