import 'dart:convert';

import 'package:http/http.dart' as http;

import '../../../model/api/mosque/mosque_model.dart';

class MosqueService {
  final String baseUrl;

  MosqueService({required this.baseUrl});

  Future<MosqueResponse> getAllMosques() async {
    try {
      final response = await http.get(
        Uri.parse('$baseUrl/api/Mosque/getAllMosques'),
      );

      if (response.statusCode == 200) {
        return MosqueResponse.fromJson(json.decode(response.body));
      } else {
        throw Exception(
          'Failed to load mosques. Status code: ${response.statusCode}',
        );
      }
    } on http.ClientException catch (e) {
      throw Exception('Network error occurred: ${e.message}');
    } on FormatException catch (e) {
      throw Exception('Error parsing response data: ${e.message}');
    } catch (e) {
      throw Exception('An unexpected error occurred: $e');
    }
  }
}
