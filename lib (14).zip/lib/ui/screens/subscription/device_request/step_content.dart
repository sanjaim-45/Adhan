import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:prayerunitesss/utils/app_urls.dart';
import 'package:provider/provider.dart';

import '../../../../model/api/address/shipping_address_create_model.dart';
import '../../../../model/api/login/login_model.dart';
import '../../../../model/api/mosque/mosque_model.dart';
import '../../../../providers/device_request/device_request_provider.dart';
import '../../../../service/api/address/get_all/get_all_shipping_address.dart';
import 'mosque_tiles.dart';

class StepContentWidget extends StatelessWidget {
  final int step;
  final List<Mosque?> selectedMasjids;
  final List<SubscriptionPlan?> selectedPlans;
  final List<Mosque> masjidList;
  final Function(int, Mosque?) updateMasjid;
  final Function(int, SubscriptionPlan?) updatePlan;
  final VoidCallback addDevice;
  final Map<String, dynamic>? selectedAddress;
  final List<Map<String, dynamic>> savedAddresses;
  final Future<void> Function() addNewAddress;
  final String? selectedPaymentMethod;
  final Function(String?) onPaymentMethodChanged;
  final Function(Map<String, dynamic>) onAddressSelected;
  List<SubscriptionPlan> plans =
      []; // Changed to store list of SubscriptionPlan

  StepContentWidget({
    super.key,
    required this.step,
    required this.selectedMasjids,
    required this.selectedPlans,
    required this.masjidList,
    required this.updateMasjid,
    required this.updatePlan,
    required this.addDevice,
    this.selectedAddress,
    required this.savedAddresses,
    required this.addNewAddress,
    this.selectedPaymentMethod,
    required this.onPaymentMethodChanged,
    required this.onAddressSelected,
    required this.plans, // Add this to the constructor
  });

  @override
  Widget build(BuildContext context) {
    switch (step) {
      case 0:
        return Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              'Request Speaker Devices',
              style: TextStyle(fontWeight: FontWeight.w600, fontSize: 16),
            ),
            const SizedBox(height: 12),
            ...List.generate(selectedMasjids.length, (index) {
              return Padding(
                padding: const EdgeInsets.only(bottom: 12),
                child: Container(
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(12),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black.withOpacity(0.05),
                        blurRadius: 8,
                        offset: const Offset(0, 2),
                      ),
                    ],
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'Device ${index + 1}',
                        style: const TextStyle(
                          fontWeight: FontWeight.w600,
                          color: Color(0xFF2E7D32),
                          fontSize: 16,
                        ),
                      ),
                      const SizedBox(height: 12),
                      const Text(
                        'Masjid',
                        style: TextStyle(fontWeight: FontWeight.w500),
                      ),
                      const SizedBox(height: 8),
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 12),
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(10),
                          border: Border.all(color: Colors.grey.shade300),
                        ),
                        child: DropdownButtonFormField<Mosque>(
                          dropdownColor: Colors.white,
                          hint: const Text('Select Masjid'),
                          value: selectedMasjids[index],
                          items:
                              masjidList.map((masjid) {
                                return DropdownMenuItem(
                                  value: masjid,
                                  child: Text(masjid.mosqueName),
                                );
                              }).toList(),
                          onChanged: (value) => updateMasjid(index, value),
                          decoration: const InputDecoration(
                            border: InputBorder.none,
                          ),
                        ),
                      ),
                      if (selectedMasjids[index] != null) ...[
                        const SizedBox(height: 12),
                        const Text(
                          'Plan',
                          style: TextStyle(fontWeight: FontWeight.w500),
                        ),
                        const SizedBox(height: 8),
                        Container(
                          padding: const EdgeInsets.symmetric(horizontal: 12),
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(10),
                            border: Border.all(color: Colors.grey.shade300),
                          ),
                          child: DropdownButtonFormField<SubscriptionPlan>(
                            dropdownColor: Colors.white,
                            hint: const Text('Select Plan'),
                            value: selectedPlans[index],
                            items:
                                plans.map((plan) {
                                  return DropdownMenuItem(
                                    value: plan,
                                    child: Text(plan.planName),
                                  );
                                }).toList(),
                            onChanged: (value) => updatePlan(index, value),
                            decoration: const InputDecoration(
                              border: InputBorder.none,
                            ),
                          ),
                        ),
                      ],
                    ],
                  ),
                ),
              );
            }),
            GestureDetector(
              onTap: addDevice,
              child: const Row(
                children: [
                  Icon(Icons.add, color: Color(0xFF2E7D32)),
                  SizedBox(width: 4),
                  Text(
                    'Add Another Device',
                    style: TextStyle(
                      color: Color(0xFF2E7D32),
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ],
              ),
            ),
          ],
        );
      case 1:
        return Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              'Add Address',
              style: TextStyle(fontWeight: FontWeight.w600, fontSize: 16),
            ),
            const SizedBox(height: 12),

            // In your widget file (where you have the Container code)
            FutureBuilder<List<ShippingAddress>>(
              future:
                  ShippingAddressGetAllApiService(
                    baseUrl: AppUrls.appUrl,
                    client: http.Client(),
                  ).getShippingAddresses(),
              builder: (context, snapshot) {
                if (snapshot.connectionState == ConnectionState.waiting) {
                  return const CircularProgressIndicator();
                }
                if (snapshot.hasError) {
                  return Text('Error: ${snapshot.error}');
                }
                if (!snapshot.hasData || snapshot.data!.isEmpty) {
                  return const Text('No shipping addresses found');
                }

                // Find the default address
                final defaultAddress = snapshot.data!.firstWhere(
                  (address) => address.isDefault,
                  orElse: () => snapshot.data!.first,
                );

                // Set the default address as selected when first loaded
                WidgetsBinding.instance.addPostFrameCallback((_) {
                  Provider.of<DeviceRequestProvider>(
                    context,
                    listen: false,
                  ).setShippingAddressId(defaultAddress.shippingAddressId);
                });

                return Container(
                  padding: const EdgeInsets.all(16),
                  margin: const EdgeInsets.only(bottom: 16),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(12),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black.withOpacity(0.05),
                        blurRadius: 8,
                        offset: const Offset(0, 2),
                      ),
                    ],
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      MosqueTiles(
                        isSelected: true,
                        mosqueName: defaultAddress.address ?? '',
                        email: defaultAddress.email ?? '',
                        onTap: () {
                          Provider.of<DeviceRequestProvider>(
                            context,
                            listen: false,
                          ).setShippingAddressId(
                            defaultAddress.shippingAddressId,
                          );
                        },
                        mobileNumber: defaultAddress.phoneNumber ?? '',
                        name: defaultAddress.fullName ?? '',
                      ),
                    ],
                  ),
                );
              },
            ),
            if (savedAddresses.length > 1)
              Column(
                children:
                    savedAddresses.map((address) {
                      if (address == selectedAddress) return const SizedBox();
                      return GestureDetector(
                        onTap: () {
                          onAddressSelected(address);
                        },
                        child: Container(
                          padding: const EdgeInsets.all(16),
                          margin: const EdgeInsets.only(bottom: 8),
                          decoration: BoxDecoration(
                            color: Colors.white,
                            borderRadius: BorderRadius.circular(12),
                            border: Border.all(
                              color:
                                  selectedAddress == address
                                      ? const Color(0xFF2E7D32)
                                      : Colors.grey.shade300,
                              width: 1.5,
                            ),
                          ),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                address['fullName'],
                                style: TextStyle(
                                  fontWeight: FontWeight.w600,
                                  fontSize: 16,
                                  color:
                                      selectedAddress == address
                                          ? const Color(0xFF2E7D32)
                                          : Colors.black,
                                ),
                              ),
                              const SizedBox(height: 8),
                              Text(address['address']),
                              if (address['isDefault'])
                                const Padding(
                                  padding: EdgeInsets.only(top: 8.0),
                                  child: Text(
                                    'Default Address',
                                    style: TextStyle(
                                      color: Color(0xFF2E7D32),
                                      fontWeight: FontWeight.w500,
                                    ),
                                  ),
                                ),
                            ],
                          ),
                        ),
                      );
                    }).toList(),
              ),
            Container(
              margin: const EdgeInsets.only(top: 16),
              padding: const EdgeInsets.symmetric(vertical: 16, horizontal: 8),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(12),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withOpacity(0.05),
                    blurRadius: 8,
                    offset: const Offset(0, 2),
                  ),
                ],
              ),
              child: GestureDetector(
                onTap: addNewAddress,
                child: const Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Icon(Icons.add, color: Color(0xFF2E7D32)),
                    SizedBox(width: 4),
                    Text(
                      'Add New Address',
                      style: TextStyle(
                        color: Color(0xFF2E7D32),
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ],
                ),
              ),
            ),
            if (selectedMasjids.any((masjid) => masjid != null))
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisAlignment: MainAxisAlignment.start,
                children: [
                  const SizedBox(height: 16),
                  const Text(
                    'Device Price Details',
                    style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
                  ),
                  const SizedBox(height: 8),
                  Container(
                    padding: const EdgeInsets.all(16),
                    decoration: BoxDecoration(
                      boxShadow: [
                        BoxShadow(
                          color: Colors.black.withOpacity(0.05),
                          blurRadius: 8,
                          offset: const Offset(0, 2),
                        ),
                      ],
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(12),
                    ),
                    margin: const EdgeInsets.only(bottom: 16),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        // In both case 1 and case 2 where you calculate prices:
                        ...selectedMasjids
                            .asMap()
                            .entries
                            .where((entry) => entry.value != null)
                            .map((masjidEntry) {
                              final plan = selectedPlans[masjidEntry.key];
                              return Padding(
                                padding: const EdgeInsets.symmetric(
                                  vertical: 4.0,
                                ),
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Row(
                                      mainAxisAlignment:
                                          MainAxisAlignment.spaceBetween,
                                      children: [
                                        Text(
                                          'Device ${masjidEntry.key + 1} (${plan?.planName ?? ''})',
                                          style: const TextStyle(
                                            color: Color(0xFF2E7D32),
                                          ),
                                        ),
                                        Text(
                                          '${plan?.price?.toStringAsFixed(2) ?? '0.00'} ${plan?.currency ?? 'KWD'}',
                                        ),
                                      ],
                                    ),
                                    const SizedBox(height: 2),
                                    Text(
                                      masjidEntry.value!.mosqueName ?? '',
                                      style: const TextStyle(
                                        color: Colors.grey,
                                      ),
                                    ),
                                  ],
                                ),
                              );
                            })
                            .toList(),

                        // And update the total calculation:
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            const Text(
                              'Total',
                              style: TextStyle(
                                fontWeight: FontWeight.bold,
                                fontSize: 16,
                              ),
                            ),
                            Text(
                              '${selectedMasjids.asMap().entries.where((entry) => entry.value != null).fold<double>(0.0, (sum, masjidEntry) {
                                final plan = selectedPlans[masjidEntry.key];
                                return sum + (plan?.price ?? 0.0);
                              }).toStringAsFixed(2)} KWD',
                              style: const TextStyle(
                                fontWeight: FontWeight.bold,
                                fontSize: 16,
                              ),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                ],
              ),
          ],
        );
      case 2:
        return Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(12),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withOpacity(0.05),
                    blurRadius: 8,
                    offset: const Offset(0, 2),
                  ),
                ],
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  if (selectedAddress != null)
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Text(
                          'Add Address',
                          style: TextStyle(
                            fontWeight: FontWeight.w600,
                            fontSize: 16,
                          ),
                        ),
                        const SizedBox(height: 12),
                        MosqueTiles(
                          isSelected: true,
                          mosqueName: selectedAddress!['address'] ?? '',
                          email: selectedAddress!['email'] ?? '',
                          onTap: () {
                            // Handle selection logic here
                          },
                          mobileNumber: selectedAddress!['mobileNumber'] ?? '',
                          name: selectedAddress!['fullName'] ?? '',
                        ),
                      ],
                    ),
                ],
              ),
            ),
            const SizedBox(height: 16),
            if (selectedMasjids.any((masjid) => masjid != null))
              Container(
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  boxShadow: [
                    BoxShadow(
                      color: Colors.black.withOpacity(0.05),
                      blurRadius: 8,
                      offset: const Offset(0, 2),
                    ),
                  ],
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(12),
                ),
                margin: const EdgeInsets.only(bottom: 16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text(
                      'Device Price Details',
                      style: TextStyle(
                        fontWeight: FontWeight.bold,
                        fontSize: 16,
                      ),
                    ),
                    const SizedBox(height: 8),
                    ...selectedMasjids
                        .asMap()
                        .entries
                        .where((entry) => entry.value != null)
                        .map((masjidEntry) {
                          final plan = selectedPlans[masjidEntry.key];
                          return Padding(
                            padding: const EdgeInsets.symmetric(vertical: 4.0),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Row(
                                  mainAxisAlignment:
                                      MainAxisAlignment.spaceBetween,
                                  children: [
                                    Text(
                                      'Device ${masjidEntry.key + 1} (${plan?.planName ?? ''})',
                                      style: const TextStyle(
                                        color: Color(0xFF2E7D32),
                                      ),
                                    ),
                                    Text(
                                      '${plan?.price?.toStringAsFixed(2) ?? '0.00'} ${plan?.currency ?? 'KWD'}',
                                    ),
                                  ],
                                ),
                                const SizedBox(height: 2),
                                Text(
                                  masjidEntry.value!.mosqueName ?? '',
                                  style: const TextStyle(color: Colors.grey),
                                ),
                              ],
                            ),
                          );
                        })
                        .toList(),
                    const Divider(
                      height: 20,
                      thickness: 1,
                      color: Color(0xFFDBDBDB),
                    ),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        const Text(
                          'Total',
                          style: TextStyle(
                            fontWeight: FontWeight.bold,
                            fontSize: 16,
                          ),
                        ),
                        Text(
                          '${selectedMasjids.asMap().entries.where((entry) => entry.value != null).fold<double>(0.0, (sum, masjidEntry) {
                            final plan = selectedPlans[masjidEntry.key];
                            return sum + (plan?.price ?? 0.0);
                          }).toStringAsFixed(2)} KWD',
                          style: const TextStyle(
                            fontWeight: FontWeight.bold,
                            fontSize: 16,
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(12),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withOpacity(0.05),
                    blurRadius: 8,
                    offset: const Offset(0, 2),
                  ),
                ],
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text(
                    'Payment Method',
                    style: TextStyle(fontWeight: FontWeight.w600, fontSize: 16),
                  ),
                  const SizedBox(height: 12),
                  RadioListTile<String>(
                    title: const Text('KNET (Online Payment)'),
                    value: 'KNET',
                    groupValue: selectedPaymentMethod,
                    onChanged: onPaymentMethodChanged,
                    activeColor: const Color(0xFF2E7D32),
                  ),
                  RadioListTile<String>(
                    title: const Text('Offline Payment'),
                    value: 'Offline',
                    groupValue: selectedPaymentMethod,
                    onChanged: onPaymentMethodChanged,
                    activeColor: const Color(0xFF2E7D32),
                  ),
                ],
              ),
            ),
            const SizedBox(
              height: 16,
            ), // Add some space before the bottom navigation bar
            const SizedBox(height: 16),
          ],
        );
      default:
        return Container();
    }
  }
}
