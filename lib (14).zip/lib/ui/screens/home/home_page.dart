// lib/views/prayer/prayer_home_page.dart
import 'dart:async';
import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;
import 'package:permission_handler/permission_handler.dart';
import 'package:prayerunitesss/utils/home/home_utils.dart';
import 'package:provider/provider.dart';

import '../../../model/api/prayer/prayer_times.dart';
import '../../../providers/auth_providers.dart';
import '../../../providers/prayer_provider/prayer_timing_provider.dart';
import '../../../service/api/prayer/prayer_timing_api.dart';
import '../../../utils/home/positioned_reuse_widget.dart';
import 'home_page_mosque_header.dart';
import 'my_devices_and_prayers.dart';

class PrayerHomePage extends StatefulWidget {
  const PrayerHomePage({super.key});

  @override
  State<PrayerHomePage> createState() => _PrayerHomePageState();
}

class _PrayerHomePageState extends State<PrayerHomePage>
    with AutomaticKeepAliveClientMixin {
  @override
  bool get wantKeepAlive => true;

  DateTime selectedDate = DateTime.now();
  PrayerTimes prayerTimes = PrayerTimes(
    fajr: '--:--',
    dhuhr: '--:--',
    asr: '--:--',
    maghrib: '--:--',
    isha: '--:--',
  );
  bool isLoading = true;
  String errorMessage = '';
  late PrayerController _prayerController;
  Timer? _timer;
  Duration _timeRemaining = const Duration();
  Map<String, dynamic> _nextPrayer = {
    'name': '--',
    'arabic': '--',
    'time': DateTime.now(),
  };

  @override
  void initState() {
    super.initState();
    _prayerController = PrayerController(PrayerService(http.Client()), context);
    _fetchPrayerTimes();
    _checkPermissions();

    _startTimer();
  }

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }

  Future<void> _checkPermissions() async {
    try {
      // Check location permission (for prayer times)
      var locationStatus = await Permission.location.status;
      if (!locationStatus.isGranted) {
        locationStatus = await Permission.location.request();
        if (!locationStatus.isGranted) {
          if (mounted) HomeUtils().showPermissionDeniedDialog(context);
        }
      }

      // Check notification permission (if your app uses notifications)
      var notificationStatus = await Permission.notification.status;
      if (!notificationStatus.isGranted) {
        notificationStatus = await Permission.notification.request();
      }

      // For Android-specific permissions
      if (Platform.isAndroid) {
        // Check storage permission
        var storageStatus = await Permission.storage.status;
        if (!storageStatus.isGranted) {
          storageStatus = await Permission.storage.request();
        }

        // Check microphone permission if needed
        var micStatus = await Permission.microphone.status;
        if (!micStatus.isGranted) {
          micStatus = await Permission.microphone.request();
        }
      }
    } on PlatformException catch (e) {
      debugPrint("Permission error: ${e.toString()}");
      if (!mounted) return;

      ScaffoldMessenger.of(
        context,
      ).showSnackBar(SnackBar(content: Text("Permission error: ${e.message}")));
    }
  }

  void _startTimer() {
    _timer = Timer.periodic(const Duration(seconds: 1), (timer) {
      if (!mounted) return;

      final now = DateTime.now();
      _nextPrayer = HomeUtils().getNextPrayer(prayerTimes, now);
      _timeRemaining = _nextPrayer['time'].difference(now);

      setState(() {});
    });
  }

  Future<void> _fetchPrayerTimes() async {
    if (!mounted) return;

    setState(() {
      isLoading = true;
      errorMessage = '';
    });

    try {
      final times = await _prayerController.getPrayerTimes(selectedDate);
      if (!mounted) return;

      setState(() {
        prayerTimes = times;
        isLoading = false;
      });

      // Reset timer with new prayer times
      _timer?.cancel();
      _startTimer();
    } catch (e) {
      if (!mounted) return;

      setState(() {
        errorMessage =
            e.toString().contains('authenticated') ||
                    e.toString().contains('Session expired')
                ? 'Please login again.'
                : 'Failed to load prayer times. Please try again.';
        isLoading = false;
      });

      if (e.toString().contains('Location services')) {
        if (mounted) HomeUtils().showEnableLocationDialog(context);
      } else if (e.toString().contains('Location permissions')) {
        if (mounted) HomeUtils().showPermissionDeniedDialog(context);
      } else if (e.toString().contains('authenticated') ||
          e.toString().contains('Session expired')) {
        if (mounted) Navigator.pushReplacementNamed(context, '/login');
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    super.build(context);
    final _ = Provider.of<AuthProvider>(context);
    final mediaQuery = MediaQuery.of(context);
    final screenHeight = mediaQuery.size.height;
    final screenWidth = mediaQuery.size.width;

    // List of prayers data for ListView.builder
    final List<Map<String, dynamic>> prayers = [
      {
        'name': 'Fajr',
        'arabic': 'الفجر',
        'time': prayerTimes.fajr,
        'hasNotification': true,
      },
      {
        'name': 'Dhuhr',
        'arabic': 'الظهر',
        'time': prayerTimes.dhuhr,
        'hasNotification': true,
      },
      {
        'name': 'Asr',
        'arabic': 'العصر',
        'time': prayerTimes.asr,
        'hasNotification': false,
      },
      {
        'name': 'Maghrib',
        'arabic': 'المغرب',
        'time': prayerTimes.maghrib,
        'hasNotification': false,
      },
      {
        'name': 'Isha',
        'arabic': 'العشاء',
        'time': prayerTimes.isha,
        'hasNotification': false,
      },
    ];

    return Scaffold(
      backgroundColor: const Color(0xFF0C5E38),
      body: Column(
        children: [
          Stack(
            children: [
              HomePageMosqueHeader(
                screenHeight: screenHeight,
                screenWidth: screenWidth,
                timeRemaining: _timeRemaining,
                nextPrayer: _nextPrayer,
              ),
              PositionedImageWidget(
                top: screenHeight * 0.05,
                right: screenWidth * 0.34,
                offsetY: screenHeight * 0.01,
                imagePath: "assets/images/lamp_shot.png",
                height: screenHeight * 0.1,
              ),

              PositionedImageWidget(
                top: screenHeight * 0.1,
                right: screenWidth * 0.26,
                offsetY: screenHeight * 0.01,
                imagePath: "assets/images/lamp.png",
                height: screenHeight * 0.1,
              ),

              PositionedImageWidget(
                top: screenHeight * 0.12,
                right: -screenWidth * 0.05,
                offsetY: screenHeight * 0.01,
                imagePath: "assets/images/logo_blur.png",
                height: screenHeight * 0.21,
                width: screenWidth * 0.45,
              ),
            ],
          ),
          MyDevicesAndPrayers(
            screenHeight: screenHeight,
            screenWidth: screenWidth,
            prayers: prayers,
            prayerController: _prayerController,
            selectedDate: selectedDate,
            prayerTimes: prayerTimes,
          ),
        ],
      ),
    );
  }
}
