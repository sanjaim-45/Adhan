import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

import '../../../../utils/font_mediaquery.dart';

class MyDevicesPage extends StatelessWidget {
  final List<String> deviceIds = [
    '#623744884',
    '#623744884',
    '#623744884',
    '#623744884',
  ];

  MyDevicesPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color(0xFFF9F9F9),
      appBar: PreferredSize(
        preferredSize: const Size.fromHeight(80),
        child: Container(
          decoration: BoxDecoration(
            color: Colors.white,
            boxShadow: [
              BoxShadow(
                color: Colors.grey.withOpacity(0.1),
                spreadRadius: 1,
                blurRadius: 8,
                offset: const Offset(0, 4),
              ),
            ],
          ),
          child: Padding(
            padding: const EdgeInsets.only(
              top: 20.0,
            ), // Add padding to push content down
            child: AppBar(
              backgroundColor: Colors.white,
              elevation: 0,
              leadingWidth: 70,
              leading: Padding(
                padding: const EdgeInsets.only(left: 10.0),
                child: GestureDetector(
                  onTap: () => Navigator.of(context).pop(),
                  child: Container(
                    margin: EdgeInsets.all(10),
                    decoration: BoxDecoration(
                      border: Border.all(
                        width: 1,
                        color: Colors.grey.withOpacity(0.5),
                      ), // Optional: specify color
                      borderRadius: BorderRadius.circular(5),
                    ),

                    width: 40,
                    height: 15, // This constrains the arrow container size
                    child: const Icon(
                      Icons.arrow_back_ios_new_rounded,
                      size: 15, // Icon size
                      color: Colors.black,
                    ),
                  ),
                ),
              ),
              title: Padding(
                padding: const EdgeInsets.only(
                  top: 0.0,
                ), // Adjust title position if needed
                child: Text(
                  'My Devices',
                  style: GoogleFonts.beVietnamPro(
                    color: Colors.black,
                    letterSpacing: -0.5,
                    fontSize: getDynamicFontSize(context, 0.05),
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
            ),
          ),
        ),
      ),
      body: Column(
        children: [
          SizedBox(height: 10),
          Expanded(
            child: ListView.builder(
              itemCount: deviceIds.length,
              padding: EdgeInsets.symmetric(horizontal: 16),
              itemBuilder: (context, index) {
                return DeviceTile(deviceId: deviceIds[index]);
              },
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(16.0),
            child: SizedBox(
              width: double.infinity,
              height: 56,
              child: ElevatedButton(
                onPressed: () {
                  showModalBottomSheet(
                    context: context,
                    builder:
                        (BuildContext context) =>
                            ConfirmMasjidAssignmentSheet(),
                  );
                },
                style: ElevatedButton.styleFrom(
                  backgroundColor: Color(0xFF2E7D32),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(12),
                  ),
                ),
                child: Text(
                  'Assign Now',
                  style: TextStyle(fontSize: 16, color: Colors.white),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class ConfirmMasjidAssignmentSheet extends StatelessWidget {
  const ConfirmMasjidAssignmentSheet({super.key});

  @override
  Widget build(BuildContext context) {
    return Stack(
      children: [
        Container(
          padding: EdgeInsets.all(15),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.only(
              topLeft: Radius.circular(20),
              topRight: Radius.circular(20),
            ),
          ),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.start,
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisSize: MainAxisSize.min,
            children: <Widget>[
              SizedBox(height: 30),

              Text(
                'Confirm Masjid Assignment',
                style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
              ),
              SizedBox(height: 10),
              Text(
                'Are you sure you want to connect this device to [Masjid Name]? You can do this only once. Future changes require admin approval  ',
                style: TextStyle(fontSize: 14),
              ),
              SizedBox(height: 10),
              SizedBox(
                width: double.infinity,
                height: 56,
                child: ElevatedButton(
                  onPressed: () {
                    showModalBottomSheet(
                      context: context,
                      builder:
                          (BuildContext context) =>
                              ConfirmMasjidAssignmentSheet(),
                    );
                  },
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Color(0xFF2E7D32),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12),
                    ),
                  ),
                  child: Text(
                    'Confirm',
                    style: TextStyle(fontSize: 16, color: Colors.white),
                  ),
                ),
              ),
            ],
          ),
        ),
        Positioned(
          top: 20,
          right: 20,
          child: GestureDetector(
            onTap: () => Navigator.of(context).pop(),
            child: Container(
              padding: EdgeInsets.all(4),
              decoration: BoxDecoration(
                shape: BoxShape.rectangle,
                borderRadius: BorderRadius.circular(5),
                border: Border.all(color: Colors.grey[300]!, width: 1),
              ),
              child: Icon(Icons.close, size: 20, color: Colors.grey[600]),
            ),
          ),
        ),
      ],
    );
  }
}

class DeviceTile extends StatefulWidget {
  final String deviceId;

  const DeviceTile({super.key, required this.deviceId});

  @override
  _DeviceTileState createState() => _DeviceTileState();
}

class _DeviceTileState extends State<DeviceTile> {
  String? _selectedMosque;
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(12),
        boxShadow: [
          BoxShadow(
            color: Colors.grey.withOpacity(0.1),
            spreadRadius: 1,
            blurRadius: 8,
            offset: const Offset(0, 4), // changes position of shadow
          ),
        ],
      ),
      margin: EdgeInsets.only(bottom: 12),
      child: Card(
        elevation: 0, // Set elevation to 0 to use container's shadow
        color: Colors.transparent, // Make card transparent
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 16),
          child: Row(
            children: [
              Image.asset(
                "assets/images/active_devices.png",
                height: 21,
                width: 21,
              ),
              SizedBox(width: 12),
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('Device ID', style: TextStyle(color: Colors.grey[700])),
                  Text(
                    widget.deviceId,
                    style: TextStyle(fontWeight: FontWeight.bold),
                  ),
                ],
              ),
              Spacer(),
              _buildPopupMenuButton(context),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildPopupMenuButton(BuildContext context) {
    return PopupMenuButton<String>(
      offset: Offset(0, 30), // Offset the popup menu downwards
      color: Colors.white,
      onSelected: (String result) {
        setState(() {
          _selectedMosque = result;
        });
        // Handle mosque selection after state update if needed
        print('Selected mosque: $_selectedMosque');
      },
      itemBuilder: (BuildContext context) {
        // Define your mosque options here
        final mosqueOptions = [
          'Masjid Al-Haram',
          'Al-Masjid an-Nabawi',
          'Sheikh Zayed Grand Mosque',
          'Blue Mosque',
          'Faisal Mosque',
        ];
        return mosqueOptions
            .map(
              (String choice) => PopupMenuItem<String>(
                value: choice,
                child: SizedBox(
                  width: 150, // Specify the width for the dropdown items
                  child: Text(choice, overflow: TextOverflow.ellipsis),
                ),
              ),
            )
            .toList();
      },
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: <Widget>[
          SizedBox(
            width: 100, // Specify the width for the dropdown items

            child: Text(
              _selectedMosque ?? 'Select Mosque',
              style: TextStyle(
                color:
                    _selectedMosque == null ? Color(0xFF2E7D32) : Colors.black,
                fontWeight: FontWeight.w600,
                fontSize: 12,
              ),
            ),
          ),
          Icon(Icons.keyboard_arrow_down, color: Color(0xFF2E7D32)),
        ],
      ),
    );
  }
}
