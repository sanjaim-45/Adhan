import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:permission_handler/permission_handler.dart';

import '../../model/api/prayer/prayer_times.dart';

class HomeUtils {
  String formatCountdown(Duration duration) {
    if (duration.inDays > 0) {
      return "${duration.inDays}d ${duration.inHours % 24}h";
    } else if (duration.inHours > 0) {
      return "${duration.inHours}h ${duration.inMinutes % 60}m";
    } else if (duration.inMinutes > 0) {
      return "${duration.inMinutes}m ${duration.inSeconds % 60}s";
    } else {
      return "${duration.inSeconds}s";
    }
  }

  Map<String, dynamic> getNextPrayer(PrayerTimes prayerTimes, DateTime now) {
    final dateStr = DateFormat('yyyy-MM-dd').format(now);
    final prayers = [
      {
        'name': 'Fajr',
        'arabic': 'الفجر',
        'time': _parsePrayerTime('$dateStr ${prayerTimes.fajr}'),
        'imagePath': 'assets/images/cloud/Sunny.png', // Add image path
      },
      {
        'name': 'Dhuhr',
        'arabic': 'الظهر',
        'time': _parsePrayerTime('$dateStr ${prayerTimes.dhuhr}'),
        'imagePath': 'assets/images/cloud/Partly-cloudy.png',
      },
      {
        'name': 'Asr',
        'arabic': 'العصر',
        'time': _parsePrayerTime('$dateStr ${prayerTimes.asr}'),
        'imagePath': 'assets/images/cloud/Cloudy-clear at times-night.png',
      },
      {
        'name': 'Maghrib',
        'arabic': 'المغرب',
        'time': _parsePrayerTime('$dateStr ${prayerTimes.maghrib}'),
        'imagePath': 'assets/images/cloud/Cloudy-clear at times.png',
      },
      {
        'name': 'Isha',
        'arabic': 'العشاء',
        'time': _parsePrayerTime('$dateStr ${prayerTimes.isha}'),
        'imagePath': 'assets/images/cloud/Clear-night.png',
      },
    ];

    // Filter out null times and sort prayers by time
    final validPrayers = prayers.where((p) => p['time'] != null).toList();
    validPrayers.sort(
      (a, b) => (a['time'] as DateTime).compareTo(b['time'] as DateTime),
    );

    // Find the first prayer that's after now
    for (var prayer in validPrayers) {
      if ((prayer['time'] as DateTime).isAfter(now)) {
        return prayer;
      }
    }

    // If all prayers have passed for today, return first prayer of next day (Fajr)
    final nextFajrTime = _parsePrayerTime('$dateStr ${prayerTimes.fajr}');
    return {
      'name': 'Fajr',
      'arabic': 'الفجر',
      'time':
          nextFajrTime?.add(const Duration(days: 1)) ??
          DateTime.now().add(const Duration(days: 1)),
      'imagePath': 'assets/images/cloud/Clear-night.png',
    };
  }

  DateTime? _parsePrayerTime(String timeString) {
    try {
      return DateTime.parse(timeString);
    } catch (e) {
      return null;
    }
  }

  void showEnableLocationDialog(BuildContext context) {
    showDialog(
      context: context,
      builder:
          (context) => AlertDialog(
            title: const Text('Location Services Disabled'),
            content: const Text(
              'Please enable location services to get accurate prayer times.',
            ),
            actions: [
              TextButton(
                onPressed: () => Navigator.pop(context),
                child: const Text('Cancel'),
              ),
              TextButton(
                onPressed: () => openAppSettings(),
                child: const Text('OK'),
              ),
            ],
          ),
    );
  }

  void showPermissionDeniedDialog(BuildContext context) {
    showDialog(
      context: context,
      builder:
          (context) => AlertDialog(
            title: const Text('Location Permission Denied'),
            content: const Text(
              'Please grant location permission to get accurate prayer times.',
            ),
            actions: [
              TextButton(
                onPressed: () => Navigator.pop(context),
                child: const Text('OK'),
              ),
            ],
          ),
    );
  }
}
