import 'dart:convert';

import 'package:http/http.dart' as http;

import '../tokens/token_service.dart';

class CustomerMosqueMapService {
  final String baseUrl;

  CustomerMosqueMapService({required this.baseUrl});

  Future<void> assignDevicesToMosques(
    List<Map<String, dynamic>> assignments,
  ) async {
    final url = '$baseUrl/api/CustomerMosqueMap/map';
    final accessToken = await TokenService.getAccessToken();

    if (accessToken == null || accessToken.isEmpty) {
      throw Exception('No access token found');
    }

    try {
      final response = await http.post(
        Uri.parse(url),
        headers: {
          'Content-Type': 'application/json',
          'Authorization': 'Bearer $accessToken',
        },
        body: jsonEncode(assignments),
      );

      if (response.statusCode != 200) {
        // Changed this condition
        throw Exception(
          'Failed to assign devices to mosques: ${response.body}',
        );
      }
    } catch (e) {
      print('Error assigning devices to mosques: $e');
      throw Exception('Failed to assign devices to mosques: ${e.toString()}');
    }
  }
}
