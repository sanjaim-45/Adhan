import 'dart:convert';

import 'package:http/http.dart' as http;
import 'package:prayerunitesss/model/api/report_device/report_device_model.dart';

class ReportDeviceApiService {
  final String baseUrl;
  final http.Client client;

  ReportDeviceApiService({required this.baseUrl, required this.client});

  Future<List<ReportDeviceModel>> getAllMyReports(String accessToken) async {
    try {
      final response = await client.get(
        Uri.parse('$baseUrl/api/ReportDeviceRequest/GetAllMyReports'),
        headers: {
          'Authorization': 'Bearer $accessToken',
          'Accept': 'application/json',
        },
      );

      if (response.statusCode == 200) {
        final List<dynamic> jsonResponse = json.decode(response.body);
        return jsonResponse
            .map((item) => ReportDeviceModel.fromJson(item))
            .toList();
      } else {
        throw Exception('Failed to load reports: ${response.statusCode}');
      }
    } catch (e) {
      throw Exception('Error fetching reports: $e');
    }
  }

  Future<bool> cancelReportRequest(String reportId, String accessToken) async {
    final response = await client.post(
      Uri.parse('$baseUrl/api/ReportDeviceRequest/CancelReportRequest'),
      headers: {
        'Content-Type': 'application/json',
        'Authorization': 'Bearer $accessToken',
      },
      body: jsonEncode({'reportId': reportId}),
    );

    if (response.statusCode == 200) {
      return true;
    } else {
      throw Exception('Failed to cancel request');
    }
  }
}
