import 'dart:convert';

import 'package:http/http.dart' as http;

import '../tokens/token_service.dart';

class MosqueChangeRequestService {
  final String baseUrl;

  MosqueChangeRequestService({required this.baseUrl});

  Future<void> submitMosqueChangeRequest({
    required int deviceId,
    required int currentMosqueId,
    required int requestedMosqueId,
    required String reason,
  }) async {
    try {
      final url = '$baseUrl/api/MosqueChangeRequest/RequestMosqueChange';
      // Get the stored access token
      final accessToken = await TokenService.getAccessToken();

      if (accessToken == null || accessToken.isEmpty) {
        throw Exception('No access token found');
      }
      final response = await http.post(
        Uri.parse(url),
        headers: {
          'Content-Type': 'application/json',
          'Authorization': 'Bearer $accessToken',
        },
        body: jsonEncode({
          'deviceId': deviceId,
          'currentMosqueId': currentMosqueId,
          'requestedMosqueId': requestedMosqueId,
          'reason': reason,
        }),
      );

      if (response.statusCode != 200) {
        throw Exception(
          'Failed to submit mosque change request. Status code: ${response.statusCode}, Body: ${response.body}',
        );
      }
    } catch (e) {
      // Log the error or handle it as needed
      print('Error submitting mosque change request: $e');
      throw Exception('Failed to submit mosque change request: $e');
    }
  }
}
