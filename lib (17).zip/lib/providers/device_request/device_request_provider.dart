import 'package:flutter/foundation.dart';

class DeviceRequestProvider with ChangeNotifier {
  List<Map<String, dynamic>> _deviceRequests = [];
  int? _shippingAddressId;
  String? _paymentMethod; // Add this

  List<Map<String, dynamic>> get deviceRequests => _deviceRequests;
  int? get shippingAddressId => _shippingAddressId;
  String? get paymentMethod => _paymentMethod; // Add this getter

  void addDeviceRequest(int masjidId, int planId) {
    _deviceRequests.add({'masjidId': masjidId, 'planId': planId});
    notifyListeners();
  }

  void setShippingAddressId(int addressId) {
    _shippingAddressId = addressId;
    notifyListeners();
  }

  void setPaymentMethod(String method) {
    // New method
    _paymentMethod = method;
    notifyListeners();
  }

  void refreshAddresses() {
    notifyListeners();
  }

  void clearRequests() {
    _deviceRequests.clear();
    _shippingAddressId = null;
    _paymentMethod = null; // Clear this as well
    notifyListeners();
  }
}
