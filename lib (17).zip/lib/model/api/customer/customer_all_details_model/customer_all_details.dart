class CustomerAllDetails {
  final String message;
  final CustomerAll? data; // changed from List<CustomerAll>? to CustomerAll?

  CustomerAllDetails({required this.message, this.data});

  factory CustomerAllDetails.fromJson(Map<String, dynamic> json) {
    return CustomerAllDetails(
      message: json['message'] ?? '',
      data: json['data'] != null ? CustomerAll.fromJson(json['data']) : null,
    );
  }
}

class CustomerAll {
  final int customerId;
  final String fullName;
  final String phoneNumber;
  final String email;
  final String? profileImagePath;
  final String? address;
  final String? civilId;
  final String? civilIdExpiryDate;
  final String createdDate;
  final bool isActive;
  final List<CustomerDevice> devices;

  CustomerAll({
    required this.customerId,
    required this.fullName,
    required this.phoneNumber,
    required this.email,
    this.profileImagePath,
    this.address,
    this.civilId,
    this.civilIdExpiryDate,
    required this.createdDate,
    required this.isActive,
    required this.devices,
  });

  factory CustomerAll.fromJson(Map<String, dynamic> json) {
    return CustomerAll(
      customerId: json['customerId'] ?? 0,
      fullName: json['fullName'] ?? '',
      phoneNumber: json['phoneNumber'] ?? '',
      email: json['email'] ?? '',
      profileImagePath: json['profileImagePath'] as String?,
      address: json['address'] as String?,
      civilId: json['civilId'] as String?,
      civilIdExpiryDate: json['civilIdExpiryDate'] as String?,
      createdDate: json['createdDate'] ?? '',
      isActive: json['isActive'] ?? false,
      devices:
          json['devices'] != null
              ? (json['devices'] as List)
                  .map((i) => CustomerDevice.fromJson(i))
                  .toList()
              : [],
    );
  }
}

class CustomerDevice {
  final int customerDeviceMapId;
  final int deviceId;
  final String deviceName;
  final String serialNumber;
  final String macAddress;
  final String ipAddress;
  final String qrPath;
  final bool deviceStatus;
  final String deviceCreatedDate;
  final Mosquess? mosque;
  final Subscriptionss? subscription;

  CustomerDevice({
    required this.customerDeviceMapId,
    required this.deviceId,
    required this.deviceName,
    required this.serialNumber,
    required this.macAddress,
    required this.ipAddress,
    required this.qrPath,
    required this.deviceStatus,
    required this.deviceCreatedDate,
    this.mosque,
    this.subscription,
  });

  factory CustomerDevice.fromJson(Map<String, dynamic> json) {
    return CustomerDevice(
      customerDeviceMapId: json['customerDeviceMapId'] ?? 0,
      deviceId: json['deviceId'] ?? 0,
      deviceName: json['deviceName'] ?? '',
      serialNumber: json['serialNumber'] ?? '',
      macAddress: json['macAddress'] ?? '',
      ipAddress: json['ipAddress'] ?? '',
      qrPath: json['qrPath'] ?? '',
      deviceStatus: json['deviceStatus'] ?? false,
      deviceCreatedDate: json['deviceCreatedDate'] ?? '',
      mosque: json['mosque'] != null ? Mosquess.fromJson(json['mosque']) : null,
      subscription:
          json['subscription'] != null
              ? Subscriptionss.fromJson(json['subscription'])
              : null,
    );
  }
}

class Mosquess {
  final int mosqueId;
  final String mosqueName;
  final String mosqueLocation;
  final String streetName;
  final String area;
  final String city;
  final String governorate;
  final String paciNumber;
  final String contactPersonName;
  final String contactNumber;
  final bool mosqueMapStatus;
  final String mosqueMapCreatedDate;

  Mosquess({
    required this.mosqueId,
    required this.mosqueName,
    required this.mosqueLocation,
    required this.streetName,
    required this.area,
    required this.city,
    required this.governorate,
    required this.paciNumber,
    required this.contactPersonName,
    required this.contactNumber,
    required this.mosqueMapStatus,
    required this.mosqueMapCreatedDate,
  });

  factory Mosquess.fromJson(Map<String, dynamic> json) {
    return Mosquess(
      mosqueId: json['mosqueId'] ?? 0,
      mosqueName: json['mosqueName'] ?? '',
      mosqueLocation: json['mosqueLocation'] ?? '',
      streetName: json['streetName'] ?? '',
      area: json['area'] ?? '',
      city: json['city'] ?? '',
      governorate: json['governorate'] ?? '',
      paciNumber: json['paciNumber'] ?? '',
      contactPersonName: json['contactPersonName'] ?? '',
      contactNumber: json['contactNumber'] ?? '',
      mosqueMapStatus: json['mosqueMapStatus'] ?? false,
      mosqueMapCreatedDate: json['mosqueMapCreatedDate'] ?? '',
    );
  }
}

class Subscriptionss {
  final int subscriptionID;
  final int planID;
  final String startDate;
  final String endDate;
  final String paymentStatus;
  final double paidAmount;
  final String paymentMethod;
  final bool subscriptionStatus;

  Subscriptionss({
    required this.subscriptionID,
    required this.planID,
    required this.startDate,
    required this.endDate,
    required this.paymentStatus,
    required this.paidAmount,
    required this.paymentMethod,
    required this.subscriptionStatus,
  });

  factory Subscriptionss.fromJson(Map<String, dynamic> json) {
    return Subscriptionss(
      subscriptionID: json['subscriptionID'] ?? 0,
      planID: json['planID'] ?? 0,
      startDate: json['startDate'] ?? '',
      endDate: json['endDate'] ?? '',
      paymentStatus: json['paymentStatus'] ?? '',
      paidAmount: (json['paidAmount'] as num?)?.toDouble() ?? 0.0,
      paymentMethod: json['paymentMethod'] ?? '',
      subscriptionStatus: json['subscriptionStatus'] ?? false,
    );
  }
}
