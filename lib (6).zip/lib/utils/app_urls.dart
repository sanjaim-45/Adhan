class AppUrls {
  static const appUrl = "https://prayer.leatticafe.com";
}

//  final appUrl = "https://prayer.leatticafe.com";
