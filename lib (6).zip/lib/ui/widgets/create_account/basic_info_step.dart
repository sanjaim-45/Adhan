// import 'package:flutter/material.dart';
// import 'package:prayerunitesss/ui/widgets/create_account/signup_controller.dart';
//
// import 'custom_password_field.dart';
// import 'custom_text_field.dart';
//
// class BasicInfoStep extends StatelessWidget {
//   final SignupController controller;
//   final VoidCallback onNextPressed;
//   final bool showError;
//
//   const BasicInfoStep({
//     super.key,
//     required this.controller,
//     required this.onNextPressed,
//     required this.showError,
//   });
//
//   @override
//   Widget build(BuildContext context) {
//     return Column(
//       children: [
//         CustomTextField(
//           label: 'Full Name',
//           hint: 'Enter your full name',
//           controller: controller.fullNameController,
//           validator:
//               (value) =>
//                   value?.isEmpty ?? true ? 'Please enter your full name' : null,
//           showError: showError,
//         ),
//         const SizedBox(height: 16),
//         CustomTextField(
//           label: 'Email',
//           hint: 'Enter your email',
//           controller: controller.emailController,
//           validator: (value) {
//             if (value?.isEmpty ?? true) return 'Please enter your email';
//             if (!RegExp(r'^[\w-\.]+@([\w-]+\.)+[\w-]{2,4}$').hasMatch(value!)) {
//               return 'Please enter a valid email';
//             }
//             return null;
//           },
//           showError: showError,
//         ),
//         const SizedBox(height: 16),
//         CustomTextField(
//           label: 'Phone Number',
//           hint: 'Enter your phone number',
//           controller: controller.phoneController,
//           validator:
//               (value) =>
//                   value?.isEmpty ?? true
//                       ? 'Please enter your phone number'
//                       : null,
//           showError: showError,
//         ),
//         const SizedBox(height: 16),
//         CustomPasswordField(
//           label: 'Password',
//           hint: 'Enter your password',
//           controller: controller.passwordController,
//           validator: (value) {
//             if (value?.isEmpty ?? true) return 'Please enter a password';
//             if (value!.length < 8)
//               return 'Password must be at least 8 characters';
//             return null;
//           },
//           showError: showError,
//         ),
//         const SizedBox(height: 16),
//         CustomPasswordField(
//           label: 'Confirm Password',
//           hint: 'Confirm your password',
//           controller: controller.confirmPasswordController,
//           validator: (value) {
//             if (value != controller.passwordController.text) {
//               return 'Passwords do not match';
//             }
//             return null;
//           },
//           showError: showError,
//         ),
//         const SizedBox(height: 24),
//         SizedBox(
//           width: double.infinity,
//           child: ElevatedButton(
//             onPressed: () {
//               // Force validation
//               controller.setShowValidationErrors(true);
//
//               // Validate form
//               if (controller.formKey.currentState!.validate()) {
//                 onNextPressed();
//               }
//             },
//             style: ElevatedButton.styleFrom(
//               backgroundColor: const Color(0xFF2D7C3F),
//               padding: const EdgeInsets.symmetric(vertical: 14),
//               shape: RoundedRectangleBorder(
//                 borderRadius: BorderRadius.circular(10),
//               ),
//             ),
//             child: Text(
//               'Next',
//               style: TextStyle(
//                 fontWeight: FontWeight.w500,
//                 color: Colors.white,
//               ),
//             ),
//           ),
//         ),
//       ],
//     );
//   }
// }
