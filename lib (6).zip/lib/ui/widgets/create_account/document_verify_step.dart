// import 'package:flutter/material.dart';
//
// import 'custom_text_field.dart';
// import 'signup_controller.dart';
//
// class DocumentVerifyStep extends StatelessWidget {
//   final SignupController controller;
//
//   final bool showError;
//   const DocumentVerifyStep({
//     super.key,
//     required this.controller,
//     required this.showError,
//   });
//
//   @override
//   Widget build(BuildContext context) {
//     return Column(
//       crossAxisAlignment: CrossAxisAlignment.start,
//       children: [
//         Text(
//           'Verify Documentation',
//           style: TextStyle(fontWeight: FontWeight.bold),
//         ),
//         const SizedBox(height: 4),
//         Text(
//           'Enter your Civil ID Number for verification by our support team.',
//           style: TextStyle(color: Colors.grey[700]),
//         ),
//         const SizedBox(height: 16),
//         CustomTextField(
//           label: 'Civil ID Number',
//           hint: 'e.g. 299010101010',
//           controller: controller.idNumberController,
//           validator: (value) {
//             if (value == null || value.isEmpty) {
//               return 'Please enter your Civil ID';
//             }
//             if (!RegExp(r'^[0-9]{12}$').hasMatch(value)) {
//               return 'Civil ID must be 12 digits';
//             }
//             return null;
//           },
//           showError: showError,
//         ),
//         const SizedBox(height: 16),
//         CustomTextField(
//           label: 'ID Expiry Date',
//           hint: 'DD/MM/YYYY',
//           controller: controller.idExpiryController,
//           validator: (value) {
//             if (value == null || value.isEmpty) {
//               return 'Please enter expiry date';
//             }
//             if (!RegExp(r'^\d{2}/\d{2}/\d{4}$').hasMatch(value)) {
//               return 'Enter date in DD/MM/YYYY format';
//             }
//             return null;
//           },
//           showError: showError,
//         ),
//       ],
//     );
//   }
// }
